// src/background/account-storage.ts
var PER_ACCOUNT_KEYS = /* @__PURE__ */ new Set([
  "followerDatabase",
  "followersCache",
  "sessionStats",
  "lastFollowerCount",
  "lastFollowerCountSource",
  "lastFollowerCountAt",
  "lastFollowerCountOwner",
  "userInfo",
  "unfollowerDetected",
  "unfollowerCount",
  "unfollowerDetectedAt",
  "syncQueue",
  "lastNotificationCheck",
  "lastSync",
  "lastFullSync",
  "scanProgress",
  "unfollowerAnalysisProgress",
  "pendingNewFollowerScan",
  "dm_messages"
]);
var REGISTRY_KEY = "accountRegistry";
var ACTIVE_KEY = "activeDsUserId";
var PRIMARY_KEY = "primaryDsUserId";
function nsKey(dsUserId, key) {
  return `acct:${dsUserId}:${key}`;
}
function resolveKey(activeDsUserId, primaryDsUserId, key) {
  if (activeDsUserId && primaryDsUserId && activeDsUserId !== primaryDsUserId && PER_ACCOUNT_KEYS.has(key)) {
    return nsKey(activeDsUserId, key);
  }
  return key;
}
async function getActiveDsUserId() {
  const stored = await chrome.storage.local.get(ACTIVE_KEY);
  return stored[ACTIVE_KEY] ?? null;
}
async function getPrimaryDsUserId() {
  const stored = await chrome.storage.local.get(PRIMARY_KEY);
  return stored[PRIMARY_KEY] ?? null;
}
async function getAccountRegistry() {
  const stored = await chrome.storage.local.get(REGISTRY_KEY);
  const reg = stored[REGISTRY_KEY];
  if (reg && reg.accounts) return reg;
  return { accounts: {} };
}
async function setAccountRegistry(reg) {
  await chrome.storage.local.set({ [REGISTRY_KEY]: reg });
}
async function upsertAccount(dsUserId, patch) {
  const reg = await getAccountRegistry();
  const existing = reg.accounts[dsUserId];
  const merged = {
    dsUserId,
    igUsername: patch.igUsername ?? existing?.igUsername ?? "",
    accountId: patch.accountId ?? existing?.accountId,
    avatarUrl: patch.avatarUrl ?? existing?.avatarUrl,
    linkedAt: existing?.linkedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    dismissed: patch.dismissed ?? existing?.dismissed
  };
  reg.accounts[dsUserId] = merged;
  await setAccountRegistry(reg);
  return merged;
}
async function accountGet(keys) {
  const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
  const keyList = Array.isArray(keys) ? keys : [keys];
  const physicalToLogical = /* @__PURE__ */ new Map();
  for (const key of keyList) {
    physicalToLogical.set(resolveKey(active, primary, key), key);
  }
  const physicalKeys = Array.from(physicalToLogical.keys());
  const raw = await chrome.storage.local.get(physicalKeys);
  const out = {};
  for (const [physical, value] of Object.entries(raw)) {
    const logical = physicalToLogical.get(physical) ?? physical;
    out[logical] = value;
  }
  return out;
}
async function accountSet(obj) {
  const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
  const physical = {};
  for (const [key, value] of Object.entries(obj)) {
    physical[resolveKey(active, primary, key)] = value;
  }
  await chrome.storage.local.set(physical);
}

// src/background/sync-manager.ts
var SyncManager = class {
  constructor() {
    this.API_URL = "https://waler.website/api";
    this.syncQueue = [];
    this.isSyncing = false;
  }
  async trackFollower(data) {
    await this.addToQueue({
      type: "follower",
      username: data.username,
      avatarUrl: data.avatarUrl,
      timestamp: Date.now(),
      metadata: data.metadata
    });
    await this.incrementStat("follower");
    console.log("\u{1F680} New follower detected, syncing immediately...");
    await this.syncToServer();
  }
  async trackUnfollower(data) {
    await this.addToQueue({
      type: "unfollower",
      username: data.username,
      avatarUrl: data.avatarUrl,
      timestamp: Date.now(),
      metadata: data.metadata
    });
    await this.incrementStat("unfollower");
    console.log("\u{1F680} Unfollower detected, syncing immediately...");
    await this.syncToServer();
  }
  async trackGhost(data) {
    await this.addToQueue({
      type: "ghost",
      username: data.username,
      avatarUrl: data.avatarUrl,
      timestamp: Date.now(),
      metadata: data.metadata
    });
    await this.incrementStat("ghost");
  }
  async trackEngagement(data) {
    await this.addToQueue({
      type: "engagement",
      username: data.username,
      timestamp: Date.now(),
      metadata: {
        action: data.action,
        postId: data.postId,
        duration: data.duration
      }
    });
    await this.incrementStat("engagement");
  }
  async addToQueue(data) {
    const stored = await accountGet("syncQueue");
    const queue = stored.syncQueue || [];
    queue.push(data);
    await accountSet({ syncQueue: queue });
    this.syncQueue = queue;
    if (queue.length >= 10) {
      await this.syncToServer();
    }
  }
  async syncToServer() {
    if (this.isSyncing) {
      console.log("\u23F3 Sync already in progress");
      return;
    }
    const stored = await accountGet(["syncQueue", "userId", "apiToken", "isAuthenticated", "userInfo"]);
    if (!stored.isAuthenticated || !stored.userId) {
      console.log("\u274C Not authenticated, skipping sync");
      return;
    }
    const queue = stored.syncQueue || [];
    if (queue.length === 0) {
      console.log("\u2705 Nothing to sync");
      return;
    }
    this.isSyncing = true;
    try {
      console.log(`\u{1F4E4} Syncing ${queue.length} items...`);
      const response = await fetch(`${this.API_URL}/extension/sync`, {
        method: "POST",
        credentials: "include",
        // requireAuth = cookie de session du dashboard
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify({
          userId: stored.userId,
          data: queue
        })
      });
      if (response.ok) {
        await accountSet({
          syncQueue: [],
          lastSync: Date.now()
        });
        this.syncQueue = [];
        console.log("\u2705 Sync successful");
        if (stored.userInfo) {
          console.log("\u{1F4CA} Updating user info after sync...");
          await this.updateUserInfo(stored.userInfo, stored.userId, stored.apiToken);
        }
        await chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "Waler",
          message: `${queue.length} events synced`
        });
      } else {
        console.error("\u274C Sync failed:", response.status);
      }
    } catch (error) {
      console.error("\u274C Sync error:", error);
    } finally {
      this.isSyncing = false;
    }
  }
  async updateUserInfo(userInfo, userId, token) {
    try {
      const response = await fetch(`${this.API_URL}/extension/update-user-info`, {
        method: "POST",
        credentials: "include",
        // requireAuth = cookie de session du dashboard
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          followersCount: userInfo.followersCount || 0,
          followingCount: userInfo.followingCount || 0,
          postsCount: userInfo.postsCount || 0,
          bio: userInfo.bio || "",
          isPrivate: userInfo.isPrivate || false
        })
      });
      if (response.ok) {
        console.log("\u2705 User info updated successfully");
      } else {
        console.error("\u274C Failed to update user info:", response.status);
      }
    } catch (error) {
      console.error("\u274C Error updating user info:", error);
    }
  }
  async getLocalStats() {
    const stored = await accountGet("sessionStats");
    const sessionStats = stored.sessionStats || {
      followers: 0,
      unfollowers: 0,
      ghost: 0,
      pendingClassification: 0,
      engagements: 0
    };
    return {
      followers: sessionStats.followers,
      unfollowers: sessionStats.unfollowers,
      ghost: sessionStats.ghost,
      pendingClassification: sessionStats.pendingClassification,
      engagements: sessionStats.engagements
    };
  }
  async incrementStat(type) {
    const stored = await accountGet("sessionStats");
    const sessionStats = stored.sessionStats || {
      followers: 0,
      unfollowers: 0,
      ghost: 0,
      pendingClassification: 0,
      engagements: 0
    };
    if (type === "follower") {
      sessionStats.followers++;
      sessionStats.pendingClassification = (sessionStats.pendingClassification || 0) + 1;
    } else if (type === "unfollower") {
      sessionStats.unfollowers++;
      sessionStats.pendingClassification = Math.max(0, (sessionStats.pendingClassification || 0) - 1);
    } else if (type === "ghost") {
      sessionStats.ghost = (sessionStats.ghost || 0) + 1;
      sessionStats.pendingClassification = Math.max(0, (sessionStats.pendingClassification || 0) - 1);
    } else if (type === "engagement") sessionStats.engagements++;
    await accountSet({ sessionStats });
  }
  async classifyPerson() {
    const stored = await accountGet("sessionStats");
    const sessionStats = stored.sessionStats || { pendingClassification: 0 };
    sessionStats.pendingClassification = Math.max(0, (sessionStats.pendingClassification || 0) - 1);
    await accountSet({ sessionStats });
  }
  async resetStats() {
    await accountSet({
      sessionStats: {
        followers: 0,
        unfollowers: 0,
        ghost: 0,
        pendingClassification: 0,
        engagements: 0
      }
    });
  }
  async syncFullDatabase() {
    try {
      console.log("\u{1F504} Starting full database sync...");
      const stored = await accountGet(["followerDatabase", "userId", "apiToken", "isAuthenticated"]);
      if (!stored.isAuthenticated || !stored.userId) {
        console.log("\u274C Not authenticated, cannot sync");
        return { success: false, error: "Not authenticated" };
      }
      const db = stored.followerDatabase;
      if (!db || !db.followers) {
        console.log("\u274C No follower database found");
        return { success: false, error: "No database" };
      }
      const activeStore = await chrome.storage.local.get("activeDsUserId");
      const reg = await accountGet("accountRegistry");
      const activeEntry = reg.accountRegistry?.accounts?.[activeStore.activeDsUserId];
      const activeAccountId = activeEntry?.accountId;
      const followers = Object.entries(db.followers).map(([username, data]) => ({
        type: "follower",
        username,
        avatarUrl: data.avatarUrl,
        timestamp: new Date(data.addedAt).getTime(),
        metadata: {
          position: data.position,
          isInitialScan: true
        }
      }));
      console.log(`\u{1F4E4} Syncing ${followers.length} followers from local database...`);
      const response = await fetch(`${this.API_URL}/extension/sync-full`, {
        method: "POST",
        credentials: "include",
        // requireAuth = cookie de session du dashboard
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify({
          userId: stored.userId,
          accountId: activeAccountId,
          followers,
          totalCount: db.totalCount,
          lastScanDate: db.lastScanDate
        })
      });
      if (response.ok) {
        const result = await response.json();
        console.log("\u2705 Full database sync successful:", result);
        await accountSet({
          lastFullSync: Date.now()
        });
        return { success: true, synced: followers.length };
      } else {
        const error = await response.text();
        console.error("\u274C Full sync failed:", response.status, error);
        return { success: false, error: `HTTP ${response.status}` };
      }
    } catch (error) {
      console.error("\u274C Full sync error:", error);
      return { success: false, error: error.message };
    }
  }
};

// src/background/classification-manager.ts
var ClassificationManager = class {
  constructor() {
    this.API_URL = "https://waler.website/api";
  }
  /**
   * Crée une nouvelle suggestion de classification
   */
  async createSuggestion(userId, contactUsername, fromCategory, toCategory, score, confidence, reason, evidence) {
    try {
      const stored = await chrome.storage.local.get("apiToken");
      const response = await fetch(`${this.API_URL}/extension/suggest-transition`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify({
          userId,
          contactUsername,
          fromCategory,
          toCategory,
          score,
          confidence,
          reason,
          evidence
        })
      });
      if (!response.ok) {
        console.error("Failed to create suggestion:", response.status);
        return null;
      }
      const data = await response.json();
      const suggestion = {
        id: data.suggestionId,
        contactUsername,
        fromCategory,
        toCategory,
        score,
        confidence,
        reason,
        evidence,
        status: "pending",
        createdAt: Date.now()
      };
      await this.storeSuggestionLocally(suggestion);
      await this.notifyNewSuggestion(suggestion);
      return suggestion;
    } catch (error) {
      console.error("Error creating suggestion:", error);
      return null;
    }
  }
  /**
   * Accepte une suggestion
   */
  async acceptSuggestion(suggestionId) {
    try {
      const stored = await chrome.storage.local.get("apiToken");
      const response = await fetch(`${this.API_URL}/extension/validate-suggestion`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify({
          suggestionId,
          action: "accept"
        })
      });
      if (!response.ok) {
        console.error("Failed to accept suggestion:", response.status);
        return false;
      }
      const data = await response.json();
      if (data.success) {
        await this.updateSuggestionStatus(suggestionId, "accepted");
        console.log(`\u2705 Suggestion ${suggestionId} accepted, new category: ${data.newCategory}`);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error accepting suggestion:", error);
      return false;
    }
  }
  /**
   * Rejette une suggestion
   */
  async rejectSuggestion(suggestionId, reason) {
    try {
      const stored = await chrome.storage.local.get("apiToken");
      const response = await fetch(`${this.API_URL}/extension/validate-suggestion`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify({
          suggestionId,
          action: "reject",
          reason
        })
      });
      if (!response.ok) {
        console.error("Failed to reject suggestion:", response.status);
        return false;
      }
      const data = await response.json();
      if (data.success) {
        await this.updateSuggestionStatus(suggestionId, "rejected");
        console.log(`\u274C Suggestion ${suggestionId} rejected`);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error rejecting suggestion:", error);
      return false;
    }
  }
  /**
   * Récupère toutes les suggestions en attente
   */
  async getPendingSuggestions() {
    try {
      const stored = await chrome.storage.local.get(["apiToken", "pendingSuggestions"]);
      const response = await fetch(`${this.API_URL}/extension/pending-suggestions`, {
        headers: {
          "Authorization": `Bearer ${stored.apiToken}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        return data.suggestions || [];
      }
      return stored.pendingSuggestions || [];
    } catch (error) {
      console.error("Error getting pending suggestions:", error);
      const stored = await chrome.storage.local.get("pendingSuggestions");
      return stored.pendingSuggestions || [];
    }
  }
  /**
   * Log une transition de catégorie
   */
  async logTransition(transition) {
    try {
      const stored = await chrome.storage.local.get("apiToken");
      await fetch(`${this.API_URL}/extension/log-transition`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${stored.apiToken}`
        },
        body: JSON.stringify(transition)
      });
      console.log(`\u{1F4DD} Transition logged: ${transition.contactUsername} ${transition.fromCategory} \u2192 ${transition.toCategory}`);
    } catch (error) {
      console.error("Error logging transition:", error);
    }
  }
  /**
   * Stocke une suggestion localement
   */
  async storeSuggestionLocally(suggestion) {
    const stored = await chrome.storage.local.get("pendingSuggestions");
    const suggestions = stored.pendingSuggestions || [];
    suggestions.push(suggestion);
    await chrome.storage.local.set({ pendingSuggestions: suggestions });
  }
  /**
   * Met à jour le statut d'une suggestion localement
   */
  async updateSuggestionStatus(suggestionId, status) {
    const stored = await chrome.storage.local.get("pendingSuggestions");
    const suggestions = stored.pendingSuggestions || [];
    const updatedSuggestions = suggestions.map(
      (s) => s.id === suggestionId ? { ...s, status } : s
    );
    await chrome.storage.local.set({ pendingSuggestions: updatedSuggestions });
  }
  /**
   * Notifie l'utilisateur d'une nouvelle suggestion
   */
  async notifyNewSuggestion(suggestion) {
    const emoji = this.getCategoryEmoji(suggestion.toCategory);
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "../icons/icon-48.png",
      title: "New classification suggestion",
      message: `${emoji} @${suggestion.contactUsername}
${suggestion.fromCategory} \u2192 ${suggestion.toCategory}
Score: ${suggestion.score}/100`
    });
    await this.updateBadge();
  }
  /**
   * Met à jour le badge avec le nombre de suggestions en attente
   */
  async updateBadge() {
    const suggestions = await this.getPendingSuggestions();
    const pendingCount = suggestions.filter((s) => s.status === "pending").length;
    if (pendingCount > 0) {
      await chrome.action.setBadgeText({ text: pendingCount.toString() });
      await chrome.action.setBadgeBackgroundColor({ color: "#667eea" });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  }
  /**
   * Retourne l'emoji correspondant à une catégorie
   */
  getCategoryEmoji(category) {
    const emojis = {
      lead: "\u{1F195}",
      prospect: "\u{1F4CA}",
      client: "\u{1F389}",
      network: "\u{1F91D}"
    };
    return emojis[category] || "\u{1F4CB}";
  }
  /**
   * Nettoie les suggestions anciennes (> 30 jours)
   */
  async cleanupOldSuggestions() {
    const stored = await chrome.storage.local.get("pendingSuggestions");
    const suggestions = stored.pendingSuggestions || [];
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1e3;
    const filteredSuggestions = suggestions.filter(
      (s) => s.createdAt > thirtyDaysAgo || s.status === "pending"
    );
    await chrome.storage.local.set({ pendingSuggestions: filteredSuggestions });
    console.log(`\u{1F9F9} Cleaned ${suggestions.length - filteredSuggestions.length} old suggestions`);
  }
};

// src/background/service-worker.ts
var API_BASE = "https://waler.website";
var syncManager = new SyncManager();
var classificationManager = new ClassificationManager();
async function scheduleNextMidnightReset() {
  const now = /* @__PURE__ */ new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);
  const timeUntilMidnight = tomorrow.getTime() - now.getTime();
  console.log(`\u23F0 Next stats reset scheduled in ${Math.round(timeUntilMidnight / 1e3 / 60)} minutes (at midnight)`);
  setTimeout(async () => {
    console.log("\u{1F319} Midnight! Resetting daily stats...");
    await syncManager.resetStats();
    chrome.runtime.sendMessage({ type: "STATS_RESET_MIDNIGHT" }).catch(() => {
    });
    scheduleNextMidnightReset();
  }, timeUntilMidnight);
}
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("\u{1F680} Waler Extension installed/updated, reason:", details.reason);
  if (details.reason === "install") {
    await chrome.storage.local.set({
      isAuthenticated: false,
      userId: null,
      lastSync: null
    });
  }
  chrome.alarms.create("sync-data", {
    periodInMinutes: 5
  });
  scheduleNextMidnightReset();
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "sync-data") {
    console.log("\u23F0 Syncing data...");
    await syncManager.syncToServer();
  }
});
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  console.log("\u{1F4E8} External message received:", message.type, "from:", sender.url);
  if (message.type === "WALER_AUTH" && message.userId && message.token) {
    console.log("\u{1F510} Received authentication token from Waler website");
    fetch(API_BASE + "/api/extension/validate-token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: message.token })
    }).then((res) => res.json()).then((data) => {
      if (data.valid && data.userId === message.userId) {
        console.log("\u2705 Token validated, storing authentication...");
        return chrome.storage.local.set({
          isAuthenticated: true,
          userId: message.userId,
          apiToken: message.token,
          lastSync: Date.now()
        });
      } else {
        throw new Error("Token validation failed");
      }
    }).then(() => {
      console.log("\u2705 Extension authenticated successfully");
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("\u274C Authentication error:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (message.type === "PING") {
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "VERIFY_IG_OWNERSHIP") {
    const claimedUsername = (message.claimedUsername || "").trim();
    (async () => {
      try {
        const cookie = await chrome.cookies.get({
          url: "https://www.instagram.com",
          name: "ds_user_id"
        });
        const dsUserId = cookie?.value;
        if (!dsUserId) {
          sendResponse({ loggedIn: false });
          return;
        }
        const resp = await fetch(`https://www.instagram.com/api/v1/users/${dsUserId}/info/`, {
          method: "GET",
          credentials: "include",
          headers: { "x-ig-app-id": "936619743392459" }
        });
        if (!resp.ok) {
          console.warn(`\u26A0\uFE0F [VERIFY] users/${dsUserId}/info a r\xE9pondu ${resp.status}`);
          sendResponse({ loggedIn: true, verified: false, dsUserId });
          return;
        }
        const data = await resp.json();
        const igUsername = data?.user?.username;
        const verified = !!igUsername && igUsername.toLowerCase() === claimedUsername.toLowerCase();
        sendResponse({ loggedIn: true, verified, igUsername, dsUserId });
      } catch (error) {
        console.error("\u274C [VERIFY] Erreur de v\xE9rification de propri\xE9t\xE9:", error);
        sendResponse({ loggedIn: true, verified: false, error: error?.message });
      }
    })();
    return true;
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("\u{1F4E8} Message received:", message.type);
  (async () => {
    switch (message.type) {
      case "WALER_AUTH":
        console.log("\u{1F510} Received authentication from Waler");
        try {
          const validateResponse = await fetch(API_BASE + "/api/extension/validate-token", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token: message.apiToken })
          });
          const validateData = await validateResponse.json();
          if (validateData.valid && validateData.userId === message.userId) {
            console.log("\u2705 Token validated, storing authentication...");
            await chrome.storage.local.set({
              isAuthenticated: true,
              userId: message.userId,
              apiToken: message.apiToken,
              subscriptionTier: validateData.subscriptionTier ?? null,
              isPro: validateData.isPro === true,
              lastSync: Date.now()
            });
            console.log(`\u2705 Extension authenticated successfully (tier: ${validateData.subscriptionTier ?? "n/a"}, pro: ${validateData.isPro === true})`);
            sendResponse({ success: true });
          } else {
            console.error("\u274C Token validation failed");
            sendResponse({ success: false, error: "Token validation failed" });
          }
        } catch (error) {
          console.error("\u274C Authentication error:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      case "REFRESH_PRO_STATUS":
        {
          const isPro = await refreshProStatus();
          sendResponse({ success: true, isPro });
        }
        break;
      case "TRACK_FOLLOWER":
        await syncManager.trackFollower(message.data);
        sendResponse({ success: true });
        break;
      case "TRACK_UNFOLLOWER":
        await syncManager.trackUnfollower(message.data);
        sendResponse({ success: true });
        break;
      case "TRACK_POTENTIAL_BLOCKER":
      case "TRACK_GHOST":
        await syncManager.trackGhost(message.data);
        sendResponse({ success: true });
        break;
      case "PERSON_CLASSIFIED":
        await syncManager.classifyPerson();
        sendResponse({ success: true });
        break;
      case "TRACK_ENGAGEMENT":
        await syncManager.trackEngagement(message.data);
        sendResponse({ success: true });
        break;
      case "SYNC_NOW":
        await syncManager.syncToServer();
        {
          const syncNowStored = await accountGet(["userInfo", "userId", "apiToken", "isAuthenticated"]);
          if (syncNowStored.isAuthenticated && syncNowStored.userId && syncNowStored.userInfo) {
            try {
              await syncManager.updateUserInfo(syncNowStored.userInfo, syncNowStored.userId, syncNowStored.apiToken);
              console.log("\u2705 [SYNC_NOW] User info force-synced to backend");
            } catch (e) {
              console.error("\u274C [SYNC_NOW] Failed to force-update user info:", e);
            }
          }
        }
        {
          const syncTabs = await chrome.tabs.query({});
          for (const tab of syncTabs) {
            if (tab.url?.startsWith(API_BASE)) {
              try {
                await chrome.tabs.sendMessage(tab.id, {
                  type: "REFRESH_DASHBOARD",
                  data: { syncCompleted: true }
                });
              } catch (_) {
              }
            }
          }
        }
        sendResponse({ success: true });
        break;
      case "GET_STATS":
        const stats = await syncManager.getLocalStats();
        sendResponse({ success: true, data: stats });
        break;
      case "GET_PEOPLE":
        try {
          const activeStoreP = await chrome.storage.local.get("activeDsUserId");
          const regP = await accountGet("accountRegistry");
          const activeEntryP = regP.accountRegistry?.accounts?.[activeStoreP.activeDsUserId];
          const activeAccIdP = activeEntryP?.accountId;
          const activeUserP = message.username || activeEntryP?.igUsername;
          const peopleParams = new URLSearchParams();
          if (activeUserP) peopleParams.set("username", activeUserP);
          if (activeAccIdP) peopleParams.set("accountId", String(activeAccIdP));
          const peopleQs = peopleParams.toString();
          const peopleUrl = `${API_BASE}/api/extension/people${peopleQs ? `?${peopleQs}` : ""}`;
          console.log("\u{1F50E} GET_PEOPLE diag \u2192", {
            activeDsUserId: activeStoreP.activeDsUserId,
            igUsername: activeEntryP?.igUsername,
            accountId: activeAccIdP,
            url: peopleUrl
          });
          const peopleResp = await fetch(peopleUrl, {
            method: "GET",
            credentials: "include"
          });
          if (!peopleResp.ok) {
            const body = await peopleResp.text().catch(() => "");
            console.warn("\u26A0\uFE0F GET_PEOPLE: HTTP", peopleResp.status, body.slice(0, 200));
            sendResponse({ success: false, error: `HTTP ${peopleResp.status}`, people: [] });
            break;
          }
          const peopleData = await peopleResp.json();
          console.log(`\u{1F50E} GET_PEOPLE r\xE9sultat \u2192 ${(peopleData.people || []).length} contact(s)`, peopleData.people);
          sendResponse({ success: true, people: peopleData.people || [] });
        } catch (error) {
          console.error("Error fetching people:", error);
          sendResponse({ success: false, error: error.message, people: [] });
        }
        break;
      case "RESTORE_FOLLOWERS":
        try {
          const activeStoreR = await chrome.storage.local.get("activeDsUserId");
          const regR = await accountGet("accountRegistry");
          const activeAccId = regR.accountRegistry?.accounts?.[activeStoreR.activeDsUserId]?.accountId;
          const restoreUrl = activeAccId ? `${API_BASE}/api/extension/followers?accountId=${activeAccId}` : `${API_BASE}/api/extension/followers`;
          const restoreResp = await fetch(restoreUrl, {
            method: "GET",
            credentials: "include"
          });
          if (!restoreResp.ok) {
            console.warn("\u26A0\uFE0F RESTORE_FOLLOWERS: r\xE9ponse", restoreResp.status);
            sendResponse({ success: false, error: `HTTP ${restoreResp.status}`, followers: [] });
            break;
          }
          const restoreData = await restoreResp.json();
          sendResponse({
            success: true,
            followers: restoreData.followers || [],
            totalCount: restoreData.totalCount || 0
          });
        } catch (error) {
          console.error("Error restoring followers:", error);
          sendResponse({ success: false, error: error.message, followers: [] });
        }
        break;
      case "AUTHENTICATE":
        await chrome.storage.local.set({
          isAuthenticated: true,
          userId: message.userId,
          apiToken: message.token
        });
        sendResponse({ success: true });
        break;
      case "LINK_ACCOUNT":
        try {
          const { dsUserId, igUsername } = message.data || {};
          if (!dsUserId) {
            sendResponse({ success: false, error: "dsUserId manquant" });
            break;
          }
          const linkStored = await chrome.storage.local.get("apiToken");
          if (!linkStored.apiToken) {
            sendResponse({ success: false, error: "Not authenticated" });
            break;
          }
          const linkResp = await fetch(API_BASE + "/api/accounts/link", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${linkStored.apiToken}`
            },
            credentials: "include",
            body: JSON.stringify({ igUsername, dsUserId })
          });
          if (!linkResp.ok) {
            const errText = await linkResp.text();
            console.error("\u274C LINK_ACCOUNT backend error:", linkResp.status, errText);
            sendResponse({ success: false, error: `HTTP ${linkResp.status}` });
            break;
          }
          const linkData = await linkResp.json();
          const account = await upsertAccount(dsUserId, {
            igUsername,
            accountId: linkData.accountId,
            avatarUrl: linkData.avatarUrl
          });
          console.log(`\u{1F517} Compte li\xE9: @${igUsername} \u2192 accountId ${linkData.accountId}`);
          sendResponse({ success: true, account });
        } catch (error) {
          console.error("Error linking account:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      case "GET_ACCOUNTS":
        try {
          const accTokenStore = await chrome.storage.local.get("apiToken");
          if (accTokenStore.apiToken) {
            try {
              const r = await fetch(API_BASE + "/api/accounts", {
                headers: { Authorization: `Bearer ${accTokenStore.apiToken}` },
                credentials: "include"
              });
              if (r.ok) {
                const d = await r.json();
                for (const a of d.accounts || []) {
                  if (a.instagramUserId) {
                    await upsertAccount(String(a.instagramUserId), {
                      igUsername: a.username,
                      accountId: a.id,
                      avatarUrl: a.avatarUrl
                    });
                  }
                }
              }
            } catch (e) {
              console.warn("\u26A0\uFE0F GET_ACCOUNTS: fusion backend \xE9chou\xE9e (non bloquant):", e);
            }
          }
          const reg = await accountGet("accountRegistry");
          const activeStored = await chrome.storage.local.get("activeDsUserId");
          sendResponse({
            success: true,
            accounts: reg.accountRegistry?.accounts || {},
            activeDsUserId: activeStored.activeDsUserId || null
          });
        } catch (error) {
          sendResponse({ success: false, error: error.message, accounts: {} });
        }
        break;
      case "SET_ACTIVE_ACCOUNT":
        try {
          const targetDs = message.dsUserId;
          if (!targetDs) {
            sendResponse({ success: false, error: "dsUserId manquant" });
            break;
          }
          await chrome.storage.local.set({ activeDsUserId: targetDs });
          const reg2 = await accountGet("accountRegistry");
          const entry = reg2.accountRegistry?.accounts?.[targetDs];
          const tokenStore = await chrome.storage.local.get("apiToken");
          if (entry?.accountId && tokenStore.apiToken) {
            try {
              await fetch(API_BASE + "/api/accounts/switch", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${tokenStore.apiToken}`
                },
                credentials: "include",
                body: JSON.stringify({ accountId: entry.accountId })
              });
            } catch (e) {
              console.warn("\u26A0\uFE0F Backend switch failed (non bloquant):", e);
            }
          }
          sendResponse({ success: true });
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
        break;
      // ==================== DM HANDLERS ====================
      case "NEW_DM":
        await storeDMLocally(message.message);
        console.log(`\u{1F4AC} DM stored: @${message.message.conversationWith}`);
        sendResponse({ success: true });
        break;
      case "SYNC_DMS":
        await syncDMsToBackend(message.messages, message.conversations);
        sendResponse({ success: true });
        break;
      case "GET_DM_CONVERSATIONS":
        const conversations = await getDMConversations();
        sendResponse({ success: true, conversations });
        break;
      case "SYNC_PRO_ENGAGEMENT":
        try {
          const engResp = await fetch(API_BASE + "/api/extension/pro-engagement", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({
              engagements: message.engagements || [],
              analyzedPosts: message.analyzedPosts || [],
              engagers: message.engagers || [],
              mutuals: message.mutuals || []
            })
          });
          const engData = engResp.ok ? await engResp.json() : null;
          sendResponse({ success: engResp.ok, ...engData || { error: `HTTP ${engResp.status}` } });
        } catch (error) {
          console.error("Error syncing pro engagement:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      // ==================== CLASSIFICATION HANDLERS ====================
      case "UPDATE_CONTACT_SCORE":
        await updateContactScore(message.username, message.scoreBreakdown, message.category || "lead", {
          temperature: message.temperature,
          dynamics: message.dynamics,
          advice: message.advice,
          settingPhase: message.settingPhase,
          settingSummary: message.settingSummary
        });
        sendResponse({ success: true });
        break;
      case "ANALYZE_DMS":
        {
          const dmScore = await analyzeDMsOnServer(message.username);
          sendResponse({ success: true, dmScore });
        }
        break;
      case "UPDATE_CONTACT_NAME":
        await updateContactName(message.username, message.fullName);
        sendResponse({ success: true });
        break;
      case "CREATE_SUGGESTION":
        const suggestion = await createSuggestion(
          message.username,
          message.transition,
          message.scoreBreakdown
        );
        if (suggestion) {
          await classificationManager.updateBadge();
        }
        sendResponse({ success: true, suggestion });
        break;
      case "GET_SUGGESTIONS":
        const suggestions = await classificationManager.getPendingSuggestions();
        sendResponse({ success: true, suggestions });
        break;
      case "ACCEPT_SUGGESTION":
        const accepted = await classificationManager.acceptSuggestion(message.suggestionId);
        if (accepted) {
          await classificationManager.updateBadge();
        }
        sendResponse({ success: accepted });
        break;
      case "REJECT_SUGGESTION":
        const rejected = await classificationManager.rejectSuggestion(
          message.suggestionId,
          message.reason
        );
        if (rejected) {
          await classificationManager.updateBadge();
        }
        sendResponse({ success: rejected });
        break;
      // ==================== FOLLOWER MONITORING ====================
      case "FOLLOWER_CHANGE_DETECTED":
        const changeType = message.changeType === "follower" ? "new follower(s)" : "unfollower(s)";
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: `${message.count} ${changeType} detected!`,
          message: "Click the Waler icon to sync.",
          priority: 2
        });
        sendResponse({ success: true });
        break;
      case "UPDATE_BADGE":
        chrome.action.setBadgeText({ text: message.text });
        chrome.action.setBadgeBackgroundColor({ color: message.color || "#00FF00" });
        sendResponse({ success: true });
        break;
      case "CHECK_NOTIFICATIONS":
        (async () => {
          try {
            const tabs2 = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tabs2[0]?.id) {
              await chrome.tabs.sendMessage(tabs2[0].id, {
                type: "START_NOTIFICATION_CHECK"
              });
              sendResponse({ success: true });
            } else {
              sendResponse({ success: false, error: "No active tab" });
            }
          } catch (error) {
            console.error("Error checking notifications:", error);
            sendResponse({ success: false, error: String(error) });
          }
        })();
        return true;
      // Keep channel open for async response
      case "INITIAL_SCAN_REQUIRED":
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "Initial scan required",
          message: "Click the Waler icon to start scanning your followers.",
          priority: 2
        });
        chrome.action.setBadgeText({ text: "!" });
        chrome.action.setBadgeBackgroundColor({ color: "#FF6B00" });
        sendResponse({ success: true });
        break;
      case "SCAN_PROGRESS":
        const progress = Math.floor(message.current / message.total * 100);
        chrome.action.setBadgeText({ text: `${progress}%` });
        chrome.action.setBadgeBackgroundColor({ color: "#0095F6" });
        await accountSet({
          scanProgress: {
            current: message.current,
            total: message.total,
            percentage: progress
          }
        });
        sendResponse({ success: true });
        break;
      case "CLEAR_STORAGE":
        await chrome.storage.local.clear();
        chrome.action.setBadgeText({ text: "" });
        console.log("\u{1F504} Extension storage cleared - Reset to first use");
        sendResponse({ success: true });
        break;
      case "SEND_UNFOLLOWER_RESULTS":
        try {
          const stored = await chrome.storage.local.get("apiToken");
          if (!stored.apiToken) {
            console.error("No API token found");
            sendResponse({ success: false, error: "Not authenticated" });
            break;
          }
          const response = await fetch(API_BASE + "/api/extension/verify-missing-followers", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${stored.apiToken}`
            },
            body: JSON.stringify(message.data)
          });
          const result = await response.json();
          if (response.ok) {
            console.log("\u2705 Unfollower results sent to backend:", result);
            sendResponse({ success: true, data: result });
          } else {
            console.error("\u274C Failed to send unfollower results:", result);
            sendResponse({ success: false, error: result.message });
          }
        } catch (error) {
          console.error("Error sending unfollower results:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      case "UNFOLLOWER_ANALYSIS_PROGRESS":
        const analysisProgress = message.data;
        chrome.action.setBadgeText({ text: `${analysisProgress.percentage}%` });
        chrome.action.setBadgeBackgroundColor({ color: "#FF6B00" });
        await accountSet({
          unfollowerAnalysisProgress: analysisProgress
        });
        sendResponse({ success: true });
        break;
      case "RESET_STATS":
        await syncManager.resetStats();
        console.log("\u{1F504} Session stats reset");
        sendResponse({ success: true });
        break;
      case "REPAIR_FOLLOWER_DB": {
        const repairStored = await accountGet(["followerDatabase", "lastFollowerCount", "userInfo"]);
        const repairDb = repairStored.followerDatabase;
        if (!repairDb || !repairDb.followers) {
          sendResponse({ success: false, error: "Base de donn\xE9es introuvable" });
          break;
        }
        const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        const originalEntries = Object.entries(repairDb.followers);
        const originalCount = originalEntries.length;
        const cleanedFollowers = {};
        for (const [username, data] of originalEntries) {
          if (!data.addedAt || !data.addedAt.startsWith(today)) {
            cleanedFollowers[username] = data;
          }
        }
        const removedCount = originalCount - Object.keys(cleanedFollowers).length;
        const repairedDb = {
          ...repairDb,
          followers: cleanedFollowers,
          totalCount: Object.keys(cleanedFollowers).length
        };
        await accountSet({
          followerDatabase: repairedDb,
          // Effacer la fausse alarme unfollower déclenchée par le bug
          unfollowerDetected: false,
          unfollowerCount: 0,
          // Réinitialiser le check des notifications pour repartir proprement
          lastNotificationCheck: 0
        });
        console.log(`\u{1F527} DB r\xE9par\xE9e: ${removedCount} entr\xE9es supprim\xE9es (${originalCount} \u2192 ${Object.keys(cleanedFollowers).length})`);
        sendResponse({ success: true, removed: removedCount, remaining: Object.keys(cleanedFollowers).length });
        break;
      }
      case "GET_DB_DUMP": {
        const dumpStored = await accountGet([
          "followerDatabase",
          "lastFollowerCount",
          "unfollowerDetected",
          "unfollowerCount",
          "lastNotificationCheck",
          "sessionStats"
        ]);
        const dumpDb = dumpStored.followerDatabase;
        const usernames = dumpDb ? Object.keys(dumpDb.followers || {}) : [];
        sendResponse({
          success: true,
          totalCount: dumpDb?.totalCount ?? 0,
          entriesInDB: usernames.length,
          isInitialized: dumpDb?.isInitialized ?? false,
          firstFollowerId: dumpDb?.firstFollowerId ?? null,
          lastFollowerCount: dumpStored.lastFollowerCount ?? 0,
          unfollowerDetected: dumpStored.unfollowerDetected ?? false,
          unfollowerCount: dumpStored.unfollowerCount ?? 0,
          lastNotificationCheck: dumpStored.lastNotificationCheck ?? 0,
          sessionStats: dumpStored.sessionStats ?? {},
          usernames
        });
        break;
      }
      case "SIMULATE_UNFOLLOWER": {
        const simStored = await accountGet("followerDatabase");
        const simCount = message.count || 1;
        await accountSet({
          unfollowerDetected: true,
          unfollowerCount: simCount
        });
        chrome.action.setBadgeText({ text: `-${simCount}` });
        chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
        const simDbCount = simStored.followerDatabase ? Object.keys(simStored.followerDatabase.followers || {}).length : 0;
        console.log(`\u{1F3AD} Unfollower simul\xE9 (${simCount}) \u2014 bouton analyse maintenant visible, DB=${simDbCount}`);
        sendResponse({ success: true, dbCount: simDbCount });
        break;
      }
      case "RESET_FOLLOWER_DB": {
        await accountSet({
          followerDatabase: {
            followers: {},
            isInitialized: false,
            totalCount: 0,
            firstFollowerId: null
          },
          unfollowerDetected: false,
          unfollowerCount: 0,
          lastFollowerCount: 0,
          lastNotificationCheck: 0,
          sessionStats: {
            followers: 0,
            unfollowers: 0,
            ghost: 0,
            pendingClassification: 0,
            engagements: 0
          }
        });
        console.log("\u{1F504} Follower DB r\xE9initialis\xE9e \u2014 pr\xEAt pour le scan initial");
        sendResponse({ success: true });
        break;
      }
      case "UPDATE_UNFOLLOWER_STATS":
        try {
          const stored = await accountGet("sessionStats");
          const sessionStats = stored.sessionStats || {
            followers: 0,
            unfollowers: 0,
            ghost: 0,
            pendingClassification: 0,
            engagements: 0
          };
          sessionStats.unfollowers += message.data.unfollowers || 0;
          sessionStats.ghost = (sessionStats.ghost || 0) + (message.data.ghost || message.data.potentialBlockers || 0);
          await accountSet({ sessionStats });
          console.log("\u{1F4CA} Session stats updated:", sessionStats);
          sendResponse({ success: true });
        } catch (error) {
          console.error("Error updating stats:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      case "SYNC_FULL_DATABASE":
        console.log("\u{1F504} Starting full database sync...");
        const syncResult = await syncManager.syncFullDatabase();
        sendResponse(syncResult);
        break;
      case "TRIGGER_AGENT_B":
        try {
          const stored = await chrome.storage.local.get("apiToken");
          if (!stored.apiToken) {
            console.error("No API token found");
            sendResponse({ success: false, error: "Not authenticated" });
            break;
          }
          const response = await fetch(API_BASE + "/api/extension/trigger-agent-b", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${stored.apiToken}`
            },
            body: JSON.stringify(message.data)
          });
          const result = await response.json();
          if (response.ok) {
            console.log("\u2705 Agent B triggered successfully:", result);
            sendResponse({ success: true, data: result });
          } else {
            console.error("\u274C Failed to trigger Agent B:", result);
            sendResponse({ success: false, error: result.message });
          }
        } catch (error) {
          console.error("Error triggering Agent B:", error);
          sendResponse({ success: false, error: error.message });
        }
        break;
      case "ANALYSIS_COMPLETED":
        console.log("\u2705 Analysis completed:", message.data);
        {
          const confirmedUnfollowers = message.data?.unfollowers || 0;
          if (confirmedUnfollowers > 0) {
            chrome.action.setBadgeText({ text: `-${confirmedUnfollowers}` });
            chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
            console.log(`\u{1F4CA} Badge set to -${confirmedUnfollowers} (analyse)`);
          } else {
            chrome.action.setBadgeText({ text: "" });
          }
        }
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
          if (tab.url?.startsWith(API_BASE)) {
            try {
              await chrome.tabs.sendMessage(tab.id, {
                type: "REFRESH_DASHBOARD",
                data: message.data
              });
              console.log(`\u{1F4E4} Sent refresh notification to dashboard tab ${tab.id}`);
            } catch (error) {
              console.log(`Could not send message to tab ${tab.id}`);
            }
          }
        }
        sendResponse({ success: true });
        break;
      case "FOLLOWER_COUNT_CHANGED":
        console.log("\u{1F514} Follower count changed:", message.data);
        const { oldCount, newCount, diff } = message.data;
        await chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "FlowTrack - Followers Changed",
          message: diff > 0 ? `+${diff} nouveau(x) follower(s) ! (${oldCount} \u2192 ${newCount})` : `${Math.abs(diff)} unfollower(s) d\xE9tect\xE9(s) (${oldCount} \u2192 ${newCount})`,
          priority: 2
        });
        chrome.action.setBadgeText({ text: diff > 0 ? `+${diff}` : `${diff}` });
        chrome.action.setBadgeBackgroundColor({ color: diff > 0 ? "#02c950" : "#f59e0b" });
        console.log(`\u{1F4CA} Badge updated: ${diff > 0 ? "+" : ""}${diff}`);
        const instagramTabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
        for (const tab of instagramTabs) {
          if (tab.id) {
            try {
              await chrome.tabs.sendMessage(tab.id, {
                type: "FOLLOWER_COUNT_CHANGED",
                data: message.data
              });
              console.log(`\u{1F4E4} Sent FOLLOWER_COUNT_CHANGED to Instagram tab ${tab.id}`);
            } catch (error) {
              console.log(`Could not send message to tab ${tab.id}:`, error);
            }
          }
        }
        sendResponse({ success: true });
        break;
      case "UPDATE_USER_INFO":
        console.log("\u{1F4CA} Updating user info:", message.data);
        try {
          await accountSet({ userInfo: message.data });
          console.log("\u{1F4BE} User info stored locally");
          const { userId, apiToken: token } = await chrome.storage.local.get(["userId", "apiToken"]);
          if (!userId || !token) {
            console.warn("\u26A0\uFE0F No authentication found - data stored locally only");
            console.log("\u2139\uFE0F Will be sent to backend on next sync when authenticated");
            sendResponse({ success: true, stored: true, sent: false });
            break;
          }
          console.log("\u{1F510} Authentication found, sending to backend...");
          const response = await fetch(API_BASE + "/api/extension/update-user-info", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({
              followersCount: message.data.followersCount || 0,
              followingCount: message.data.followingCount || 0,
              postsCount: message.data.postsCount || 0,
              bio: message.data.bio || "",
              isPrivate: message.data.isPrivate || false
            })
          });
          if (response.ok) {
            const data = await response.json();
            console.log("\u2705 User info updated successfully:", data);
            const dashboardTabs = await chrome.tabs.query({});
            for (const tab of dashboardTabs) {
              if (tab.url?.startsWith(API_BASE)) {
                try {
                  await chrome.tabs.sendMessage(tab.id, {
                    type: "REFRESH_DASHBOARD",
                    data: { userInfoUpdated: true }
                  });
                  console.log(`\u{1F4E4} Sent refresh notification to dashboard tab ${tab.id}`);
                } catch (error) {
                  console.log(`Could not send message to tab ${tab.id}`);
                }
              }
            }
            sendResponse({ success: true, data });
          } else {
            const error = await response.text();
            console.error("\u274C Failed to update user info:", error);
            sendResponse({ success: false, error });
          }
        } catch (error) {
          console.error("\u274C Error updating user info:", error);
          sendResponse({ success: false, error: String(error) });
        }
        break;
      default:
        console.warn("Unknown message type:", message.type);
    }
  })();
  return true;
});
async function storeDMLocally(message) {
  const stored = await accountGet("dm_messages");
  const messages = stored.dm_messages || [];
  messages.push({
    ...message,
    storedAt: Date.now()
  });
  if (messages.length > 1e3) {
    messages.splice(0, messages.length - 1e3);
  }
  await accountSet({ dm_messages: messages });
}
async function syncDMsToBackend(messages, conversations) {
  try {
    const stored = await chrome.storage.local.get("apiToken");
    if (!stored.apiToken) {
      console.error("No API token found");
      return;
    }
    const response = await fetch(API_BASE + "/api/extension/sync-dms", {
      method: "POST",
      credentials: "include",
      // requireAuth = session cookie du dashboard
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${stored.apiToken}`
      },
      body: JSON.stringify({
        messages,
        conversations
      })
    });
    if (response.ok) {
      const data = await response.json();
      console.log(`\u2705 DMs synced: ${data.insertedMessages} messages, ${data.updatedConversations} conversations`);
    } else {
      console.error("Failed to sync DMs:", response.status);
    }
  } catch (error) {
    console.error("Error syncing DMs:", error);
  }
}
async function getDMConversations() {
  try {
    const stored = await chrome.storage.local.get("apiToken");
    if (!stored.apiToken) {
      return [];
    }
    const response = await fetch(API_BASE + "/api/extension/dm-conversations", {
      headers: {
        "Authorization": `Bearer ${stored.apiToken}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      return data.conversations || [];
    }
  } catch (error) {
    console.error("Error getting DM conversations:", error);
  }
  return [];
}
async function updateContactScore(username, scoreBreakdown, category = "lead", extra) {
  try {
    const stored = await chrome.storage.local.get(["apiToken", "userId"]);
    if (!stored.apiToken) {
      console.error("No API token found");
      return;
    }
    const response = await fetch(API_BASE + "/api/extension/analyze-contact", {
      method: "POST",
      credentials: "include",
      // requireAuth = session cookie du dashboard
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${stored.apiToken}`
      },
      body: JSON.stringify({
        contactUsername: username,
        scoreBreakdown,
        currentCategory: category,
        temperature: extra?.temperature,
        dynamics: extra?.dynamics,
        advice: extra?.advice,
        settingPhase: extra?.settingPhase,
        settingSummary: extra?.settingSummary
      })
    });
    if (response.ok) {
      const data = await response.json();
      console.log(`\u{1F4CA} Score updated for @${username}: ${data.score}/100`);
    } else {
      console.error("Failed to update contact score:", response.status);
    }
  } catch (error) {
    console.error("Error updating contact score:", error);
  }
}
async function refreshProStatus() {
  const current = (await chrome.storage.local.get("isPro")).isPro === true;
  try {
    const response = await fetch(API_BASE + "/api/extension/pro-status", {
      method: "GET",
      credentials: "include"
    });
    if (!response.ok) {
      console.warn("\u26A0\uFE0F refreshProStatus: HTTP", response.status, "\u2014 conserve isPro =", current);
      return current;
    }
    const data = await response.json();
    const isPro = data.isPro === true;
    await chrome.storage.local.set({ isPro, subscriptionTier: data.subscriptionTier ?? null });
    console.log(`\u2705 Statut Pro rafra\xEEchi: isPro=${isPro} (tier: ${data.subscriptionTier ?? "n/a"})`);
    return isPro;
  } catch (error) {
    console.warn("\u26A0\uFE0F refreshProStatus error \u2014 conserve isPro =", current, error);
    return current;
  }
}
async function updateContactName(username, fullName) {
  if (!username || !fullName) return;
  try {
    const response = await fetch(API_BASE + "/api/extension/contact-name", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contactUsername: username, fullName })
    });
    if (!response.ok) {
      console.error("Failed to update contact name:", response.status);
    }
  } catch (error) {
    console.error("Error updating contact name:", error);
  }
}
async function analyzeDMsOnServer(contactUsername) {
  try {
    const response = await fetch(API_BASE + "/api/extension/analyze-dms", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contactUsername })
    });
    if (response.ok) {
      const data = await response.json();
      return typeof data.dmScore === "number" ? data.dmScore : 0;
    }
    console.warn("analyze-dms a r\xE9pondu", response.status);
  } catch (error) {
    console.error("Error analyzing DMs on server:", error);
  }
  return 0;
}
async function createSuggestion(username, transition, scoreBreakdown) {
  try {
    const stored = await chrome.storage.local.get(["apiToken", "userId"]);
    if (!stored.apiToken || !stored.userId) {
      console.error("No API token or user ID found");
      return null;
    }
    const suggestion = await classificationManager.createSuggestion(
      stored.userId,
      username,
      transition.from,
      transition.to,
      scoreBreakdown.total,
      transition.confidence,
      transition.reason,
      transition.evidence || []
    );
    if (suggestion) {
      console.log(`\u{1F4A1} Suggestion created: @${username} ${transition.from} \u2192 ${transition.to}`);
    }
    return suggestion;
  } catch (error) {
    console.error("Error creating suggestion:", error);
    return null;
  }
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url?.includes("instagram.com")) {
    console.log("\u{1F4F1} Instagram tab loaded");
  }
});
console.log("\u2705 Waler Extension background script loaded");
