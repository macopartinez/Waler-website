(() => {
  // src/content/auth-listener.ts
  console.log("\u{1F50C} Waler Auth Listener loaded");
  function checkUrlForAuth() {
    const url = new URL(window.location.href);
    const token = url.searchParams.get("waler_token");
    const userId = url.searchParams.get("waler_user_id");
    if (token && userId) {
      console.log("\u{1F510} Found auth token in URL, forwarding to extension...");
      console.log("User ID:", userId);
      chrome.runtime.sendMessage({
        type: "WALER_AUTH",
        userId: parseInt(userId),
        apiToken: token
      }).then((response) => {
        console.log("\u2705 Auth forwarded to extension successfully");
        console.log("Response from service worker:", response);
        url.searchParams.delete("waler_token");
        url.searchParams.delete("waler_user_id");
        window.history.replaceState({}, "", url.toString());
        console.log("\u{1F9F9} Token removed from URL");
      }).catch((error) => {
        console.error("\u274C Error forwarding auth:", error);
      });
    } else {
      console.log("\u23F3 Waiting for auth token in URL...");
    }
  }
  checkUrlForAuth();
  var lastUrl = window.location.href;
  new MutationObserver(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      checkUrlForAuth();
    }
  }).observe(document, { subtree: true, childList: true });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "REFRESH_DASHBOARD") {
      console.log("\u{1F504} [AuthListener] Relais REFRESH_DASHBOARD \u2192 page");
      window.postMessage({ type: "WALER_REFRESH_DASHBOARD", data: message.data }, "*");
      sendResponse({ success: true });
    } else if (message.type === "REFRESH_PRO_STATS") {
      console.log("\u{1F504} [AuthListener] Relais REFRESH_PRO_STATS \u2192 page");
      window.postMessage({ type: "WALER_REFRESH_PRO_STATS", data: message.data }, "*");
      sendResponse({ success: true });
    }
    return true;
  });
})();
