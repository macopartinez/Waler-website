// src/background/account-storage.ts
var PER_ACCOUNT_KEYS = /* @__PURE__ */ new Set([
  "followerDatabase",
  "followersCache",
  "sessionStats",
  "lastFollowerCount",
  "lastFollowerCountSource",
  "lastFollowerCountAt",
  "lastFollowerCountOwner",
  "userInfo",
  "unfollowerDetected",
  "unfollowerCount",
  "unfollowerDetectedAt",
  "syncQueue",
  "lastNotificationCheck",
  "lastSync",
  "lastFullSync",
  "scanProgress",
  "unfollowerAnalysisProgress",
  "pendingNewFollowerScan",
  "dm_messages"
]);
var ACTIVE_KEY = "activeDsUserId";
var PRIMARY_KEY = "primaryDsUserId";
function nsKey(dsUserId, key) {
  return `acct:${dsUserId}:${key}`;
}
function resolveKey(activeDsUserId, primaryDsUserId, key) {
  if (activeDsUserId && primaryDsUserId && activeDsUserId !== primaryDsUserId && PER_ACCOUNT_KEYS.has(key)) {
    return nsKey(activeDsUserId, key);
  }
  return key;
}
async function getActiveDsUserId() {
  const stored = await chrome.storage.local.get(ACTIVE_KEY);
  return stored[ACTIVE_KEY] ?? null;
}
async function getPrimaryDsUserId() {
  const stored = await chrome.storage.local.get(PRIMARY_KEY);
  return stored[PRIMARY_KEY] ?? null;
}
async function accountGet(keys) {
  const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
  const keyList = Array.isArray(keys) ? keys : [keys];
  const physicalToLogical = /* @__PURE__ */ new Map();
  for (const key of keyList) {
    physicalToLogical.set(resolveKey(active, primary, key), key);
  }
  const physicalKeys = Array.from(physicalToLogical.keys());
  const raw = await chrome.storage.local.get(physicalKeys);
  const out = {};
  for (const [physical, value] of Object.entries(raw)) {
    const logical = physicalToLogical.get(physical) ?? physical;
    out[logical] = value;
  }
  return out;
}

// src/popup/popup-chrome.ts
var ICON_PATHS = {
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .962 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.582a.5.5 0 0 1 0 .962L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.962 0z"/>',
  chart: '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M3 21v-5h5"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  cloud: '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  check: '<path d="M20 6 9 17l-4-4"/>',
  x: '<path d="M18 6 6 18"/><path d="M6 6l12 12"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>'
};
function ic(name, variant = "") {
  const cls = variant ? `ic ic-${variant}` : "ic";
  return `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICON_PATHS[name] || ""}</svg>`;
}
function lbl(name, text, variant = "") {
  return `${ic(name, variant)}<span>${text}</span>`;
}
function loadingLbl(text) {
  return `<span class="spinner-sm" style="width:13px;height:13px;"></span><span>${text}</span>`;
}
async function ensureContentScript(tabId) {
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    if (pong?.ready) return true;
  } catch {
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["injected/page-interceptor.js"],
      world: "MAIN"
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/instagram-tracker.js"]
    });
    return true;
  } catch (error) {
    console.error("Failed to inject content script:", error);
    return false;
  }
}
function hydrateIcons(root = document) {
  root.querySelectorAll("[data-icon]").forEach((el) => {
    const name = el.getAttribute("data-icon") || "";
    const variant = el.getAttribute("data-icon-variant") || "";
    el.innerHTML = ic(name, variant);
  });
}
async function init() {
  try {
    const loading = document.getElementById("loading");
    const notAuthenticated = document.getElementById("not-authenticated");
    const authenticated = document.getElementById("authenticated");
    hydrateIcons();
    const stored = await chrome.storage.local.get(["isAuthenticated", "userId", "lastSync", "isPro"]);
    loading.style.display = "none";
    if (!stored.isAuthenticated) {
      notAuthenticated.style.display = "block";
      setupLoginButton();
    } else {
      authenticated.style.display = "block";
      await loadStats();
      await checkInitialScanStatus();
      await setupAccountSwitcher();
      setupButtons();
      setupSectionTabs();
      initProSection(stored.isPro === true);
      refreshProSection();
      setInterval(loadStats, 3e4);
    }
  } catch (error) {
    console.error("Init error:", error);
    const loading = document.getElementById("loading");
    if (loading) {
      loading.innerHTML = '<div style="color: #ff4444;">Loading error. Check the console.</div>';
    }
  }
}
async function checkInitialScanStatus() {
  try {
    const stored = await accountGet(["followerDatabase", "unfollowerDetected", "unfollowerCount"]);
    const initialScanBtn = document.getElementById("initial-scan-btn");
    const unfollowerAnalysisBtn = document.getElementById("unfollower-analysis-btn");
    const unfollowerAlert = document.getElementById("unfollower-alert");
    const unfollowerCountBadge = document.getElementById("unfollower-count-badge");
    if (!stored.followerDatabase || !stored.followerDatabase.isInitialized) {
      initialScanBtn.style.display = "block";
    } else {
      initialScanBtn.style.display = "none";
    }
    if (stored.unfollowerDetected && stored.unfollowerCount > 0) {
      unfollowerAlert.style.display = "block";
      unfollowerAnalysisBtn.style.display = "block";
      unfollowerCountBadge.textContent = stored.unfollowerCount.toString();
    } else {
      unfollowerAlert.style.display = "none";
      unfollowerAnalysisBtn.style.display = "none";
    }
  } catch (error) {
    console.error("Error checking initial scan status:", error);
  }
}
async function loadStats() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_STATS" });
    if (response && response.success && response.data) {
      const stats = response.data;
      document.getElementById("followers-count").textContent = (stats.followers || 0).toString();
      document.getElementById("unfollowers-count").textContent = (stats.unfollowers || 0).toString();
      document.getElementById("ghost-count").textContent = (stats.ghost || 0).toString();
      document.getElementById("pending-count").textContent = (stats.pendingClassification || 0).toString();
    } else {
      document.getElementById("followers-count").textContent = "0";
      document.getElementById("unfollowers-count").textContent = "0";
      document.getElementById("ghost-count").textContent = "0";
      document.getElementById("pending-count").textContent = "0";
    }
  } catch (error) {
    console.error("Error loading stats:", error);
    document.getElementById("followers-count").textContent = "0";
    document.getElementById("unfollowers-count").textContent = "0";
    document.getElementById("ghost-count").textContent = "0";
    document.getElementById("pending-count").textContent = "0";
  }
  await checkAnalysisStatus();
  const stored = await accountGet("lastSync");
  if (stored.lastSync) {
    const lastSync = new Date(stored.lastSync);
    const now = /* @__PURE__ */ new Date();
    const diffMinutes = Math.floor((now.getTime() - lastSync.getTime()) / 6e4);
    let syncText = "Last sync: ";
    if (diffMinutes < 1) {
      syncText += "Just now";
    } else if (diffMinutes < 60) {
      syncText += `${diffMinutes} min ago`;
    } else {
      const diffHours = Math.floor(diffMinutes / 60);
      syncText += `${diffHours}h ago`;
    }
    document.getElementById("sync-info").textContent = syncText;
  }
}
async function checkAnalysisStatus() {
  try {
    const stored = await chrome.storage.local.get(["unfollowerCheckState", "isAnalyzing"]);
    const analysisIndicator = document.getElementById("analysis-indicator");
    const analysisProgress = document.getElementById("analysis-progress");
    const analysisStatus = document.getElementById("analysis-status");
    if (stored.isAnalyzing || stored.unfollowerCheckState) {
      analysisIndicator.style.display = "block";
      if (stored.unfollowerCheckState) {
        const state = stored.unfollowerCheckState;
        const percentage = Math.round(state.currentIndex / state.missingFollowers.length * 100);
        analysisProgress.textContent = `${percentage}%`;
        analysisStatus.textContent = `Checking ${state.currentIndex}/${state.missingFollowers.length} accounts...`;
      } else {
        analysisProgress.textContent = "0%";
        analysisStatus.textContent = "Initializing...";
      }
    } else {
      analysisIndicator.style.display = "none";
    }
  } catch (error) {
    console.error("Error checking analysis status:", error);
  }
}
function letteredAvatar(seed) {
  const s = encodeURIComponent(seed || "waler");
  return `https://api.dicebear.com/7.x/initials/svg?seed=${s}&backgroundColor=16a34a,15803d,166534&fontWeight=600`;
}
async function setupAccountSwitcher() {
  const currentBtn = document.getElementById("account-current");
  const listEl = document.getElementById("account-list");
  const linkBtn = document.getElementById("account-link-btn");
  linkBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://www.instagram.com/" });
  });
  currentBtn.addEventListener("click", () => {
    const open = listEl.style.display !== "none";
    listEl.style.display = open ? "none" : "block";
    linkBtn.style.display = open ? "none" : "block";
    document.getElementById("account-caret").textContent = open ? "\u25BC" : "\u25B2";
  });
  await renderAccountSwitcher();
}
async function renderAccountSwitcher() {
  const nameEl = document.getElementById("account-current-name");
  const avatarEl = document.getElementById("account-current-avatar");
  const listEl = document.getElementById("account-list");
  nameEl.innerHTML = '<span class="spinner-sm" style="width:13px;height:13px;"></span> Loading\u2026';
  avatarEl.src = letteredAvatar("waler");
  try {
    const resp = await chrome.runtime.sendMessage({ type: "GET_ACCOUNTS" });
    const accountsMap = resp && resp.success ? resp.accounts || {} : {};
    const activeDsUserId = resp?.activeDsUserId || null;
    const accounts = Object.values(accountsMap).filter((a) => !!a.accountId);
    const active = activeDsUserId ? accountsMap[activeDsUserId] : void 0;
    nameEl.textContent = active ? `@${active.igUsername}` : "@\u2014";
    avatarEl.src = letteredAvatar(active?.igUsername || "waler");
    listEl.innerHTML = "";
    if (accounts.length === 0) {
      const empty = document.createElement("div");
      empty.style.cssText = "padding: 10px 12px; font-size: 12px; color: hsl(240,5%,64.9%);";
      empty.textContent = "No linked accounts. Open your Instagram profile to link one.";
      listEl.appendChild(empty);
      return;
    }
    for (const acc of accounts) {
      const isActive = acc.dsUserId === activeDsUserId;
      const row = document.createElement("button");
      row.style.cssText = `width:100%; display:flex; align-items:center; gap:8px; padding:9px 12px; border:none; background:${isActive ? "hsl(240,3.7%,20%)" : "transparent"}; color:hsl(0,0%,98%); cursor:pointer; font-family:inherit; text-align:left;`;
      row.innerHTML = `
        <img src="${letteredAvatar(acc.igUsername)}" style="width:22px;height:22px;border-radius:50%;object-fit:cover;background:hsl(240,3.7%,25%);" />
        <span style="flex:1;min-width:0;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">@${acc.igUsername}</span>
        ${isActive ? '<span style="font-size:11px;color:hsl(142,70%,55%);">\u25CF active</span>' : ""}
      `;
      if (!isActive) {
        row.addEventListener("click", () => switchAccount(acc.dsUserId, row));
      }
      listEl.appendChild(row);
    }
  } catch (error) {
    console.error("Error rendering account switcher:", error);
    nameEl.textContent = "@\u2014";
  }
}
async function switchAccount(dsUserId, row) {
  const listEl = document.getElementById("account-list");
  if (row) {
    row.style.pointerEvents = "none";
    listEl.style.opacity = "0.6";
    const marker = document.createElement("span");
    marker.className = "spinner-sm";
    marker.style.cssText = "width:14px;height:14px;";
    row.appendChild(marker);
  }
  try {
    await chrome.runtime.sendMessage({ type: "SET_ACTIVE_ACCOUNT", dsUserId });
    await renderAccountSwitcher();
    await loadStats();
    await checkInitialScanStatus();
    await refreshProSection();
    peopleLoaded = false;
  } catch (error) {
    console.error("Error switching account:", error);
  } finally {
    listEl.style.opacity = "1";
    listEl.style.display = "none";
    document.getElementById("account-link-btn").style.display = "none";
    document.getElementById("account-caret").textContent = "\u25BC";
  }
}
function setupSectionTabs() {
  const tabBase = document.getElementById("tab-base");
  const tabPro = document.getElementById("tab-pro");
  const baseSection = document.getElementById("base-section");
  const proSection = document.getElementById("pro-section");
  const activate = (which) => {
    const baseActive = which === "base";
    baseSection.style.display = baseActive ? "block" : "none";
    proSection.style.display = baseActive ? "none" : "block";
    tabBase.style.background = baseActive ? "hsl(240, 3.7%, 20%)" : "transparent";
    tabBase.style.color = baseActive ? "hsl(0,0%,98%)" : "hsl(240,5%,64.9%)";
    tabPro.style.background = baseActive ? "transparent" : "hsl(240, 3.7%, 20%)";
    tabPro.style.color = baseActive ? "hsl(240,5%,64.9%)" : "hsl(0,0%,98%)";
  };
  tabBase.addEventListener("click", () => activate("base"));
  tabPro.addEventListener("click", () => {
    activate("pro");
    loadPeople();
  });
}
function initProSection(isPro) {
  const upsell = document.getElementById("pro-upsell");
  const content = document.getElementById("pro-content");
  if (isPro) {
    upsell.style.display = "none";
    content.style.display = "block";
    const refreshBtn = document.getElementById("pro-refresh-btn");
    if (refreshBtn) refreshBtn.onclick = () => loadPeople(true);
    const engagementBtn = document.getElementById("pro-engagement-btn");
    if (engagementBtn) engagementBtn.onclick = () => startProEngagement(engagementBtn);
    void populateProAccountSelect();
  } else {
    upsell.style.display = "block";
    content.style.display = "none";
    const upgradeBtn = document.getElementById("upgrade-pro-btn");
    if (upgradeBtn) upgradeBtn.onclick = () => {
      chrome.tabs.create({ url: "https://waler.website/upgrade-to-pro" });
    };
  }
}
async function refreshProSection() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: "REFRESH_PRO_STATUS" });
    if (resp && resp.success) initProSection(resp.isPro === true);
  } catch {
  }
}
var peopleLoaded = false;
var peopleLoading = false;
var proSelectedUsername = null;
var PRO_ACCOUNT_KEY = "proSelectedAccount";
async function populateProAccountSelect() {
  const select = document.getElementById("pro-account-select");
  if (!select) return;
  try {
    const resp = await chrome.runtime.sendMessage({ type: "GET_ACCOUNTS" });
    const accountsMap = resp && resp.success ? resp.accounts || {} : {};
    const activeDsUserId = resp?.activeDsUserId || null;
    const accounts = Object.values(accountsMap).filter((a) => !!a.igUsername);
    const stored = await chrome.storage.local.get(PRO_ACCOUNT_KEY);
    const activeUser = activeDsUserId ? accountsMap[activeDsUserId]?.igUsername : void 0;
    const initial = stored[PRO_ACCOUNT_KEY] || activeUser || accounts[0]?.igUsername || "";
    proSelectedUsername = initial || null;
    select.innerHTML = "";
    if (accounts.length === 0) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "Active account";
      select.appendChild(opt);
    } else {
      for (const acc of accounts) {
        const opt = document.createElement("option");
        opt.value = acc.igUsername;
        opt.textContent = `@${acc.igUsername}`;
        if (acc.igUsername === initial) opt.selected = true;
        select.appendChild(opt);
      }
    }
    select.onchange = async () => {
      proSelectedUsername = select.value || null;
      await chrome.storage.local.set({ [PRO_ACCOUNT_KEY]: select.value });
      await loadPeople(true);
    };
  } catch (error) {
    console.error("Error populating pro account select:", error);
  }
}
async function loadPeople(force = false) {
  const loadingEl = document.getElementById("pro-people-loading");
  const emptyEl = document.getElementById("pro-people-empty");
  const listEl = document.getElementById("pro-people-list");
  if (peopleLoaded && !force) return;
  if (peopleLoading) return;
  peopleLoading = true;
  loadingEl.style.display = "flex";
  emptyEl.style.display = "none";
  listEl.style.display = "none";
  listEl.innerHTML = "";
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_PEOPLE", username: proSelectedUsername || void 0 });
    peopleLoaded = true;
    loadingEl.style.display = "none";
    const people = response && response.success && Array.isArray(response.people) ? response.people : [];
    if (people.length === 0) {
      emptyEl.style.display = "block";
      return;
    }
    listEl.style.display = "flex";
    for (const person of people) {
      listEl.appendChild(renderPersonRow(person));
    }
  } catch (error) {
    console.error("Error loading people:", error);
    loadingEl.style.display = "none";
    emptyEl.style.display = "block";
  } finally {
    peopleLoading = false;
  }
}
function renderPersonRow(person) {
  const username = person.memberUsername || person.username || "";
  const fullName = person.fullName || "";
  const score = typeof person.relationshipScore === "number" ? person.relationshipScore : null;
  const row = document.createElement("div");
  row.style.cssText = "display:flex; align-items:center; justify-content:space-between; gap:8px; background: hsl(240,3.7%,15.9%); border:1px solid hsl(240,3.7%,20%); border-radius:10px; padding:10px 12px;";
  const info = document.createElement("div");
  info.style.cssText = "min-width:0; flex:1;";
  info.innerHTML = `
    <div style="font-size:13px; font-weight:600; color:hsl(0,0%,98%); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">@${username}</div>
    <div style="font-size:11px; color:hsl(240,5%,64.9%); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${fullName}${score !== null ? ` \xB7 score ${score}/100` : ""}</div>
  `;
  const btn = document.createElement("button");
  btn.className = "btn btn-primary";
  btn.style.cssText = "padding:8px 10px; font-size:12px; white-space:nowrap; flex-shrink:0;";
  btn.innerHTML = lbl("search", "Analyze");
  btn.addEventListener("click", () => startProAnalysis(username, fullName, btn));
  row.appendChild(info);
  row.appendChild(btn);
  return row;
}
async function startProAnalysis(username, fullName, btn) {
  const originalHtml = btn.innerHTML;
  btn.setAttribute("disabled", "true");
  btn.style.opacity = "0.6";
  btn.innerHTML = '<span class="spinner-sm" style="width:13px;height:13px;"></span>';
  try {
    const instagramTabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
    if (instagramTabs.length === 0 || !instagramTabs[0]?.id) {
      btn.innerHTML = lbl("x", "Open Instagram");
      setTimeout(() => {
        btn.innerHTML = originalHtml;
        btn.removeAttribute("disabled");
        btn.style.opacity = "1";
      }, 3e3);
      return;
    }
    await ensureContentScript(instagramTabs[0].id);
    await chrome.tabs.sendMessage(instagramTabs[0].id, {
      type: "START_PRO_CONVERSATION_ANALYSIS",
      username,
      fullName
    });
    btn.innerHTML = lbl("check", "Started!");
    void chrome.runtime.sendMessage({ type: "PERSON_CLASSIFIED" });
    await chrome.tabs.update(instagramTabs[0].id, { active: true });
    setTimeout(() => {
      window.close();
    }, 800);
  } catch (error) {
    console.error("Error starting pro analysis:", error);
    btn.innerHTML = lbl("x", "Error");
    setTimeout(() => {
      btn.innerHTML = originalHtml;
      btn.removeAttribute("disabled");
      btn.style.opacity = "1";
    }, 3e3);
  }
}
async function startProEngagement(btn) {
  const originalHtml = btn.innerHTML;
  btn.setAttribute("disabled", "true");
  btn.style.opacity = "0.6";
  btn.innerHTML = loadingLbl("Analyzing...");
  try {
    const instagramTabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
    if (instagramTabs.length === 0 || !instagramTabs[0]?.id) {
      btn.innerHTML = lbl("x", "Open Instagram");
      setTimeout(() => {
        btn.innerHTML = originalHtml;
        btn.removeAttribute("disabled");
        btn.style.opacity = "1";
      }, 3e3);
      return;
    }
    await ensureContentScript(instagramTabs[0].id);
    await chrome.tabs.sendMessage(instagramTabs[0].id, { type: "START_PRO_ENGAGEMENT_ANALYSIS" });
    btn.innerHTML = lbl("check", "Started!");
    await chrome.tabs.update(instagramTabs[0].id, { active: true });
    setTimeout(() => {
      window.close();
    }, 800);
  } catch (error) {
    console.error("Error starting pro engagement:", error);
    btn.innerHTML = lbl("x", "Error");
    setTimeout(() => {
      btn.innerHTML = originalHtml;
      btn.removeAttribute("disabled");
      btn.style.opacity = "1";
    }, 3e3);
  }
}
function setupLoginButton() {
  const loginBtn = document.getElementById("login-btn");
  loginBtn.addEventListener("click", () => {
    chrome.tabs.create({
      url: "https://waler.website/extension-auth"
    });
  });
}
function setupButtons() {
  const initialScanBtn = document.getElementById("initial-scan-btn");
  const unfollowerAnalysisBtn = document.getElementById("unfollower-analysis-btn");
  const syncBtn = document.getElementById("sync-btn");
  const syncFullBtn = document.getElementById("sync-full-btn");
  const restoreDbBtn = document.getElementById("restore-db-btn");
  const dashboardBtn = document.getElementById("dashboard-btn");
  const resetStatsBtn = document.getElementById("reset-stats-btn");
  let isSyncing = false;
  let isAnalyzing = false;
  let isFullSyncing = false;
  resetStatsBtn.addEventListener("click", async () => {
    if (confirm("Are you sure you want to reset the session statistics?")) {
      try {
        await chrome.runtime.sendMessage({ type: "RESET_STATS" });
        await loadStats();
        console.log("\u2705 Stats r\xE9initialis\xE9es");
      } catch (error) {
        console.error("Error resetting stats:", error);
      }
    }
  });
  syncFullBtn.addEventListener("click", async () => {
    if (isFullSyncing) {
      console.log("\u23F3 Synchronisation compl\xE8te d\xE9j\xE0 en cours...");
      return;
    }
    isFullSyncing = true;
    const originalHtml = syncFullBtn.innerHTML;
    syncFullBtn.innerHTML = loadingLbl("Syncing...");
    syncFullBtn.setAttribute("disabled", "true");
    syncFullBtn.style.opacity = "0.6";
    try {
      const response = await chrome.runtime.sendMessage({ type: "SYNC_FULL_DATABASE" });
      if (response.success) {
        syncFullBtn.innerHTML = lbl("check", `${response.synced} followers synced!`);
        console.log("\u2705 Full sync successful:", response);
        setTimeout(() => {
          syncFullBtn.innerHTML = originalHtml;
          syncFullBtn.removeAttribute("disabled");
          syncFullBtn.style.opacity = "1";
          isFullSyncing = false;
        }, 3e3);
      } else {
        syncFullBtn.innerHTML = lbl("x", "Sync error");
        console.error("\u274C Full sync failed:", response.error);
        setTimeout(() => {
          syncFullBtn.innerHTML = originalHtml;
          syncFullBtn.removeAttribute("disabled");
          syncFullBtn.style.opacity = "1";
          isFullSyncing = false;
        }, 3e3);
      }
    } catch (error) {
      console.error("Error during full sync:", error);
      syncFullBtn.innerHTML = lbl("x", "Error");
      setTimeout(() => {
        syncFullBtn.innerHTML = originalHtml;
        syncFullBtn.removeAttribute("disabled");
        syncFullBtn.style.opacity = "1";
        isFullSyncing = false;
      }, 3e3);
    }
  });
  restoreDbBtn.addEventListener("click", async () => {
    const originalHtml = restoreDbBtn.innerHTML;
    restoreDbBtn.innerHTML = loadingLbl("Restoring...");
    restoreDbBtn.setAttribute("disabled", "true");
    restoreDbBtn.style.opacity = "0.6";
    const reset = (html) => {
      restoreDbBtn.innerHTML = html;
      setTimeout(() => {
        restoreDbBtn.innerHTML = originalHtml;
        restoreDbBtn.removeAttribute("disabled");
        restoreDbBtn.style.opacity = "1";
      }, 3e3);
    };
    try {
      const instagramTabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
      if (instagramTabs.length === 0 || !instagramTabs[0]?.id) {
        reset(lbl("x", "Open Instagram first"));
        return;
      }
      await ensureContentScript(instagramTabs[0].id);
      const response = await chrome.tabs.sendMessage(instagramTabs[0].id, {
        type: "RESTORE_FROM_BACKEND"
      });
      if (response?.success) {
        await loadStats();
        reset(lbl("check", `${response.count ?? 0} followers restored!`));
      } else {
        reset(lbl("info", "No data to restore"));
      }
    } catch (error) {
      console.error("Error restoring database:", error);
      reset(lbl("x", "Error"));
    }
  });
  initialScanBtn.addEventListener("click", async () => {
    initialScanBtn.innerHTML = loadingLbl("Scanning...");
    initialScanBtn.setAttribute("disabled", "true");
    initialScanBtn.style.opacity = "0.6";
    try {
      const instagramTabs = await chrome.tabs.query({ url: "*://www.instagram.com/*" });
      if (instagramTabs.length === 0 || !instagramTabs[0]?.id) {
        initialScanBtn.innerHTML = lbl("x", "Open Instagram first");
        initialScanBtn.removeAttribute("disabled");
        initialScanBtn.style.opacity = "1";
        return;
      }
      await ensureContentScript(instagramTabs[0].id);
      await chrome.tabs.sendMessage(instagramTabs[0].id, { type: "START_INITIAL_SCAN" });
      initialScanBtn.innerHTML = lbl("check", "Scan started!");
      setTimeout(() => {
        initialScanBtn.style.display = "none";
      }, 2e3);
    } catch (error) {
      console.error("Error starting initial scan:", error);
      initialScanBtn.innerHTML = lbl("x", "Error - Open Instagram");
      initialScanBtn.removeAttribute("disabled");
      initialScanBtn.style.opacity = "1";
    }
  });
  unfollowerAnalysisBtn.addEventListener("click", async () => {
    if (isAnalyzing) {
      console.log("\u23F3 Analyse d\xE9j\xE0 en cours...");
      return;
    }
    isAnalyzing = true;
    unfollowerAnalysisBtn.innerHTML = loadingLbl("Analyzing...");
    unfollowerAnalysisBtn.setAttribute("disabled", "true");
    unfollowerAnalysisBtn.style.opacity = "0.6";
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const currentTab = tabs[0];
      if (!currentTab?.url?.includes("instagram.com")) {
        alert("Please open Instagram in the active tab to start the analysis.");
        unfollowerAnalysisBtn.innerHTML = lbl("search", "Analyze unfollowers");
        unfollowerAnalysisBtn.removeAttribute("disabled");
        unfollowerAnalysisBtn.style.opacity = "1";
        isAnalyzing = false;
        return;
      }
      if (currentTab.id) {
        await ensureContentScript(currentTab.id);
        await chrome.tabs.sendMessage(currentTab.id, { type: "START_UNFOLLOWER_ANALYSIS" });
      }
      unfollowerAnalysisBtn.innerHTML = lbl("check", "Analysis started!");
      setTimeout(() => {
        unfollowerAnalysisBtn.style.display = "none";
        document.getElementById("unfollower-alert").style.display = "none";
        isAnalyzing = false;
      }, 2e3);
    } catch (error) {
      console.error("Error starting unfollower analysis:", error);
      unfollowerAnalysisBtn.innerHTML = lbl("x", "Error");
      unfollowerAnalysisBtn.removeAttribute("disabled");
      unfollowerAnalysisBtn.style.opacity = "1";
      isAnalyzing = false;
    }
  });
  syncBtn.addEventListener("click", async () => {
    if (isSyncing) {
      console.log("\u23F3 Synchronisation d\xE9j\xE0 en cours...");
      return;
    }
    isSyncing = true;
    syncBtn.innerHTML = loadingLbl("Syncing...");
    syncBtn.setAttribute("disabled", "true");
    syncBtn.style.opacity = "0.6";
    syncBtn.style.cursor = "not-allowed";
    try {
      syncBtn.innerHTML = loadingLbl("Checking notifications...");
      await chrome.runtime.sendMessage({ type: "CHECK_NOTIFICATIONS" });
      syncBtn.innerHTML = loadingLbl("Syncing...");
      await chrome.runtime.sendMessage({ type: "SYNC_NOW" });
      await loadStats();
      syncBtn.innerHTML = lbl("check", "Synced");
      setTimeout(() => {
        syncBtn.textContent = "Sync now";
        syncBtn.removeAttribute("disabled");
        syncBtn.style.opacity = "1";
        syncBtn.style.cursor = "pointer";
        isSyncing = false;
      }, 3e3);
    } catch (error) {
      console.error("Sync error:", error);
      syncBtn.innerHTML = lbl("x", "Error");
      setTimeout(() => {
        syncBtn.textContent = "Sync now";
        syncBtn.removeAttribute("disabled");
        syncBtn.style.opacity = "1";
        syncBtn.style.cursor = "pointer";
        isSyncing = false;
      }, 2e3);
    }
  });
  dashboardBtn.addEventListener("click", async () => {
    const stored = await chrome.storage.local.get("userId");
    chrome.tabs.create({
      url: `https://waler.website/dashboard/${stored.userId}`
    });
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "ANALYSIS_COMPLETED") {
    console.log("\u2705 Analysis completed, refreshing stats...", message.data);
    loadStats().then(() => {
      console.log("\u{1F4CA} Stats refreshed after analysis completion");
    });
    const analysisIndicator = document.getElementById("analysis-indicator");
    if (analysisIndicator) {
      analysisIndicator.style.display = "none";
    }
    sendResponse({ success: true });
  }
  return true;
});
init();
