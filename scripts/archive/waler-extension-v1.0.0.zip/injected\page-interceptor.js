(() => {
  // src/injected/page-interceptor.ts
  (function() {
    const SOURCE = "WALER_PAGE_INTERCEPTOR";
    if (window.__walerInterceptorInstalled) {
      return;
    }
    window.__walerInterceptorInstalled = true;
    console.log("\u{1F50C} [MAIN] Waler page interceptor installed");
    const RELEVANT_URL_PATTERNS = [
      "/graphql/query",
      "/api/v1/users/",
      "web_profile_info",
      "followers",
      "following"
    ];
    function isRelevantUrl(url) {
      if (!url) return false;
      return RELEVANT_URL_PATTERNS.some((pattern) => url.includes(pattern));
    }
    function postToContentScript(url, data) {
      try {
        window.postMessage(
          {
            source: SOURCE,
            type: "API_RESPONSE",
            url,
            data
          },
          "*"
        );
      } catch (e) {
      }
    }
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
      const response = await originalFetch.apply(this, args);
      try {
        let url = "";
        const input = args[0];
        if (typeof input === "string") {
          url = input;
        } else if (input instanceof Request) {
          url = input.url;
        } else if (input && typeof input.url === "string") {
          url = input.url;
        }
        if (isRelevantUrl(url)) {
          response.clone().json().then((data) => postToContentScript(url, data)).catch(() => {
          });
        }
      } catch (e) {
      }
      return response;
    };
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__walerUrl = url;
      return originalOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      const xhr = this;
      const url = xhr.__walerUrl || "";
      if (isRelevantUrl(url)) {
        xhr.addEventListener("load", function() {
          try {
            const contentType = xhr.getResponseHeader("content-type") || "";
            if (contentType.includes("application/json") || xhr.responseType === "" || xhr.responseType === "text") {
              const text = xhr.responseText;
              if (text) {
                const data = JSON.parse(text);
                postToContentScript(url, data);
              }
            }
          } catch (e) {
          }
        });
      }
      return originalSend.apply(this, args);
    };
  })();
})();
