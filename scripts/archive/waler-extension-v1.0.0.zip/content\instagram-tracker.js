(() => {
  // src/content/dom-observer.ts
  var DOMObserver = class {
    constructor() {
      this.observers = [];
      this.callbacks = {};
    }
    onProfileVisit(callback) {
      this.callbacks.onProfileVisit = callback;
    }
    onFollowerDetected(callback) {
      this.callbacks.onFollowerDetected = callback;
    }
    onUnfollowerDetected(callback) {
      this.callbacks.onUnfollowerDetected = callback;
    }
    onEngagement(callback) {
      this.callbacks.onEngagement = callback;
    }
    start() {
      this.observeDOM();
      this.observeClicks();
      this.observeURLChanges();
      this.observeFollowersModal();
      console.log("\u{1F440} DOM observation started");
    }
    stop() {
      this.observers.forEach((observer) => observer.disconnect());
      this.observers = [];
      console.log("\u{1F6D1} DOM observation stopped");
    }
    observeDOM() {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.processNode(node);
            }
          });
        });
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      this.observers.push(observer);
    }
    processNode(node) {
      if (this.isFollowerElement(node)) {
        console.log("\u{1F464} Follower element detected in DOM");
        const followerData = this.extractFollowerData(node);
        if (followerData) {
          console.log(`\u{1F4E6} Follower data extracted: @${followerData.username}`);
          if (this.callbacks.onFollowerDetected) {
            this.callbacks.onFollowerDetected(followerData);
          }
        } else {
          console.log("\u274C Failed to extract follower data");
        }
      }
    }
    observeClicks() {
      document.addEventListener("click", (event) => {
        const target = event.target;
        const link = target.closest('a[href^="/"]');
        if (link) {
          const href = link.getAttribute("href");
          if (href && href.startsWith("/direct/t/")) {
            console.log("\u{1F50D} DM conversation link clicked");
            setTimeout(() => {
              const headerLink = document.querySelector('header a[href^="/"]');
              if (headerLink) {
                const profileHref = headerLink.getAttribute("href");
                const username = profileHref?.match(/^\/([a-zA-Z0-9._]+)\/?$/)?.[1];
                if (username && this.callbacks.onProfileVisit) {
                  console.log("\u2705 DM username extracted:", username);
                  this.callbacks.onProfileVisit(username);
                }
              }
            }, 600);
          } else if (href && this.isProfileLink(href)) {
            const username = this.extractUsernameFromLink(href);
            if (username && this.callbacks.onProfileVisit) {
              this.callbacks.onProfileVisit(username);
            }
          }
        }
        if (target.closest('[aria-label*="Like"]') || target.closest(`[aria-label*="J'aime"]`)) {
          this.trackEngagement("like", target);
        } else if (target.closest('[aria-label*="Comment"]') || target.closest('[aria-label*="Commenter"]')) {
          this.trackEngagement("comment", target);
        } else if (target.closest('[aria-label*="Share"]') || target.closest('[aria-label*="Partager"]')) {
          this.trackEngagement("share", target);
        } else if (target.closest('[aria-label*="Save"]') || target.closest('[aria-label*="Enregistrer"]')) {
          this.trackEngagement("save", target);
        }
      }, true);
    }
    observeFollowersModal() {
      let scanTimeout = null;
      const modalObserver = new MutationObserver(() => {
        const modal = document.querySelector('[role="dialog"]');
        if (modal) {
          const currentPath = window.location.pathname;
          const isProfilePage = /^\/[a-zA-Z0-9._]+\/?$/.test(currentPath);
          if (!isProfilePage) {
            console.log("\u{1F6AB} Ignoring modal: not on profile page (path: " + currentPath + ")");
            return;
          }
          const profileLinks = modal.querySelectorAll('a[href^="/"]');
          if (profileLinks.length < 3) {
            console.log("\u{1F6AB} Ignoring modal: not enough profile links (" + profileLinks.length + ")");
            return;
          }
          console.log("\u{1F4CB} Followers modal detected, waiting for content to load...");
          if (scanTimeout) {
            clearTimeout(scanTimeout);
          }
          scanTimeout = setTimeout(() => {
            console.log("\u{1F50D} Modal content should be loaded, scanning now...");
            this.scanFollowersInModal(modal);
          }, 2e3);
        }
      });
      modalObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      this.observers.push(modalObserver);
    }
    scanFollowersInModal(modal) {
      try {
        console.log(`\u{1F50D} Scanning followers modal...`);
        const allLinks = modal.querySelectorAll('a[href^="/"]');
        console.log(`\u{1F4CA} Total links found: ${allLinks.length}`);
        if (allLinks.length === 0) {
          console.warn("\u26A0\uFE0F No links found in modal, aborting scan");
          return;
        }
        let profileCount = 0;
        const maxProfiles = 1;
        for (const link of Array.from(allLinks)) {
          try {
            const href = link.getAttribute("href");
            if (href) {
              const usernameMatch = href.match(/^\/([a-zA-Z0-9._]+)\/?(\?.*)?$/);
              if (usernameMatch) {
                const username = usernameMatch[1];
                const systemPages = ["explore", "reels", "direct", "p", "stories", "tv", "accounts"];
                if (!systemPages.includes(username)) {
                  profileCount++;
                  console.log(`\u{1F464} Profile #${profileCount}: @${username}`);
                  if (profileCount === maxProfiles) {
                    console.log(`\u2705 First follower in list: @${username}`);
                    const parent = link.closest("div");
                    const img = parent?.querySelector("img");
                    const avatarUrl = img?.getAttribute("src") || void 0;
                    if (this.callbacks.onFollowerDetected) {
                      this.callbacks.onFollowerDetected({ username, avatarUrl });
                    }
                    return;
                  }
                }
              }
            }
          } catch (error) {
            console.warn("\u26A0\uFE0F Could not extract username from element:", error);
            continue;
          }
        }
        if (profileCount === 0) {
          console.log(`\u{1F6AB} No valid profiles found in modal`);
        } else {
          console.log(`\u26A0\uFE0F Only found ${profileCount} profile(s), expected at least ${maxProfiles}`);
        }
      } catch (error) {
        console.error("\u274C Failed to scan followers modal:", error);
      }
    }
    observeURLChanges() {
      let lastUrl = window.location.href;
      const urlObserver = new MutationObserver(() => {
        const currentUrl = window.location.href;
        if (currentUrl !== lastUrl) {
          lastUrl = currentUrl;
          if (currentUrl.includes("/direct/t/")) {
            setTimeout(() => {
              const headerLink = document.querySelector('header a[href^="/"]');
              if (headerLink) {
                const href = headerLink.getAttribute("href");
                const username = href?.match(/^\/([a-zA-Z0-9._]+)\/?$/)?.[1];
                if (username && this.callbacks.onProfileVisit) {
                  this.callbacks.onProfileVisit(username);
                }
              }
            }, 500);
          } else {
            const match = currentUrl.match(/instagram\.com\/([a-zA-Z0-9._]+)\/?$/);
            if (match && this.callbacks.onProfileVisit) {
              const username = match[1];
              if (username !== "explore" && username !== "reels" && username !== "direct") {
                this.callbacks.onProfileVisit(username);
              }
            }
          }
        }
      });
      urlObserver.observe(document, { subtree: true, childList: true });
      this.observers.push(urlObserver);
    }
    trackEngagement(action, element) {
      const postElement = element.closest("article");
      const postId = this.extractPostId(postElement);
      if (this.callbacks.onEngagement) {
        this.callbacks.onEngagement({
          type: action,
          postId,
          timestamp: Date.now()
        });
      }
    }
    isProfileLink(href) {
      return /^\/[a-zA-Z0-9._]+\/?$/.test(href) && !href.includes("/explore") && !href.includes("/reels") && !href.includes("/p/");
    }
    extractUsernameFromLink(href) {
      const match = href.match(/^\/([a-zA-Z0-9._]+)/);
      return match ? match[1] : null;
    }
    isFollowerElement(element) {
      return element.querySelector('a[href^="/"]') !== null && element.querySelector('img[alt*="photo"]') !== null;
    }
    extractFollowerData(element) {
      const links = element.querySelectorAll('a[href^="/"]');
      let username = null;
      let avatarUrl = void 0;
      for (const link of Array.from(links)) {
        const href = link.getAttribute("href");
        if (href && this.isProfileLink(href)) {
          username = this.extractUsernameFromLink(href);
          if (username) break;
        }
      }
      if (!username) {
        const spans = element.querySelectorAll("span");
        for (const span of Array.from(spans)) {
          const text = span.textContent?.trim();
          if (text && /^[a-zA-Z0-9._]+$/.test(text) && text.length > 0 && text.length < 30) {
            username = text;
            break;
          }
        }
      }
      const img = element.querySelector("img");
      if (img) {
        avatarUrl = img.getAttribute("src") || void 0;
      }
      if (!username) {
        console.log("\u26A0\uFE0F Could not extract username from element:", element.innerHTML.substring(0, 200));
        return null;
      }
      return { username, avatarUrl };
    }
    extractPostId(element) {
      if (!element) return null;
      const link = element.querySelector('a[href*="/p/"]');
      if (!link) return null;
      const href = link.getAttribute("href");
      const match = href?.match(/\/p\/([^\/]+)/);
      return match ? match[1] : null;
    }
  };

  // src/content/data-collector.ts
  var DataCollector = class {
    constructor() {
      this.profileVisits = /* @__PURE__ */ new Map();
      this.engagements = [];
      this.trackedUsername = null;
    }
    setTrackedUsername(username) {
      this.trackedUsername = username;
    }
    trackProfileVisit(username) {
      const count = this.profileVisits.get(username) || 0;
      this.profileVisits.set(username, count + 1);
      console.log(`\u{1F464} Profile visit: @${username} (${count + 1} times)`);
    }
    trackEngagement(engagement) {
      this.engagements.push({
        ...engagement,
        timestamp: Date.now()
      });
      console.log(`\u{1F4AB} Engagement tracked:`, engagement.type);
      if (this.engagements.length >= 20) {
        this.flushEngagements();
      }
    }
    processFollowersData(data) {
      console.log("\u{1F4CA} Processing followers data from API");
      try {
        if (data?.data?.user?.edge_followed_by?.edges) {
          const followers = data.data.user.edge_followed_by.edges.map((edge) => ({
            username: edge.node.username,
            fullName: edge.node.full_name,
            avatarUrl: edge.node.profile_pic_url,
            isVerified: edge.node.is_verified
          }));
          console.log(`Found ${followers.length} followers in API response`);
        }
      } catch (error) {
        console.error("Error processing followers data:", error);
      }
    }
    processFollowingData(data) {
      console.log("\u{1F4CA} Processing following data from API");
      try {
        if (data?.data?.user?.edge_follow?.edges) {
          const following = data.data.user.edge_follow.edges.map((edge) => ({
            username: edge.node.username,
            fullName: edge.node.full_name,
            avatarUrl: edge.node.profile_pic_url,
            isVerified: edge.node.is_verified
          }));
          console.log(`Found ${following.length} following in API response`);
        }
      } catch (error) {
        console.error("Error processing following data:", error);
      }
    }
    async processUserInfo(data) {
      try {
        const user = data?.data?.user || data?.user;
        if (!user) return;
        const followersCount = user.edge_followed_by?.count ?? user.follower_count ?? void 0;
        if (typeof followersCount !== "number") {
          return;
        }
        const userInfo = {
          username: user.username,
          fullName: user.full_name,
          bio: user.biography,
          followersCount,
          followingCount: user.edge_follow?.count ?? user.following_count ?? 0,
          postsCount: user.edge_owner_to_timeline_media?.count ?? user.media_count ?? 0,
          isPrivate: user.is_private,
          isVerified: user.is_verified
        };
        if (this.trackedUsername && userInfo.username && userInfo.username !== this.trackedUsername) {
          return;
        }
        console.log("\u{1F4CA} Processing user info from API:", userInfo.username, "\u2192", followersCount, "followers");
        chrome.runtime.sendMessage({
          type: "UPDATE_USER_INFO",
          data: userInfo
        });
        await this.checkFollowerCountChange(followersCount);
      } catch (error) {
        console.error("Error processing user info:", error);
      }
    }
    async checkFollowerCountChange(newCount) {
      try {
        const stored = await chrome.storage.local.get(["followerDatabase", "lastFollowerCount"]);
        let oldCount = stored.lastFollowerCount || 0;
        if (oldCount === 0 && stored.followerDatabase) {
          oldCount = Object.keys(stored.followerDatabase.followers || {}).length;
        }
        if (newCount !== oldCount && oldCount > 0) {
          const diff = newCount - oldCount;
          console.log(`\u{1F514} [API] Follower count changed: ${oldCount} \u2192 ${newCount} (${diff > 0 ? "+" : ""}${diff})`);
          await chrome.storage.local.set({ lastFollowerCount: newCount });
          console.log(`\u{1F4BE} Updated lastFollowerCount to ${newCount}`);
          if (stored.followerDatabase) {
            stored.followerDatabase.totalCount = newCount;
            await chrome.storage.local.set({ followerDatabase: stored.followerDatabase });
            console.log(`\u{1F4BE} Updated followerDatabase.totalCount to ${newCount} (real count)`);
          }
          chrome.runtime.sendMessage({
            type: "FOLLOWER_COUNT_CHANGED",
            data: {
              oldCount,
              newCount,
              diff
            }
          });
          if (diff > 0) {
            console.log(`\u2728 ${diff} nouveau(x) follower(s) d\xE9tect\xE9(s) ! Ouvrez le modal des followers pour les identifier.`);
          }
        } else if (oldCount === 0) {
          console.log(`\u{1F4CA} [API] Initial follower count detected: ${newCount}`);
          await chrome.storage.local.set({ lastFollowerCount: newCount });
          if (stored.followerDatabase) {
            stored.followerDatabase.totalCount = newCount;
            await chrome.storage.local.set({ followerDatabase: stored.followerDatabase });
            console.log(`\u{1F4BE} Initialized followerDatabase.totalCount to ${newCount} (real count)`);
          }
        }
      } catch (error) {
        console.error("Error checking follower count change:", error);
      }
    }
    async flushEngagements() {
      if (this.engagements.length === 0) return;
      console.log(`\u{1F4E4} Flushing ${this.engagements.length} engagements`);
      for (const engagement of this.engagements) {
        await chrome.runtime.sendMessage({
          type: "TRACK_ENGAGEMENT",
          data: engagement
        });
      }
      this.engagements = [];
    }
    async getStats() {
      return {
        profileVisits: Object.fromEntries(this.profileVisits),
        pendingEngagements: this.engagements.length
      };
    }
  };

  // src/content/dm-interceptor.ts
  var DMInterceptor = class {
    constructor() {
    }
    init() {
    }
    getDMMessages() {
      return [];
    }
  };

  // src/content/dm-analyzer.ts
  var PROSPECT_KEYWORDS = [
    "prix",
    "tarif",
    "tarifs",
    "devis",
    "combien",
    "co\xFBte",
    "cout",
    "dispo",
    "disponible",
    "int\xE9ress\xE9",
    "interesse",
    "int\xE9ress\xE9e",
    "acheter",
    "commander",
    "commande",
    "r\xE9server",
    "reserver",
    "info",
    "infos",
    "renseignement",
    "catalogue",
    "offre",
    "promo",
    "price",
    "cost",
    "quote",
    "available",
    "interested",
    "buy",
    "order",
    "booking",
    "how much"
  ];
  var CLIENT_KEYWORDS = [
    "pay\xE9",
    "paye",
    "paiement",
    "pay\xE9e",
    "facture",
    "re\xE7u",
    "recu",
    "livraison",
    "livr\xE9",
    "livre",
    "commande confirm\xE9e",
    "merci pour",
    "parfait merci",
    "re\xE7u le",
    "satisfait",
    "recommande",
    "paid",
    "payment",
    "invoice",
    "delivery",
    "delivered",
    "received",
    "thanks for the",
    "order confirmed"
  ];
  var FRIENDLY_KEYWORDS = [
    "salut",
    "coucou",
    "\xE7a va",
    "ca va",
    "cool",
    "mdr",
    "lol",
    "haha",
    "merci",
    "bisous",
    "\xE0 bient\xF4t",
    "hey",
    "hi",
    "hello",
    "thanks",
    "nice",
    "see you",
    "how are you"
  ];
  var STOPWORDS = /* @__PURE__ */ new Set([
    "le",
    "la",
    "les",
    "un",
    "une",
    "des",
    "de",
    "du",
    "et",
    "\xE0",
    "a",
    "au",
    "aux",
    "en",
    "dans",
    "je",
    "tu",
    "il",
    "elle",
    "on",
    "nous",
    "vous",
    "ils",
    "elles",
    "que",
    "qui",
    "quoi",
    "pas",
    "ne",
    "pour",
    "avec",
    "sur",
    "ce",
    "cette",
    "mon",
    "ma",
    "mes",
    "ton",
    "ta",
    "tes",
    "son",
    "the",
    "a",
    "an",
    "and",
    "or",
    "to",
    "of",
    "in",
    "on",
    "for",
    "with",
    "is",
    "are",
    "you",
    "i",
    "it",
    "this",
    "that",
    "me",
    "my",
    "your",
    "so",
    "but",
    "we",
    "they",
    "be",
    "have"
  ]);
  var DMAnalyzer = class {
    /**
     * Score DM global (0-30), utilisé par ScoringEngine. Combine fréquence,
     * mots-clés/ton et réciprocité — purement côté extension.
     */
    calculateDMScore(conversation) {
      const messages = conversation?.messages || [];
      if (messages.length === 0) {
        return { total: 0, frequency: 0, keywordsTone: 0, reciprocity: 0 };
      }
      const frequency = Math.min(Math.floor(messages.length / 3), 10);
      const keywordsTone = this.scoreKeywordsTone(conversation);
      const sent = messages.filter((m) => m.isSent).length;
      const received = messages.length - sent;
      const balance = sent > 0 && received > 0 ? Math.min(sent, received) / Math.max(sent, received) : 0;
      const reciprocity = Math.round(Math.min(received, 5) + balance * 5);
      const total = Math.min(30, frequency + keywordsTone + reciprocity);
      return { total, frequency, keywordsTone, reciprocity };
    }
    /** Score mots-clés + ton (0-10) — la part qualitative côté extension. */
    scoreKeywordsTone(conversation) {
      const text = this.joinText(conversation.messages).toLowerCase();
      if (!text) return 0;
      const prospectHits = this.countHits(text, PROSPECT_KEYWORDS);
      const clientHits = this.countHits(text, CLIENT_KEYWORDS);
      const friendlyHits = this.countHits(text, FRIENDLY_KEYWORDS);
      const raw = clientHits * 3 + prospectHits * 2 + friendlyHits * 0.5;
      return Math.max(0, Math.min(10, Math.round(raw)));
    }
    /** Détermine la tonalité dominante de la conversation. */
    analyzeConversationTone(messages) {
      const text = this.joinText(messages).toLowerCase();
      const prospectHits = this.countHits(text, PROSPECT_KEYWORDS);
      const clientHits = this.countHits(text, CLIENT_KEYWORDS);
      const friendlyHits = this.countHits(text, FRIENDLY_KEYWORDS);
      if (clientHits >= 1 && clientHits >= prospectHits) {
        return { category: "client", score: clientHits };
      }
      if (prospectHits >= 1) {
        return { category: "prospect", score: prospectHits };
      }
      if (friendlyHits >= 2) {
        return { category: "network", score: friendlyHits };
      }
      return { category: "lead", score: 0 };
    }
    /** Mots-clés les plus fréquents (hors stopwords). */
    extractTopKeywords(conversation, n = 5) {
      const text = this.joinText(conversation.messages).toLowerCase();
      const words = text.match(/[a-zàâçéèêëîïôûùüÿñæœ0-9]{3,}/gi) || [];
      const freq = /* @__PURE__ */ new Map();
      for (const w of words) {
        if (STOPWORDS.has(w)) continue;
        freq.set(w, (freq.get(w) || 0) + 1);
      }
      return Array.from(freq.entries()).sort((a, b) => b[1] - a[1]).slice(0, n).map(([w]) => w);
    }
    /** Détecte un changement de ton entre le début et la fin de la conversation. */
    detectToneChange(messages) {
      if (messages.length < 6) {
        const tone = this.analyzeConversationTone(messages).category;
        return { changed: false, from: tone, to: tone };
      }
      const third = Math.floor(messages.length / 3);
      const from = this.analyzeConversationTone(messages.slice(0, third)).category;
      const to = this.analyzeConversationTone(messages.slice(-third)).category;
      return { changed: from !== to, from, to };
    }
    // ==================== Helpers ====================
    joinText(messages) {
      return (messages || []).map((m) => m.text || "").join(" \n ");
    }
    countHits(text, keywords) {
      let count = 0;
      for (const kw of keywords) {
        let idx = text.indexOf(kw);
        while (idx !== -1) {
          count++;
          idx = text.indexOf(kw, idx + kw.length);
        }
      }
      return count;
    }
  };

  // src/content/scoring-engine.ts
  var ScoringEngine = class {
    constructor() {
      this.dmAnalyzer = new DMAnalyzer();
    }
    /**
     * Calcule le score total d'un contact
     */
    calculateTotalScore(contact) {
      const dms = this.calculateDMScore(contact);
      const engagement = this.calculateEngagementScore(contact);
      const activity = this.calculateActivityScore(contact);
      const seniority = this.calculateSeniorityScore(contact);
      const reciprocity = this.calculateReciprocityScore(contact);
      const total = dms + engagement + activity + seniority + reciprocity;
      return {
        dms,
        engagement,
        activity,
        seniority,
        reciprocity,
        total
      };
    }
    /**
     * Score DMs (0-30 points)
     */
    calculateDMScore(contact) {
      if (!contact.conversation || contact.conversation.messages.length === 0) {
        return 0;
      }
      const breakdown = this.dmAnalyzer.calculateDMScore(contact.conversation);
      return breakdown.total;
    }
    /**
     * Score Engagement (0-25 points)
     */
    calculateEngagementScore(contact) {
      let score = 0;
      score += Math.min(contact.likesGiven, 8);
      score += Math.min(contact.commentsGiven * 2, 8);
      score += Math.min(contact.storiesViewed, 5);
      score += Math.min(contact.sharesReceived * 2, 4);
      return Math.min(score, 25);
    }
    /**
     * Score Activité (0-20 points)
     */
    calculateActivityScore(contact) {
      let score = 0;
      score += Math.min(contact.profileVisits * 2, 8);
      score += Math.min(contact.timeSpentMinutes, 6);
      score += Math.min(contact.linkClicks * 3, 6);
      return Math.min(score, 20);
    }
    /**
     * Score Ancienneté (0-10 points)
     */
    calculateSeniorityScore(contact) {
      const now = Date.now();
      const daysSinceFirst = Math.floor(
        (now - contact.firstInteractionDate) / (1e3 * 60 * 60 * 24)
      );
      let seniorityPoints = 0;
      if (daysSinceFirst < 7) seniorityPoints = 1;
      else if (daysSinceFirst < 30) seniorityPoints = 2;
      else if (daysSinceFirst < 90) seniorityPoints = 3;
      else if (daysSinceFirst < 180) seniorityPoints = 4;
      else seniorityPoints = 5;
      const daysSinceLast = Math.floor(
        (now - contact.lastInteractionDate) / (1e3 * 60 * 60 * 24)
      );
      let consistencyPoints = 0;
      if (daysSinceLast < 7) consistencyPoints = 5;
      else if (daysSinceLast < 14) consistencyPoints = 4;
      else if (daysSinceLast < 30) consistencyPoints = 3;
      else if (daysSinceLast < 60) consistencyPoints = 2;
      else consistencyPoints = 1;
      return seniorityPoints + consistencyPoints;
    }
    /**
     * Score Réciprocité (0-15 points)
     */
    calculateReciprocityScore(contact) {
      let score = 0;
      if (contact.isFollowingBack) {
        score += 5;
      }
      score += Math.min(contact.mutualEngagementCount, 5);
      score += Math.min(contact.mutualConnectionsCount, 5);
      return Math.min(score, 15);
    }
    /**
     * Détermine la catégorie suggérée basée sur le score
     */
    determineSuggestedCategory(score, dmCategory) {
      if (dmCategory) {
        if (dmCategory === "client" && score >= 80) return "client";
        if (dmCategory === "prospect" && score >= 50) return "prospect";
      }
      if (score >= 80) return "client";
      if (score >= 50) return "prospect";
      if (score >= 20) return "network";
      return "lead";
    }
    /**
     * Détecte si une transition de catégorie est nécessaire
     */
    detectTransition(contact, currentScore) {
      const currentCategory = contact.currentCategory || "lead";
      const suggestedCategory = this.determineSuggestedCategory(
        currentScore.total,
        contact.conversation ? this.dmAnalyzer.analyzeConversationTone(contact.conversation.messages).category : void 0
      );
      if (currentCategory === suggestedCategory) {
        return {
          shouldTransition: false,
          from: currentCategory,
          to: currentCategory,
          confidence: 0,
          reason: "Category unchanged",
          evidence: []
        };
      }
      const { reason, evidence, confidence } = this.analyzeTransitionReason(
        contact,
        currentCategory,
        suggestedCategory,
        currentScore
      );
      return {
        shouldTransition: true,
        from: currentCategory,
        to: suggestedCategory,
        confidence,
        reason,
        evidence
      };
    }
    /**
     * Analyse la raison d'une transition
     */
    analyzeTransitionReason(contact, from, to, score) {
      const evidence = [];
      let confidence = 0.5;
      if (contact.conversation && contact.conversation.messages.length > 0) {
        const topKeywords = this.dmAnalyzer.extractTopKeywords(contact.conversation, 3);
        if (topKeywords.length > 0) {
          evidence.push(`Keywords: ${topKeywords.join(", ")}`);
          confidence += 0.2;
        }
        const toneChange = this.dmAnalyzer.detectToneChange(contact.conversation.messages);
        if (toneChange.changed) {
          evidence.push(`Tone change detected: ${toneChange.from} \u2192 ${toneChange.to}`);
          confidence += 0.15;
        }
      }
      if (score.total >= 80) {
        evidence.push(`High score: ${score.total}/100`);
        confidence += 0.1;
      }
      if (score.engagement >= 20) {
        evidence.push(`Strong engagement: ${score.engagement}/25`);
        confidence += 0.05;
      }
      let reason = "";
      if (from === "lead" && to === "prospect") {
        reason = "Commercial intent detected";
      } else if (from === "prospect" && to === "client") {
        reason = "Conversion confirmed";
      } else if (from === "client" && to === "network") {
        reason = "Drop in business activity detected";
      } else if (from === "network" && to === "prospect") {
        reason = "Emerging commercial interest";
      } else if (from === "lead" && to === "network") {
        reason = "Social relationship established";
      } else {
        reason = `Transition from ${from} to ${to}`;
      }
      return {
        reason,
        evidence,
        confidence: Math.min(confidence, 1)
      };
    }
    /**
     * Vérifie si un contact devrait être reclassifié
     */
    shouldReclassify(contact, scoreBreakdown) {
      const currentCategory = contact.currentCategory || "lead";
      const suggestedCategory = this.determineSuggestedCategory(scoreBreakdown.total);
      const rules = {
        // Lead → Prospect: score >= 50 OU DMs avec mots-clés prospect
        lead_to_prospect: currentCategory === "lead" && (scoreBreakdown.total >= 50 || scoreBreakdown.dms >= 15),
        // Prospect → Client: score >= 80 ET DMs avec mots-clés client
        prospect_to_client: currentCategory === "prospect" && scoreBreakdown.total >= 80 && scoreBreakdown.dms >= 20,
        // Client → Network: score < 60 ET pas de DMs client récents
        client_to_network: currentCategory === "client" && scoreBreakdown.total < 60,
        // Network → Prospect: score >= 50 ET DMs avec mots-clés business
        network_to_prospect: currentCategory === "network" && scoreBreakdown.total >= 50 && scoreBreakdown.dms >= 15
      };
      return Object.values(rules).some((rule) => rule);
    }
    /**
     * Calcule le score de confiance pour une suggestion
     */
    calculateConfidence(contact, transition) {
      let confidence = transition.confidence;
      confidence += Math.min(transition.evidence.length * 0.05, 0.15);
      const scoreBreakdown = this.calculateTotalScore(contact);
      if (scoreBreakdown.total >= 80 && transition.to === "client") {
        confidence += 0.1;
      }
      if (scoreBreakdown.total >= 50 && transition.to === "prospect") {
        confidence += 0.1;
      }
      return Math.min(confidence, 1);
    }
  };

  // src/content/scan-overlay.ts
  var ICON_HOURGLASS = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#02c950" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg>`;
  var ICON_CHECK = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#02c950" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  var ICON_X = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d4d" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
  var ScanOverlay = class {
    constructor() {
      this.overlay = null;
      this.progressBar = null;
      this.statusText = null;
      this.iconEl = null;
      this.pctText = null;
    }
    show(message = "Analyse en cours...") {
      if (this.overlay) this.overlay.remove();
      const style2 = document.createElement("style");
      style2.id = "waler-overlay-style";
      style2.textContent = `
      @keyframes waler-in  { from { transform: translateY(12px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
      @keyframes waler-out { from { transform: translateY(0);    opacity: 1; } to { transform: translateY(12px); opacity: 0; } }
      @keyframes waler-spin {
        0%   { transform: rotate(0deg); }
        40%  { transform: rotate(180deg); }
        50%  { transform: rotate(180deg); }
        90%  { transform: rotate(360deg); }
        100% { transform: rotate(360deg); }
      }
    `;
      if (!document.getElementById("waler-overlay-style")) {
        document.head.appendChild(style2);
      }
      this.overlay = document.createElement("div");
      this.overlay.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #000;
      border: 1px solid rgba(2,201,80,0.18);
      color: #fff;
      padding: 14px 16px;
      border-radius: 10px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.7), 0 0 0 1px rgba(2,201,80,0.06);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      min-width: 260px;
      max-width: 320px;
      animation: waler-in 0.25s ease-out;
    `;
      const header = document.createElement("div");
      header.style.cssText = "display:flex;align-items:center;gap:8px;margin-bottom:10px;";
      this.iconEl = document.createElement("div");
      this.iconEl.innerHTML = ICON_HOURGLASS;
      this.iconEl.style.cssText = "display:flex;align-items:center;flex-shrink:0;animation:waler-spin 2s ease-in-out infinite;";
      const title = document.createElement("span");
      title.textContent = "Waler";
      title.style.cssText = "font-weight:600;font-size:13px;letter-spacing:0.02em;color:#02c950;flex:1;";
      this.pctText = document.createElement("span");
      this.pctText.textContent = "";
      this.pctText.style.cssText = "font-size:11px;color:rgba(255,255,255,0.4);font-variant-numeric:tabular-nums;";
      header.appendChild(this.iconEl);
      header.appendChild(title);
      header.appendChild(this.pctText);
      this.statusText = document.createElement("span");
      this.statusText.textContent = message;
      this.statusText.style.cssText = "display:block;font-size:12px;color:rgba(255,255,255,0.65);margin-bottom:10px;line-height:1.4;";
      const track = document.createElement("div");
      track.style.cssText = "width:100%;height:2px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;";
      this.progressBar = document.createElement("div");
      this.progressBar.style.cssText = "width:0%;height:100%;background:#02c950;border-radius:2px;transition:width 0.4s ease;box-shadow:0 0 6px rgba(2,201,80,0.5);";
      track.appendChild(this.progressBar);
      this.overlay.appendChild(header);
      this.overlay.appendChild(this.statusText);
      this.overlay.appendChild(track);
      document.body.appendChild(this.overlay);
    }
    updateProgress(current, total, message) {
      if (!this.overlay) return;
      const pct = Math.min(100, Math.floor(current / total * 100));
      if (this.progressBar) this.progressBar.style.width = `${pct}%`;
      if (this.statusText) this.statusText.textContent = message || `${current} / ${total} (${pct}%)`;
      if (this.pctText) this.pctText.textContent = `${pct}%`;
    }
    showSuccess(message = "Analyse termin\xE9e !") {
      if (!this.overlay) return;
      if (this.iconEl) {
        this.iconEl.innerHTML = ICON_CHECK;
        this.iconEl.style.animation = "none";
      }
      if (this.statusText) this.statusText.textContent = message;
      if (this.progressBar) this.progressBar.style.width = "100%";
      if (this.pctText) this.pctText.textContent = "100%";
      setTimeout(() => this.hide(), 3e3);
    }
    showError(message = "Erreur lors de l'analyse") {
      if (!this.overlay) return;
      if (this.iconEl) {
        this.iconEl.innerHTML = ICON_X;
        this.iconEl.style.animation = "none";
      }
      if (this.overlay) this.overlay.style.borderColor = "rgba(255,77,77,0.3)";
      if (this.statusText) this.statusText.textContent = message;
      if (this.progressBar) {
        this.progressBar.style.background = "#ff4d4d";
        this.progressBar.style.boxShadow = "0 0 6px rgba(255,77,77,0.5)";
      }
      setTimeout(() => this.hide(), 5e3);
    }
    hide() {
      if (!this.overlay) return;
      this.overlay.style.animation = "waler-out 0.25s ease-out forwards";
      setTimeout(() => {
        if (this.overlay) {
          this.overlay.remove();
          this.overlay = null;
        }
        this.progressBar = null;
        this.statusText = null;
        this.iconEl = null;
        this.pctText = null;
      }, 250);
    }
    isVisible() {
      return this.overlay !== null;
    }
  };
  var scan_overlay_default = ScanOverlay;

  // src/content/instagram-api-interceptor.ts
  var PAGE_INTERCEPTOR_SOURCE = "WALER_PAGE_INTERCEPTOR";
  var InstagramAPIInterceptor = class {
    constructor() {
      this.followers = /* @__PURE__ */ new Set();
      this.isIntercepting = false;
      this.onUserInfoCallback = null;
      this.onFollowersCallback = null;
      this.messageHandler = null;
    }
    start(onFollowersReceived, onUserInfo) {
      this.onFollowersCallback = onFollowersReceived;
      this.onUserInfoCallback = onUserInfo || null;
      if (this.isIntercepting) {
        console.log("\u{1F50C} API interception already active, callbacks updated");
        return;
      }
      console.log("\u{1F50C} Starting Instagram API interception (listening to MAIN world)...");
      this.isIntercepting = true;
      this.messageHandler = (event) => {
        if (event.source !== window) return;
        const msg = event.data;
        if (!msg || msg.source !== PAGE_INTERCEPTOR_SOURCE || msg.type !== "API_RESPONSE") {
          return;
        }
        this.handleApiResponse(msg.url, msg.data);
      };
      window.addEventListener("message", this.messageHandler);
    }
    handleApiResponse(url, data) {
      try {
        const userNode = data?.data?.user || data?.user;
        if (userNode && this.onUserInfoCallback) {
          console.log("\u{1F4CA} User info detected in API response:", url);
          const normalized = data?.data?.user ? data : { data: { user: userNode } };
          this.onUserInfoCallback(normalized);
        }
        this.parseFollowersFromResponse(data);
        if (this.followers.size > 0 && this.onFollowersCallback) {
          console.log(`\u{1F4E1} Intercepted ${this.followers.size} followers from API`);
          this.onFollowersCallback(Array.from(this.followers));
        }
      } catch (e) {
      }
    }
    stop() {
      if (!this.isIntercepting) return;
      console.log("\u{1F50C} Stopping Instagram API interception...");
      if (this.messageHandler) {
        window.removeEventListener("message", this.messageHandler);
        this.messageHandler = null;
      }
      this.isIntercepting = false;
    }
    parseFollowersFromResponse(data) {
      const findUsernames = (obj) => {
        if (!obj || typeof obj !== "object") return;
        if (obj.username && typeof obj.username === "string") {
          this.followers.add(obj.username);
        }
        for (const key in obj) {
          if (obj.hasOwnProperty(key)) {
            findUsernames(obj[key]);
          }
        }
      };
      findUsernames(data);
    }
    getFollowers() {
      return Array.from(this.followers);
    }
  };

  // src/content/action-recorder.ts
  var ActionRecorder = class {
    constructor() {
      this.recording = false;
      this.events = [];
      this.checkpoints = [];
      this.startTime = 0;
      this.controlPanel = null;
      this.lastScrollTop = 0;
      this.followersDetected = /* @__PURE__ */ new Set();
      this.handleScroll = (e) => {
        if (!this.recording) return;
        const target = e.target;
        const scrollTop = target === document.documentElement ? window.scrollY : target.scrollTop;
        this.detectFollowers();
        this.logEvent("scroll", {
          scrollTop,
          delta: scrollTop - this.lastScrollTop,
          target: this.getSelector(target),
          followersVisible: this.followersDetected.size
        });
        this.lastScrollTop = scrollTop;
      };
      this.handleClick = (e) => {
        if (!this.recording) return;
        const target = e.target;
        if (target.closest("#waler-recorder-panel")) return;
        this.logEvent("click", {
          x: e.clientX,
          y: e.clientY,
          selector: this.getSelector(target),
          text: target.textContent?.slice(0, 50),
          href: target.href || null
        });
        this.showClickFlash(e.clientX, e.clientY);
      };
      this.handleMutation = (mutations) => {
        if (!this.recording) return;
        let newNodesCount = 0;
        mutations.forEach((m) => newNodesCount += m.addedNodes.length);
        if (newNodesCount > 5) {
          this.detectFollowers();
          this.logEvent("dom_update", {
            addedNodes: newNodesCount,
            followersDetected: this.followersDetected.size
          });
        }
      };
      this.createControlPanel();
    }
    createControlPanel() {
      const panel = document.createElement("div");
      panel.id = "waler-recorder-panel";
      panel.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 999999;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: 2px solid #fff;
      border-radius: 16px;
      padding: 20px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      color: white;
      min-width: 280px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
    `;
      panel.innerHTML = `
      <div style="font-size: 18px; font-weight: bold; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
        <span>\u{1F3AC}</span>
        <span>WALER RECORDER</span>
      </div>
      
      <div id="rec-status" style="font-size: 13px; opacity: 0.9; margin-bottom: 12px; padding: 8px; background: rgba(255,255,255,0.1); border-radius: 8px;">
        \u23F8\uFE0F En attente...
      </div>
      
      <div id="rec-stats" style="font-size: 12px; opacity: 0.8; margin-bottom: 16px; display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
        <div>\u{1F4CA} <span id="events-count">0</span> events</div>
        <div>\u{1F4CD} <span id="checkpoints-count">0</span> checkpoints</div>
        <div>\u{1F465} <span id="followers-count">0</span> followers</div>
        <div>\u23F1\uFE0F <span id="duration">0s</span></div>
      </div>
      
      <button id="btn-record" style="
        width: 100%; padding: 12px; margin-bottom: 8px;
        background: #10b981; color: white;
        border: none; border-radius: 10px;
        cursor: pointer; font-weight: bold; font-size: 14px;
        transition: all 0.2s;
      ">\u23FA D\xE9marrer l'enregistrement</button>
      
      <button id="btn-checkpoint" style="
        width: 100%; padding: 12px; margin-bottom: 8px;
        background: #f59e0b; color: white;
        border: none; border-radius: 10px;
        cursor: pointer; font-weight: bold; font-size: 14px;
        display: none;
      ">\u{1F4CD} Ajouter un checkpoint</button>
      
      <button id="btn-stop" style="
        width: 100%; padding: 12px;
        background: #ef4444; color: white;
        border: none; border-radius: 10px;
        cursor: pointer; font-weight: bold; font-size: 14px;
        display: none;
      ">\u23F9 Arr\xEAter & G\xE9n\xE9rer le code</button>
    `;
      document.body.appendChild(panel);
      this.controlPanel = panel;
      panel.querySelector("#btn-record")?.addEventListener("click", () => this.startRecording());
      panel.querySelector("#btn-checkpoint")?.addEventListener("click", () => this.addCheckpoint());
      panel.querySelector("#btn-stop")?.addEventListener("click", () => this.stopAndExport());
    }
    startRecording() {
      this.recording = true;
      this.startTime = Date.now();
      this.events = [];
      this.checkpoints = [];
      this.followersDetected.clear();
      const statusEl = document.getElementById("rec-status");
      if (statusEl) {
        statusEl.innerHTML = "\u{1F534} <strong>ENREGISTREMENT EN COURS</strong>";
        statusEl.style.background = "rgba(239, 68, 68, 0.2)";
      }
      document.getElementById("btn-record").style.display = "none";
      document.getElementById("btn-checkpoint").style.display = "block";
      document.getElementById("btn-stop").style.display = "block";
      this.attachListeners();
      this.addCheckpoint("START");
      console.log("\u{1F3AC} [Recorder] Enregistrement d\xE9marr\xE9");
    }
    attachListeners() {
      document.addEventListener("scroll", this.handleScroll, true);
      document.addEventListener("click", this.handleClick, true);
      const observer = new MutationObserver(this.handleMutation);
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      setInterval(() => this.updateStats(), 1e3);
    }
    detectFollowers() {
      const modal = document.querySelector('[role="dialog"]');
      if (!modal) return;
      const links = modal.querySelectorAll('a[href^="/"]');
      links.forEach((link) => {
        const href = link.getAttribute("href");
        if (href) {
          const match = href.match(/^\/([a-zA-Z0-9._]+)\/?/);
          if (match) {
            const username = match[1];
            const systemPages = ["explore", "reels", "direct", "p", "stories"];
            if (!systemPages.includes(username)) {
              this.followersDetected.add(username);
            }
          }
        }
      });
      this.updateStats();
    }
    addCheckpoint(label) {
      const checkpoint = {
        id: `cp_${this.checkpoints.length + 1}`,
        label: label || `Checkpoint ${this.checkpoints.length + 1}`,
        timestamp: Date.now(),
        elapsed_ms: Date.now() - this.startTime,
        url: window.location.href,
        scrollPosition: window.scrollY,
        followersCount: this.followersDetected.size,
        visibleFollowers: Array.from(this.followersDetected)
      };
      this.checkpoints.push(checkpoint);
      this.showCheckpointFlash(checkpoint.label);
      this.updateStats();
      console.log(`\u{1F4CD} [Checkpoint] ${checkpoint.label}`, checkpoint);
    }
    logEvent(type, data) {
      const event = {
        id: this.events.length,
        type,
        timestamp: Date.now(),
        elapsed_ms: Date.now() - this.startTime,
        data
      };
      this.events.push(event);
    }
    stopAndExport() {
      this.recording = false;
      this.addCheckpoint("END");
      const generatedCode = this.generateScanCode();
      const report = {
        recorded_at: (/* @__PURE__ */ new Date()).toISOString(),
        duration_ms: Date.now() - this.startTime,
        total_events: this.events.length,
        total_checkpoints: this.checkpoints.length,
        total_followers: this.followersDetected.size,
        checkpoints: this.checkpoints,
        events: this.events,
        generated_code: generatedCode,
        followers_list: Array.from(this.followersDetected)
      };
      this.downloadJSON(report, `waler-recording-${Date.now()}.json`);
      this.downloadFile(generatedCode, `waler-scan-generated-${Date.now()}.ts`);
      this.showSummary(report);
      console.log("\u2705 [Recorder] Export termin\xE9", report);
    }
    generateScanCode() {
      let code = `/**
 * Code g\xE9n\xE9r\xE9 automatiquement par Waler Recorder
 * Date: ${(/* @__PURE__ */ new Date()).toISOString()}
 * Dur\xE9e d'enregistrement: ${Math.round((Date.now() - this.startTime) / 1e3)}s
 * Followers d\xE9tect\xE9s: ${this.followersDetected.size}
 * Checkpoints: ${this.checkpoints.length}
 */

async function performOptimizedScan() {
  console.log('\u{1F680} D\xE9marrage du scan optimis\xE9...');
  
  const scannedFollowers = new Set<string>();
  const modal = document.querySelector('[role="dialog"]');
  if (!modal) {
    console.error('\u274C Modal not found');
    return [];
  }
  
  // Trouver le container scrollable
  const scrollContainer = modal as HTMLElement;
  
`;
      const scrollEvents = this.events.filter((e) => e.type === "scroll");
      const avgScrollDelta = scrollEvents.reduce((sum, e) => sum + Math.abs(e.data.delta), 0) / scrollEvents.length;
      const avgDelay = scrollEvents.length > 1 ? (scrollEvents[scrollEvents.length - 1].elapsed_ms - scrollEvents[0].elapsed_ms) / scrollEvents.length : 1e3;
      code += `  // Pattern de scroll d\xE9tect\xE9:
`;
      code += `  // - Scroll moyen: ${Math.round(avgScrollDelta)}px
`;
      code += `  // - D\xE9lai moyen: ${Math.round(avgDelay)}ms
`;
      code += `  
`;
      code += `  let lastCount = 0;
`;
      code += `  let stableCount = 0;
`;
      code += `  const maxStableChecks = 5;
`;
      code += `  
`;
      code += `  while (stableCount < maxStableChecks) {
`;
      code += `    // Collecter les followers visibles
`;
      code += `    const links = modal.querySelectorAll('a[href^="/"]');
`;
      code += `    links.forEach(link => {
`;
      code += `      const href = link.getAttribute('href');
`;
      code += `      if (href) {
`;
      code += `        const match = href.match(/^\\/([a-zA-Z0-9._]+)\\/?/);
`;
      code += `        if (match) {
`;
      code += `          const username = match[1];
`;
      code += `          const systemPages = ['explore', 'reels', 'direct', 'p', 'stories'];
`;
      code += `          if (!systemPages.includes(username)) {
`;
      code += `            scannedFollowers.add(username);
`;
      code += `          }
`;
      code += `        }
`;
      code += `      }
`;
      code += `    });
`;
      code += `    
`;
      code += `    const currentCount = scannedFollowers.size;
`;
      code += `    console.log(\`\u{1F4CA} Followers: \${currentCount}\`);
`;
      code += `    
`;
      code += `    if (currentCount === lastCount) {
`;
      code += `      stableCount++;
`;
      code += `    } else {
`;
      code += `      stableCount = 0;
`;
      code += `      lastCount = currentCount;
`;
      code += `    }
`;
      code += `    
`;
      code += `    // Scroll optimis\xE9 (bas\xE9 sur tes gestes r\xE9els)
`;
      code += `    scrollContainer.scrollTop += ${Math.round(avgScrollDelta)};
`;
      code += `    
`;
      code += `    // D\xE9lai naturel (bas\xE9 sur ton rythme)
`;
      code += `    await new Promise(resolve => setTimeout(resolve, ${Math.round(avgDelay)}));
`;
      code += `  }
`;
      code += `  
`;
      code += `  console.log(\`\u2705 Scan termin\xE9: \${scannedFollowers.size} followers\`);
`;
      code += `  return Array.from(scannedFollowers);
`;
      code += `}
`;
      return code;
    }
    getSelector(element) {
      if (element.id) return `#${element.id}`;
      if (element.getAttribute("aria-label")) return `[aria-label="${element.getAttribute("aria-label")}"]`;
      if (element.getAttribute("role")) return `[role="${element.getAttribute("role")}"]`;
      return element.tagName.toLowerCase();
    }
    showClickFlash(x, y) {
      const flash = document.createElement("div");
      flash.style.cssText = `
      position: fixed;
      left: ${x - 15}px;
      top: ${y - 15}px;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: rgba(16, 185, 129, 0.4);
      border: 2px solid #10b981;
      pointer-events: none;
      z-index: 999998;
      animation: walerFlash 0.5s ease-out forwards;
    `;
      document.body.appendChild(flash);
      setTimeout(() => flash.remove(), 500);
    }
    showCheckpointFlash(label) {
      const flash = document.createElement("div");
      flash.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(245, 158, 11, 0.95);
      color: white;
      padding: 16px 32px;
      border-radius: 12px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-weight: bold;
      font-size: 18px;
      z-index: 999999;
      pointer-events: none;
      box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    `;
      flash.textContent = `\u{1F4CD} ${label}`;
      document.body.appendChild(flash);
      setTimeout(() => flash.remove(), 1500);
    }
    updateStats() {
      const duration = Math.round((Date.now() - this.startTime) / 1e3);
      document.getElementById("events-count").textContent = this.events.length.toString();
      document.getElementById("checkpoints-count").textContent = this.checkpoints.length.toString();
      document.getElementById("followers-count").textContent = this.followersDetected.size.toString();
      document.getElementById("duration").textContent = `${duration}s`;
    }
    showSummary(report) {
      alert(`\u2705 Recording complete!

\u{1F4CA} Statistics:
- Duration: ${Math.round(report.duration_ms / 1e3)}s
- Events: ${report.total_events}
- Checkpoints: ${report.total_checkpoints}
- Followers detected: ${report.total_followers}

\u{1F4E5} Files downloaded:
- waler-recording-*.json (full data)
- waler-scan-generated-*.ts (optimized code)

The generated code uses your real scroll patterns for an undetectable scan!`);
    }
    downloadJSON(data, filename) {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      this.downloadBlob(blob, filename);
    }
    downloadFile(content, filename) {
      const blob = new Blob([content], { type: "text/plain" });
      this.downloadBlob(blob, filename);
    }
    downloadBlob(blob, filename) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    }
  };
  var style = document.createElement("style");
  style.textContent = `
  @keyframes walerFlash {
    0% { transform: scale(1); opacity: 1; }
    100% { transform: scale(3); opacity: 0; }
  }
`;
  document.head.appendChild(style);

  // src/content/instagram-modal-scroller.ts
  var InstagramModalScroller = class {
    constructor(options = {}) {
      this.modalSelector = 'div[role="dialog"] div._aano';
      this.followerItemSelector = "div._aano > div > div";
      this.scrollContainer = null;
      this.lastFollowerCount = 0;
      this.stuckCount = 0;
      this.maxStuckAttempts = options.maxScrollAttempts || 10;
      this.scrollDelay = options.scrollDelay || 250;
      this.waitForLoadTimeout = options.waitForLoadTimeout || 5e3;
      this.onProgress = options.onProgress;
    }
    /**
     * Scroll jusqu'à la fin du modal et retourne tous les usernames
     */
    async scrollToEnd() {
      this.scrollContainer = this.findScrollContainer();
      if (!this.scrollContainer) {
        throw new Error("Modal followers non trouv\xE9. Assurez-vous que le modal est ouvert.");
      }
      const allFollowers = [];
      let isEndReached = false;
      let scrollAttempt = 0;
      console.log("\u{1F680} D\xE9but du scroll intelligent pour capturer TOUS les followers...");
      while (!isEndReached) {
        scrollAttempt++;
        const scrolled = await this.humanScroll();
        await this.waitForNewFollowers();
        const visibleFollowers = this.extractVisibleFollowers();
        let newCount = 0;
        visibleFollowers.forEach((username) => {
          if (!allFollowers.includes(username)) {
            allFollowers.push(username);
            newCount++;
          }
        });
        isEndReached = this.isEndOfList(allFollowers.length);
        if (this.onProgress) {
          this.onProgress({
            totalFollowers: allFollowers.length,
            newFollowersThisScroll: newCount,
            scrollPosition: this.scrollContainer.scrollTop,
            isEndReached
          });
        }
        console.log(
          `\u{1F4CA} Scroll #${scrollAttempt}: ${allFollowers.length} followers captur\xE9s (+${newCount} dans cette portion) | Position: ${Math.round(this.scrollContainer.scrollTop)}px`
        );
        if (scrollAttempt > 100) {
          console.warn("\u26A0\uFE0F Limite de 100 scrolls atteinte. Arr\xEAt.");
          break;
        }
      }
      console.log(`\u2705 Scroll termin\xE9 : ${allFollowers.length} followers captur\xE9s`);
      return allFollowers;
    }
    /**
     * Trouve le conteneur scrollable du modal
     */
    findScrollContainer() {
      const modal = document.querySelector('[role="dialog"]');
      if (!modal) {
        console.error("\u274C Modal non trouv\xE9");
        return null;
      }
      console.log("\u{1F50D} Recherche du conteneur scrollable...");
      const selectors = [
        'div[role="dialog"] div._aano',
        'div[role="dialog"] div[style*="overflow"]',
        'div[role="dialog"] > div > div > div:nth-child(2)'
      ];
      for (const selector of selectors) {
        const container = document.querySelector(selector);
        if (container && container.scrollHeight > container.clientHeight) {
          console.log(`\u2705 Conteneur scrollable trouv\xE9 (s\xE9lecteur) : ${selector}`);
          console.log(`\u{1F4CF} scrollHeight=${container.scrollHeight}, clientHeight=${container.clientHeight}`);
          return container;
        }
      }
      console.log("\u{1F50D} Strat\xE9gie 2: Recherche par overflow...");
      const allDivs = modal.querySelectorAll("div");
      for (const div of Array.from(allDivs)) {
        const style2 = window.getComputedStyle(div);
        const hasOverflow = style2.overflow === "auto" || style2.overflow === "scroll" || style2.overflowY === "auto" || style2.overflowY === "scroll";
        if (hasOverflow && div.scrollHeight > div.clientHeight) {
          console.log(`\u2705 Conteneur scrollable trouv\xE9 (overflow) : ${div.className}`);
          console.log(`\u{1F4CF} scrollHeight=${div.scrollHeight}, clientHeight=${div.clientHeight}`);
          return div;
        }
      }
      console.log("\u{1F50D} Strat\xE9gie 3: Utilisation du modal...");
      const modalElement = modal;
      if (modalElement.scrollHeight > modalElement.clientHeight) {
        console.log(`\u2705 Utilisation du modal comme conteneur`);
        console.log(`\u{1F4CF} scrollHeight=${modalElement.scrollHeight}, clientHeight=${modalElement.clientHeight}`);
        return modalElement;
      }
      console.log("\u{1F50D} Strat\xE9gie 4: Recherche par taille...");
      for (const div of Array.from(allDivs)) {
        const htmlDiv = div;
        if (htmlDiv.scrollHeight > 500) {
          console.log(`\u2705 Conteneur trouv\xE9 par taille : ${htmlDiv.className}`);
          console.log(`\u{1F4CF} scrollHeight=${htmlDiv.scrollHeight}, clientHeight=${htmlDiv.clientHeight}`);
          return htmlDiv;
        }
      }
      console.error("\u274C Aucun conteneur scrollable trouv\xE9");
      return null;
    }
    /**
     * Scroll progressif avec variation humaine naturelle
     * Basé sur les patterns observés dans waler-recording-1779454178367.json
     */
    async humanScroll() {
      if (!this.scrollContainer) return 0;
      const currentScroll = this.scrollContainer.scrollTop;
      const maxScroll = this.scrollContainer.scrollHeight - this.scrollContainer.clientHeight;
      if (currentScroll >= maxScroll - 10) {
        return 0;
      }
      const baseScroll = 300 + Math.random() * 200;
      const variation = Math.random() * 200 - 100;
      const scrollAmount = Math.min(baseScroll + variation, maxScroll - currentScroll);
      const steps = 5 + Math.floor(Math.random() * 5);
      const stepSize = scrollAmount / steps;
      const stepDelay = 16 + Math.floor(Math.random() * 20);
      for (let i = 0; i < steps; i++) {
        this.scrollContainer.scrollTop += stepSize;
        await this.sleep(stepDelay);
      }
      const pauseTime = this.scrollDelay + Math.random() * 600;
      await this.sleep(pauseTime);
      return scrollAmount;
    }
    /**
     * Attend que plus de followers soient chargés dans le DOM (lazy loading)
     */
    async waitForNewFollowers() {
      const maxWait = this.waitForLoadTimeout;
      const startTime = Date.now();
      const initialCount = this.getCurrentFollowerCount();
      while (Date.now() - startTime < maxWait) {
        await this.sleep(100);
        const currentCount = this.getCurrentFollowerCount();
        if (currentCount > initialCount) {
          await this.sleep(200);
          return;
        }
      }
      console.log("\u23F1\uFE0F Timeout : aucun follower suppl\xE9mentaire charg\xE9 (fin de liste probable)");
    }
    /**
     * Compte le nombre d'éléments followers actuellement dans le DOM
     * Pattern OpenCLI: compter les liens dans le modal
     */
    getCurrentFollowerCount() {
      const modal = document.querySelector('div[role="dialog"]');
      if (!modal) return 0;
      return modal.querySelectorAll('a[href^="/"]').length;
    }
    /**
     * Extrait les usernames visibles dans le modal
     * Pattern inspiré d'OpenCLI/Playwright agents
     */
    extractVisibleFollowers() {
      const followers = [];
      const seen = /* @__PURE__ */ new Set();
      const modal = document.querySelector('div[role="dialog"]');
      if (!modal) {
        console.warn("\u26A0\uFE0F Modal not found");
        return followers;
      }
      const links = modal.querySelectorAll('a[href^="/"]');
      links.forEach((linkEl) => {
        const href = linkEl.getAttribute("href");
        if (href) {
          const username = href.replace(/^\//, "").replace(/\/$/, "").split("/")[0];
          const invalidPrefixes = ["explore", "p", "reel", "reels", "stories", "direct", "accounts"];
          const isValid = username && username.length > 0 && !invalidPrefixes.includes(username) && !seen.has(username);
          if (isValid) {
            seen.add(username);
            followers.push(username);
          }
        }
      });
      console.log(`\u2705 Extracted ${followers.length} unique followers from ${links.length} links`);
      return followers;
    }
    /**
     * Détecte si on a atteint la fin de la liste
     */
    isEndOfList(currentCount) {
      if (currentCount === this.lastFollowerCount) {
        this.stuckCount++;
        console.log(`\u{1F504} Aucun follower suppl\xE9mentaire charg\xE9 (${this.stuckCount}/${this.maxStuckAttempts})`);
      } else {
        this.stuckCount = 0;
        this.lastFollowerCount = currentCount;
      }
      return this.stuckCount >= this.maxStuckAttempts;
    }
    /**
     * Vérifie si le modal est toujours ouvert
     */
    isModalOpen() {
      return document.querySelector('div[role="dialog"]') !== null;
    }
    /**
     * Ferme le modal
     */
    closeModal() {
      const closeButton = document.querySelector('div[role="dialog"] button[aria-label*="Close"]');
      if (closeButton instanceof HTMLElement) {
        closeButton.click();
        console.log("\u2705 Modal ferm\xE9");
      }
    }
    /**
     * Utilitaire : sleep
     */
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Reset l'état du scroller
     */
    reset() {
      this.scrollContainer = null;
      this.lastFollowerCount = 0;
      this.stuckCount = 0;
    }
  };

  // src/content/follower-extractor.ts
  var FollowerExtractor = class _FollowerExtractor {
    constructor() {
      this.followerItemSelector = "div._aano > div > div";
      this.cache = /* @__PURE__ */ new Map();
    }
    /**
     * Extrait les données complètes de tous les followers visibles
     */
    extractAllVisible() {
      const elements = document.querySelectorAll(this.followerItemSelector);
      const followers = [];
      elements.forEach((el) => {
        const data = this.extractFromElement(el);
        if (data) {
          const cached = this.cache.get(data.username);
          if (cached) {
            followers.push(cached);
          } else {
            this.cache.set(data.username, data);
            followers.push(data);
          }
        }
      });
      return followers;
    }
    /**
     * Extrait les données d'un seul élément follower
     */
    extractFromElement(element) {
      try {
        const linkEl = element.querySelector('a[href^="/"]');
        if (!linkEl) return null;
        const href = linkEl.getAttribute("href");
        if (!href) return null;
        const username = href.replace(/^\//, "").replace(/\/$/, "");
        if (!username || username.includes("/") || username === "explore") {
          return null;
        }
        const avatarImg = element.querySelector("img");
        const avatarUrl = avatarImg?.getAttribute("src") || void 0;
        const fullNameEl = element.querySelector("span > span");
        const fullName = fullNameEl?.textContent?.trim() || void 0;
        const verifiedBadge = element.querySelector('svg[aria-label*="Verified"]');
        const isVerified = verifiedBadge !== null;
        const followsYouEl = element.querySelector("span");
        const followsYouText = followsYouEl?.textContent?.toLowerCase() || "";
        const followsYou = followsYouText.includes("follows you") || followsYouText.includes("vous suit");
        const isPrivate = void 0;
        return {
          username,
          fullName,
          avatarUrl,
          isVerified,
          isPrivate,
          followsYou,
          timestamp: Date.now()
        };
      } catch (error) {
        console.error("Erreur extraction follower:", error);
        return null;
      }
    }
    /**
     * Extrait uniquement les usernames (rapide)
     */
    extractUsernames() {
      const elements = document.querySelectorAll(this.followerItemSelector);
      const usernames = [];
      elements.forEach((el) => {
        const linkEl = el.querySelector('a[href^="/"]');
        if (linkEl) {
          const href = linkEl.getAttribute("href");
          if (href) {
            const username = href.replace(/^\//, "").replace(/\/$/, "");
            if (username && !username.includes("/") && username !== "explore") {
              usernames.push(username);
            }
          }
        }
      });
      return usernames;
    }
    /**
     * Statistiques d'extraction
     */
    getStats() {
      const followers = Array.from(this.cache.values());
      return {
        total: followers.length,
        withAvatar: followers.filter((f) => f.avatarUrl).length,
        withFullName: followers.filter((f) => f.fullName).length,
        verified: followers.filter((f) => f.isVerified).length,
        private: followers.filter((f) => f.isPrivate === true).length,
        followsYou: followers.filter((f) => f.followsYou === true).length
      };
    }
    /**
     * Récupère un follower depuis le cache
     */
    getCached(username) {
      return this.cache.get(username);
    }
    /**
     * Récupère tous les followers du cache
     */
    getAllCached() {
      return Array.from(this.cache.values());
    }
    /**
     * Vide le cache
     */
    clearCache() {
      this.cache.clear();
    }
    /**
     * Exporte les données en JSON
     */
    exportJSON() {
      const followers = this.getAllCached();
      return JSON.stringify({
        extractedAt: (/* @__PURE__ */ new Date()).toISOString(),
        total: followers.length,
        followers,
        stats: this.getStats()
      }, null, 2);
    }
    /**
     * Compare deux listes de followers pour détecter les changements
     */
    static compareFollowers(oldFollowers, newFollowers) {
      const oldSet = new Set(oldFollowers);
      const newSet = new Set(newFollowers);
      const added = newFollowers.filter((u) => !oldSet.has(u));
      const removed = oldFollowers.filter((u) => !newSet.has(u));
      const unchanged = newFollowers.filter((u) => oldSet.has(u));
      return { added, removed, unchanged };
    }
    /**
     * Détecte les unfollowers depuis la dernière extraction
     */
    detectUnfollowers(previousUsernames) {
      const currentUsernames = Array.from(this.cache.keys());
      const comparison = _FollowerExtractor.compareFollowers(
        previousUsernames,
        currentUsernames
      );
      return comparison.removed;
    }
    /**
     * Détecte les nouveaux followers depuis la dernière extraction
     */
    detectNewFollowers(previousUsernames) {
      const currentUsernames = Array.from(this.cache.keys());
      const comparison = _FollowerExtractor.compareFollowers(
        previousUsernames,
        currentUsernames
      );
      return comparison.added;
    }
    /**
     * Enrichit une liste de usernames avec les données complètes
     */
    enrichUsernames(usernames) {
      return usernames.map((username) => this.cache.get(username)).filter((data) => data !== void 0);
    }
    /**
     * Filtre les followers selon des critères
     */
    filter(predicate) {
      return this.getAllCached().filter(predicate);
    }
    /**
     * Exemples de filtres prédéfinis
     */
    getVerifiedFollowers() {
      return this.filter((f) => f.isVerified);
    }
    getFollowersWhoFollowYou() {
      return this.filter((f) => f.followsYou === true);
    }
    getFollowersWithoutAvatar() {
      return this.filter((f) => !f.avatarUrl);
    }
    /**
     * Recherche un follower par username (case-insensitive)
     */
    search(query) {
      const lowerQuery = query.toLowerCase();
      return this.getAllCached().filter(
        (f) => f.username.toLowerCase().includes(lowerQuery) || f.fullName?.toLowerCase().includes(lowerQuery)
      );
    }
    /**
     * Trie les followers par ordre alphabétique
     */
    sortByUsername(ascending = true) {
      const followers = this.getAllCached();
      return followers.sort((a, b) => {
        const comparison = a.username.localeCompare(b.username);
        return ascending ? comparison : -comparison;
      });
    }
    /**
     * Trie les followers par timestamp (plus récent en premier)
     */
    sortByTimestamp(ascending = false) {
      const followers = this.getAllCached();
      return followers.sort((a, b) => {
        const comparison = a.timestamp - b.timestamp;
        return ascending ? comparison : -comparison;
      });
    }
  };

  // src/content/instagram-search-automator.ts
  var InstagramSearchAutomator = class {
    constructor() {
      this.CHAR_DELAY_MIN = 80;
      this.CHAR_DELAY_MAX = 150;
      this.SEARCH_DELAY_MIN = 1e4;
      // 10 secondes
      this.SEARCH_DELAY_MAX = 15e3;
    }
    // 15 secondes
    /**
     * Navigue vers la page d'accueil Instagram
     */
    async navigateToHome() {
      try {
        if (window.location.pathname === "/") {
          console.log("\u2705 Already on home page");
          return true;
        }
        console.log("\u{1F3E0} Navigating to home page...");
        window.location.href = "https://www.instagram.com/";
        await this.sleep(3e3);
        return true;
      } catch (error) {
        console.error("Error navigating to home:", error);
        return false;
      }
    }
    /**
     * Ouvre la barre de recherche Instagram
     */
    async openSearchBar() {
      try {
        console.log("\u{1F50D} Opening search bar...");
        let searchInput = null;
        searchInput = document.querySelector('input[placeholder*="Search"]');
        if (!searchInput) {
          searchInput = document.querySelector('input[aria-label*="Search"]');
        }
        if (!searchInput) {
          const searchIcon = Array.from(document.querySelectorAll("a, span")).find((el) => {
            const text = el.textContent?.toLowerCase() || "";
            const ariaLabel = el.getAttribute("aria-label")?.toLowerCase() || "";
            return text.includes("search") || ariaLabel.includes("search") || text.includes("recherche");
          });
          if (searchIcon) {
            console.log("\u{1F50D} Clicking search icon...");
            searchIcon.click();
            await this.sleep(1e3);
            searchInput = document.querySelector('input[placeholder*="Search"]');
          }
        }
        if (!searchInput) {
          console.error("\u274C Search bar not found");
          return false;
        }
        searchInput.focus();
        searchInput.click();
        await this.sleep(500);
        console.log("\u2705 Search bar opened");
        return true;
      } catch (error) {
        console.error("Error opening search bar:", error);
        return false;
      }
    }
    /**
     * Tape un username dans la barre de recherche avec délai naturel
     */
    async typeUsername(username) {
      try {
        console.log(`\u2328\uFE0F Typing username: @${username}`);
        const searchInput = document.querySelector('input[placeholder*="Search"], input[aria-label*="Search"]');
        if (!searchInput) {
          console.error("\u274C Search input not found");
          return false;
        }
        searchInput.value = "";
        searchInput.dispatchEvent(new Event("input", { bubbles: true }));
        await this.sleep(200);
        for (let i = 0; i < username.length; i++) {
          const char = username[i];
          searchInput.value += char;
          searchInput.dispatchEvent(new Event("input", { bubbles: true }));
          const delay = this.CHAR_DELAY_MIN + Math.random() * (this.CHAR_DELAY_MAX - this.CHAR_DELAY_MIN);
          await this.sleep(delay);
        }
        console.log(`\u2705 Typed: ${username}`);
        return true;
      } catch (error) {
        console.error("Error typing username:", error);
        return false;
      }
    }
    /**
     * Attend les résultats de recherche
     */
    async waitForResults(timeout = 5e3) {
      try {
        console.log("\u23F3 Waiting for search results...");
        const startTime = Date.now();
        while (Date.now() - startTime < timeout) {
          const results = document.querySelectorAll('a[href^="/"]');
          for (const result of Array.from(results)) {
            const href = result.getAttribute("href") || "";
            const match = href.match(/^\/([a-zA-Z0-9._]+)\/?$/);
            if (match) {
              console.log("\u2705 Search results loaded");
              return true;
            }
          }
          await this.sleep(200);
        }
        console.log("\u23F1\uFE0F No results found (timeout)");
        return false;
      } catch (error) {
        console.error("Error waiting for results:", error);
        return false;
      }
    }
    /**
     * Clique sur le premier résultat de recherche
     */
    async clickFirstResult(expectedUsername) {
      try {
        console.log(`\u{1F5B1}\uFE0F Clicking first result for @${expectedUsername}...`);
        const links = document.querySelectorAll('a[href^="/"]');
        for (const link of Array.from(links)) {
          const href = link.getAttribute("href") || "";
          const match = href.match(/^\/([a-zA-Z0-9._]+)\/?$/);
          if (match && match[1].toLowerCase() === expectedUsername.toLowerCase()) {
            console.log(`\u2705 Found result: ${href}`);
            link.click();
            await this.sleep(3e3);
            return true;
          }
        }
        console.log(`\u274C No result found for @${expectedUsername}`);
        return false;
      } catch (error) {
        console.error("Error clicking result:", error);
        return false;
      }
    }
    /**
     * Recherche un username complet (toutes les étapes)
     */
    async searchUsername(username) {
      try {
        console.log(`\u{1F50D} Searching for @${username}...`);
        const searchOpened = await this.openSearchBar();
        if (!searchOpened) {
          return { found: false, username };
        }
        const typed = await this.typeUsername(username);
        if (!typed) {
          return { found: false, username };
        }
        await this.sleep(2e3);
        const hasResults = await this.waitForResults();
        if (!hasResults) {
          console.log(`\u274C @${username} not found on Instagram`);
          return { found: false, username };
        }
        const clicked = await this.clickFirstResult(username);
        if (clicked) {
          const profileUrl = window.location.href;
          console.log(`\u2705 @${username} found and opened: ${profileUrl}`);
          return { found: true, username, profileUrl };
        } else {
          console.log(`\u274C @${username} not found in results`);
          return { found: false, username };
        }
      } catch (error) {
        console.error(`Error searching for @${username}:`, error);
        return { found: false, username };
      }
    }
    /**
     * Supprime l'historique de recherche Instagram
     */
    async clearSearchHistory(username) {
      try {
        console.log(`\u{1F5D1}\uFE0F Clearing search history for @${username}...`);
        const searchOpened = await this.openSearchBar();
        if (!searchOpened) {
          console.warn("Cannot open search bar to clear history");
          return false;
        }
        await this.sleep(500);
        const recentButtons = Array.from(document.querySelectorAll("span, div")).filter((el) => {
          const text = el.textContent?.toLowerCase() || "";
          return text === "recent" || text === "r\xE9cent" || text === "recents" || text === "r\xE9cents";
        });
        if (recentButtons.length === 0) {
          console.log("No recent searches found");
          return true;
        }
        const searchHistoryItems = Array.from(document.querySelectorAll("a, div")).filter((el) => {
          const text = el.textContent?.toLowerCase() || "";
          const href = el.href || "";
          return text.includes(username.toLowerCase()) || href.includes(`/${username.toLowerCase()}`);
        });
        for (const item of searchHistoryItems) {
          const parent = item.closest('div[role="button"], div[tabindex]');
          if (!parent) continue;
          const deleteButton = parent.querySelector('svg[aria-label*="Remove"], svg[aria-label*="Supprimer"], button[aria-label*="Remove"], button[aria-label*="Supprimer"]');
          if (deleteButton) {
            console.log(`\u{1F5D1}\uFE0F Removing @${username} from search history...`);
            deleteButton.click();
            await this.sleep(300);
          } else {
            const buttons = parent.querySelectorAll('button, div[role="button"]');
            for (const btn of Array.from(buttons)) {
              const svg = btn.querySelector("svg");
              if (svg) {
                const paths = svg.querySelectorAll("path, line");
                if (paths.length > 0) {
                  console.log(`\u{1F5D1}\uFE0F Removing @${username} from search history (alternative method)...`);
                  btn.click();
                  await this.sleep(300);
                  break;
                }
              }
            }
          }
        }
        const main = document.querySelector("main");
        if (main) {
          main.click();
          await this.sleep(300);
        }
        console.log(`\u2705 Search history cleared for @${username}`);
        return true;
      } catch (error) {
        console.error("Error clearing search history:", error);
        return false;
      }
    }
    /**
     * Retourne à la page d'accueil
     */
    async goBack() {
      try {
        console.log("\u2B05\uFE0F Going back to home...");
        await this.navigateToHome();
      } catch (error) {
        console.error("Error going back:", error);
      }
    }
    /**
     * Délai avant la prochaine recherche (10-15 secondes)
     */
    async delayBeforeNextSearch() {
      const delay = this.SEARCH_DELAY_MIN + Math.random() * (this.SEARCH_DELAY_MAX - this.SEARCH_DELAY_MIN);
      console.log(`\u23F3 Waiting ${Math.round(delay / 1e3)}s before next search...`);
      await this.sleep(delay);
    }
    /**
     * Pause aléatoire occasionnelle (5% de chance)
     */
    async randomPause() {
      if (Math.random() < 0.05) {
        const pauseDuration = 500 + Math.random() * 1e3;
        console.log(`\u23F8\uFE0F Random pause: ${Math.round(pauseDuration)}ms`);
        await this.sleep(pauseDuration);
      }
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };

  // src/content/profile-analyzer.ts
  var ProfileAnalyzer = class {
    /**
     * Extrait les statistiques d'un profil Instagram
     */
    extractProfileStats() {
      try {
        const username = this.extractUsernameFromUrl();
        if (!username) {
          console.error("\u274C Cannot extract username from URL");
          return null;
        }
        const header = document.querySelector("header");
        if (!header) {
          console.error("\u274C Profile header not found");
          return null;
        }
        const statSpans = header.querySelectorAll("span");
        const stats = [];
        for (const span of Array.from(statSpans)) {
          const text = span.textContent?.trim() || "";
          const match = text.match(/^([\d,\.]+)([KMk]?)$/);
          if (match) {
            let value = parseFloat(match[1].replace(/,/g, ""));
            const unit = match[2].toUpperCase();
            if (unit === "K") value *= 1e3;
            if (unit === "M") value *= 1e6;
            stats.push(Math.floor(value));
          }
        }
        let posts = 0;
        let followers = 0;
        let following = 0;
        if (stats.length >= 3) {
          posts = stats[0];
          followers = stats[1];
          following = stats[2];
        } else {
          const links = header.querySelectorAll("a");
          for (const link of Array.from(links)) {
            const href = link.getAttribute("href") || "";
            const text = link.textContent?.trim() || "";
            if (href.includes("/followers/")) {
              const match = text.match(/([\d,\.]+)([KMk]?)/);
              if (match) {
                followers = this.parseCount(match[1], match[2]);
              }
            } else if (href.includes("/following/")) {
              const match = text.match(/([\d,\.]+)([KMk]?)/);
              if (match) {
                following = this.parseCount(match[1], match[2]);
              }
            }
          }
          const postsText = Array.from(statSpans).find(
            (span) => span.textContent?.includes("post") || span.textContent?.includes("publication")
          );
          if (postsText) {
            const match = postsText.textContent?.match(/([\d,\.]+)([KMk]?)/);
            if (match) {
              posts = this.parseCount(match[1], match[2]);
            }
          }
        }
        const hasCustomAvatar = this.hasCustomAvatar();
        const profileStats = {
          posts,
          followers,
          following,
          hasCustomAvatar,
          username
        };
        console.log("\u{1F4CA} Profile stats extracted:", profileStats);
        return profileStats;
      } catch (error) {
        console.error("Error extracting profile stats:", error);
        return null;
      }
    }
    /**
     * Parse un nombre avec unité (K, M)
     */
    parseCount(value, unit) {
      let num = parseFloat(value.replace(/,/g, ""));
      const upperUnit = unit.toUpperCase();
      if (upperUnit === "K") num *= 1e3;
      if (upperUnit === "M") num *= 1e6;
      return Math.floor(num);
    }
    /**
     * Extrait le username depuis l'URL
     */
    extractUsernameFromUrl() {
      const match = window.location.pathname.match(/^\/([a-zA-Z0-9._]+)/);
      return match ? match[1] : null;
    }
    /**
     * Vérifie si le profil a un avatar personnalisé (pas l'avatar par défaut)
     */
    hasCustomAvatar() {
      try {
        const header = document.querySelector("header");
        if (!header) return false;
        const img = header.querySelector("img");
        if (!img) return false;
        const src = img.getAttribute("src") || "";
        if (src.includes("44884218_345707102882519") || src.includes("default_profile")) {
          return false;
        }
        const width = img.naturalWidth || img.width;
        const height = img.naturalHeight || img.height;
        if (width <= 150 && height <= 150) {
          return false;
        }
        return true;
      } catch (error) {
        console.error("Error checking avatar:", error);
        return true;
      }
    }
    /**
     * Détermine si un profil est bloqué (profil vide)
     * Critères: 0 posts, 0 followers, 0 following, avatar par défaut
     */
    isBlocked(stats) {
      if (stats.posts === 0 && stats.followers === 0 && stats.following === 0 && !stats.hasCustomAvatar) {
        console.log(`\u{1F6AB} Profile @${stats.username} is BLOCKED (empty profile)`);
        return true;
      }
      if (stats.posts === 0 && stats.followers === 0 && !stats.hasCustomAvatar) {
        console.log(`\u{1F6AB} Profile @${stats.username} is likely BLOCKED (no posts, no followers, default avatar)`);
        return true;
      }
      console.log(`\u2705 Profile @${stats.username} is NORMAL (not blocked)`);
      return false;
    }
    /**
     * Attend que le profil soit complètement chargé
     */
    async waitForProfileLoad(timeout = 5e3) {
      const startTime = Date.now();
      while (Date.now() - startTime < timeout) {
        const header = document.querySelector("header");
        if (header) {
          await this.sleep(500);
          return true;
        }
        await this.sleep(100);
      }
      console.error("\u23F1\uFE0F Timeout waiting for profile to load");
      return false;
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };

  // src/background/account-storage.ts
  var PER_ACCOUNT_KEYS = /* @__PURE__ */ new Set([
    "followerDatabase",
    "followersCache",
    "sessionStats",
    "lastFollowerCount",
    "lastFollowerCountSource",
    "lastFollowerCountAt",
    "lastFollowerCountOwner",
    "userInfo",
    "unfollowerDetected",
    "unfollowerCount",
    "unfollowerDetectedAt",
    "syncQueue",
    "lastNotificationCheck",
    "lastSync",
    "lastFullSync",
    "scanProgress",
    "unfollowerAnalysisProgress",
    "pendingNewFollowerScan",
    "dm_messages"
  ]);
  var REGISTRY_KEY = "accountRegistry";
  var ACTIVE_KEY = "activeDsUserId";
  var PRIMARY_KEY = "primaryDsUserId";
  function nsKey(dsUserId, key) {
    return `acct:${dsUserId}:${key}`;
  }
  function resolveKey(activeDsUserId, primaryDsUserId, key) {
    if (activeDsUserId && primaryDsUserId && activeDsUserId !== primaryDsUserId && PER_ACCOUNT_KEYS.has(key)) {
      return nsKey(activeDsUserId, key);
    }
    return key;
  }
  async function getActiveDsUserId() {
    const stored = await chrome.storage.local.get(ACTIVE_KEY);
    return stored[ACTIVE_KEY] ?? null;
  }
  async function setActiveDsUserId(dsUserId) {
    await chrome.storage.local.set({ [ACTIVE_KEY]: dsUserId });
  }
  async function getPrimaryDsUserId() {
    const stored = await chrome.storage.local.get(PRIMARY_KEY);
    return stored[PRIMARY_KEY] ?? null;
  }
  async function setPrimaryDsUserId(dsUserId) {
    await chrome.storage.local.set({ [PRIMARY_KEY]: dsUserId });
  }
  async function ensurePrimaryAccount(dsUserId) {
    const current = await getPrimaryDsUserId();
    if (!current) {
      await setPrimaryDsUserId(dsUserId);
      await recoverPrimaryFromNamespace(dsUserId);
      return true;
    }
    return current === dsUserId;
  }
  async function recoverPrimaryFromNamespace(dsUserId) {
    try {
      const keys = Array.from(PER_ACCOUNT_KEYS);
      const nsKeys = keys.map((k) => nsKey(dsUserId, k));
      const [globalData, nsData] = await Promise.all([
        chrome.storage.local.get(keys),
        chrome.storage.local.get(nsKeys)
      ]);
      const globalDb = globalData.followerDatabase;
      const nsDb = nsData[nsKey(dsUserId, "followerDatabase")];
      const globalEmpty = !globalDb?.isInitialized && (globalDb?.totalCount ?? 0) === 0;
      const nsHasData = (nsDb?.totalCount ?? 0) > 0;
      if (globalEmpty && nsHasData) {
        const toSet = {};
        for (const k of keys) {
          const v = nsData[nsKey(dsUserId, k)];
          if (v !== void 0) toSet[k] = v;
        }
        if (Object.keys(toSet).length > 0) {
          await chrome.storage.local.set(toSet);
          console.log(`\u267B\uFE0F Donn\xE9es du compte principal restaur\xE9es depuis le namespace (${Object.keys(toSet).length} cl\xE9s)`);
        }
      }
    } catch (e) {
      console.error("recoverPrimaryFromNamespace error:", e);
    }
  }
  async function getAccountRegistry() {
    const stored = await chrome.storage.local.get(REGISTRY_KEY);
    const reg = stored[REGISTRY_KEY];
    if (reg && reg.accounts) return reg;
    return { accounts: {} };
  }
  async function setAccountRegistry(reg) {
    await chrome.storage.local.set({ [REGISTRY_KEY]: reg });
  }
  async function upsertAccount(dsUserId, patch) {
    const reg = await getAccountRegistry();
    const existing = reg.accounts[dsUserId];
    const merged = {
      dsUserId,
      igUsername: patch.igUsername ?? existing?.igUsername ?? "",
      accountId: patch.accountId ?? existing?.accountId,
      avatarUrl: patch.avatarUrl ?? existing?.avatarUrl,
      linkedAt: existing?.linkedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
      dismissed: patch.dismissed ?? existing?.dismissed
    };
    reg.accounts[dsUserId] = merged;
    await setAccountRegistry(reg);
    return merged;
  }
  async function isAccountLinked(dsUserId) {
    const reg = await getAccountRegistry();
    const entry = reg.accounts[dsUserId];
    return !!entry && !!entry.accountId;
  }
  async function accountGet(keys) {
    const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
    const keyList = Array.isArray(keys) ? keys : [keys];
    const physicalToLogical = /* @__PURE__ */ new Map();
    for (const key of keyList) {
      physicalToLogical.set(resolveKey(active, primary, key), key);
    }
    const physicalKeys = Array.from(physicalToLogical.keys());
    const raw = await chrome.storage.local.get(physicalKeys);
    const out = {};
    for (const [physical, value] of Object.entries(raw)) {
      const logical = physicalToLogical.get(physical) ?? physical;
      out[logical] = value;
    }
    return out;
  }
  async function accountSet(obj) {
    const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
    const physical = {};
    for (const [key, value] of Object.entries(obj)) {
      physical[resolveKey(active, primary, key)] = value;
    }
    await chrome.storage.local.set(physical);
  }
  async function accountRemove(keys) {
    const [active, primary] = await Promise.all([getActiveDsUserId(), getPrimaryDsUserId()]);
    const keyList = Array.isArray(keys) ? keys : [keys];
    await chrome.storage.local.remove(keyList.map((k) => resolveKey(active, primary, k)));
  }
  async function migrateLegacyKeysToAccount(dsUserId, igUsername) {
    const flagKey = `migratedLegacyFor:${dsUserId}`;
    const flagStore = await chrome.storage.local.get(flagKey);
    if (flagStore[flagKey]) return;
    const legacyKeys = Array.from(PER_ACCOUNT_KEYS);
    const legacy = await chrome.storage.local.get(legacyKeys);
    const legacyUsername = legacy.userInfo?.username;
    const hasLegacyData = legacyKeys.some((k) => legacy[k] !== void 0);
    const belongsToThisAccount = hasLegacyData && !!legacyUsername && !!igUsername && legacyUsername.toLowerCase() === igUsername.toLowerCase();
    if (belongsToThisAccount) {
      const toSet = {};
      const toRemove = [];
      for (const key of legacyKeys) {
        if (legacy[key] !== void 0) {
          const nsk = nsKey(dsUserId, key);
          toSet[nsk] = legacy[key];
          toRemove.push(key);
        }
      }
      const existing = await chrome.storage.local.get(Object.keys(toSet));
      const filtered = {};
      for (const [nsk, value] of Object.entries(toSet)) {
        if (existing[nsk] === void 0) filtered[nsk] = value;
      }
      if (Object.keys(filtered).length > 0) {
        await chrome.storage.local.set(filtered);
      }
      await chrome.storage.local.remove(toRemove);
      console.log(`\u{1F500} Migration legacy \u2192 @${igUsername} (${dsUserId}): ${toRemove.length} cl\xE9s`);
    } else if (hasLegacyData) {
      console.log(
        `\u23ED\uFE0F Pas de migration pour ${dsUserId} (@${igUsername || "?"}) : donn\xE9es legacy appartiennent \xE0 @${legacyUsername || "?"} \u2014 base vierge`
      );
    }
    await chrome.storage.local.set({ [flagKey]: true });
  }

  // src/content/unfollower-detector.ts
  var UnfollowerDetector = class {
    constructor() {
      this.isRunning = false;
      this.maxSearches = 20;
      this.searchCount = 0;
      this.scroller = new InstagramModalScroller({
        maxScrollAttempts: 6,
        scrollDelay: 400,
        waitForLoadTimeout: 8e3
      });
      this.searcher = new InstagramSearchAutomator();
      this.analyzer = new ProfileAnalyzer();
    }
    /**
     * Lance l'analyse complète des unfollowers
     */
    async analyzeUnfollowers(currentUsername) {
      if (this.isRunning) {
        throw new Error("Analysis already in progress");
      }
      this.isRunning = true;
      this.searchCount = 0;
      const result = {
        totalMissing: 0,
        unfollowed: [],
        blocked: [],
        notFoundOnInstagram: [],
        errors: []
      };
      try {
        console.log("\u{1F3AC} Starting unfollower analysis...");
        console.log("\u{1F4CA} Phase 1: Scanning current followers...");
        const currentFollowers = await this.scanCurrentFollowers(currentUsername);
        console.log(`\u2705 Current followers scanned: ${currentFollowers.length}`);
        console.log("\u{1F4CA} Phase 2: Comparing with database...");
        const missingFollowers = await this.findMissingFollowers(currentFollowers);
        result.totalMissing = missingFollowers.length;
        console.log(`\u{1F50D} Missing followers: ${missingFollowers.length}`);
        if (missingFollowers.length === 0) {
          console.log("\u2705 No unfollowers detected");
          await accountSet({ unfollowerDetected: false, unfollowerCount: 0 });
          await this.setUnfollowerBadge(0);
          return result;
        }
        await accountSet({
          unfollowerDetected: true,
          unfollowerCount: missingFollowers.length,
          unfollowerDetectedAt: Date.now()
        });
        await this.setUnfollowerBadge(missingFollowers.length);
        console.log("\u{1F6AA} Closing followers modal...");
        await this.closeFollowersModal();
        await this.sleep(2e3);
        console.log("\u{1F4CA} Phase 3: Checking missing followers via URL navigation...");
        await this.updateProgress("Checking unfollowers...", 0, missingFollowers.length);
        localStorage.removeItem("notificationCheckerAutoState");
        await chrome.storage.local.set({ isAnalyzing: true });
        await this.initializeUrlCheckState(currentUsername, missingFollowers);
        if (missingFollowers.length > 0) {
          console.log(`\u27A1\uFE0F Navigating to first profile: @${missingFollowers[0]}`);
          window.location.href = `https://www.instagram.com/${missingFollowers[0]}/`;
          return result;
        }
        console.log("\u{1F4CA} Phase 4: Sending results to backend...");
        await this.sendResultsToBackend(result);
        console.log("\u2705 Unfollower analysis completed");
        console.log(`\u{1F4CA} Results: ${result.unfollowed.length} unfollows, ${result.blocked.length} blocked, ${result.notFoundOnInstagram.length} not found`);
        return result;
      } catch (error) {
        console.error("Error during unfollower analysis:", error);
        throw error;
      } finally {
        this.isRunning = false;
      }
    }
    /**
     * Scan complet des followers actuels via le modal.
     * Comportement éprouvé : la modale des followers doit être OUVERTE MANUELLEMENT
     * avant de lancer l'analyse. On scrolle simplement la liste déjà affichée.
     * (Le paramètre myUsername est conservé pour compat d'appel, non utilisé ici.)
     */
    async scanCurrentFollowers(_myUsername) {
      try {
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) {
          throw new Error(
            "Ouvre d'abord la liste de tes followers (clique sur \xAB followers \xBB sur ton profil), puis relance l'analyse."
          );
        }
        const followers = await this.scroller.scrollToEnd();
        return followers;
      } catch (error) {
        console.error("Error scanning current followers:", error);
        throw error;
      }
    }
    /**
     * Ouvre la modale des followers en cliquant sur le lien /followers/ de la page
     * de profil courante. Renvoie l'élément de la modale, ou null si le lien est
     * introuvable (typiquement : on n'est pas sur la page de profil).
     */
    async openFollowersModal(myUsername) {
      const clickableAncestor = (el) => el.closest('a, button, [role="button"], [role="link"], li') || el;
      const findTarget = () => {
        if (myUsername) {
          const exact = document.querySelector(
            `a[href="/${myUsername}/followers/"]`
          );
          if (exact) return exact;
        }
        const anchors = Array.from(document.querySelectorAll("a[href]"));
        const byHref = anchors.find((a) => {
          try {
            return /\/followers\/?$/.test(new URL(a.href, location.origin).pathname);
          } catch {
            return false;
          }
        });
        if (byHref) return byHref;
        const candidates = Array.from(document.querySelectorAll("a, span, button, div, li")).filter((el) => {
          const t = (el.textContent || "").trim();
          return /\b(followers|abonn[ée]s?)\b/i.test(t) && t.length > 0 && t.length < 40;
        }).sort((a, b) => (a.textContent || "").length - (b.textContent || "").length);
        return candidates.length ? clickableAncestor(candidates[0]) : null;
      };
      let target = null;
      for (let attempts = 0; attempts < 8 && !target; attempts++) {
        target = findTarget();
        if (!target) await this.sleep(500);
      }
      if (!target) {
        console.warn(
          '\u26A0\uFE0F \xC9l\xE9ment "followers" introuvable (es-tu sur ta page de profil ?).'
        );
        return null;
      }
      console.log("\u{1F517} Cible followers trouv\xE9e:", target.tagName, (target.textContent || "").trim().slice(0, 30), "\u2014 ouverture...");
      target.scrollIntoView({ block: "center" });
      target.click();
      for (let i = 0; i < 12; i++) {
        await this.sleep(500);
        const modal = document.querySelector('[role="dialog"]');
        if (modal && modal.querySelectorAll('a[href^="/"]').length >= 3) {
          console.log("\u2705 Modale des followers ouverte");
          await this.sleep(800);
          return modal;
        }
      }
      console.warn("\u26A0\uFE0F Clic effectu\xE9 mais aucune liste de followers d\xE9tect\xE9e");
      return null;
    }
    /**
     * Compare les followers actuels avec la base de données
     */
    async findMissingFollowers(currentFollowers) {
      try {
        const stored = await accountGet("followerDatabase");
        const followerDatabase = stored.followerDatabase;
        if (!followerDatabase || !followerDatabase.followers) {
          console.warn("\u26A0\uFE0F No follower database found");
          return [];
        }
        const previousFollowers = Object.keys(followerDatabase.followers);
        console.log(`\u{1F4CA} Previous followers: ${previousFollowers.length}`);
        console.log(`\u{1F4CA} Current followers: ${currentFollowers.length}`);
        const currentSet = new Set(currentFollowers.map((u) => u.toLowerCase().trim()));
        const missing = previousFollowers.filter(
          (username) => !currentSet.has(username.toLowerCase().trim())
        );
        console.log(`\u{1F50D} Missing followers: ${missing.length}`);
        return missing;
      } catch (error) {
        console.error("Error finding missing followers:", error);
        throw error;
      }
    }
    /**
     * Envoie les résultats au backend
     */
    async sendResultsToBackend(result) {
      try {
        console.log("\u{1F4E4} Sending results to backend...");
        const response = await chrome.runtime.sendMessage({
          type: "SEND_UNFOLLOWER_RESULTS",
          data: {
            unfollowedUsernames: result.unfollowed,
            blockedUsernames: result.blocked,
            missingUsernames: result.notFoundOnInstagram
          }
        });
        if (response && response.success) {
          console.log("\u2705 Results sent to backend successfully");
          await chrome.runtime.sendMessage({
            type: "UPDATE_UNFOLLOWER_STATS",
            data: {
              unfollowers: result.unfollowed.length,
              ghost: result.blocked.length + result.notFoundOnInstagram.length
            }
          });
          if (result.notFoundOnInstagram.length > 0) {
            console.log(`\u{1F916} D\xE9clenchement de l'Agent B pour ${result.notFoundOnInstagram.length} unfollowers non trouv\xE9s`);
            await this.triggerAgentB(result.notFoundOnInstagram);
          }
        } else {
          console.error("\u274C Failed to send results to backend:", response);
        }
      } catch (error) {
        console.error("Error sending results to backend (non-fatal):", error);
      }
    }
    /**
     * Déclenche l'Agent B pour vérifier les unfollowers via Google
     */
    async triggerAgentB(missingUsernames) {
      try {
        console.log(`\u{1F916} Triggering Agent B for ${missingUsernames.length} usernames...`);
        const response = await chrome.runtime.sendMessage({
          type: "TRIGGER_AGENT_B",
          data: {
            missingUsernames
          }
        });
        if (response && response.success) {
          console.log("\u2705 Agent B triggered successfully");
          console.log(`\u{1F50D} Agent B will verify these usernames via Google search`);
        } else {
          console.error("\u274C Failed to trigger Agent B:", response);
        }
      } catch (error) {
        console.error("Error triggering Agent B:", error);
      }
    }
    /**
     * Met à jour le badge de l'extension pour les unfollowers détectés par
     * l'analyse (couleur ambre). `count <= 0` efface le badge.
     */
    async setUnfollowerBadge(count) {
      try {
        await chrome.runtime.sendMessage({
          type: "UPDATE_BADGE",
          text: count > 0 ? `-${count}` : "",
          color: "#f59e0b"
        });
      } catch (error) {
        console.log("\u26A0\uFE0F Impossible de mettre \xE0 jour le badge unfollower:", error);
      }
    }
    /**
     * Met à jour la progression (pour l'overlay)
     */
    async updateProgress(message, current, total) {
      try {
        await chrome.runtime.sendMessage({
          type: "UNFOLLOWER_ANALYSIS_PROGRESS",
          data: {
            message,
            current,
            total,
            percentage: Math.round(current / total * 100)
          }
        });
      } catch (error) {
      }
    }
    /**
     * Vérifie si une analyse est en cours
     */
    isAnalysisRunning() {
      return this.isRunning;
    }
    /**
     * Arrête l'analyse en cours
     */
    stopAnalysis() {
      this.isRunning = false;
      console.log("\u23F9\uFE0F Analysis stopped by user");
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Ferme le modal followers s'il est ouvert
     */
    async closeFollowersModal() {
      try {
        const closeButton = document.querySelector('[role="dialog"] svg[aria-label="Close"], [role="dialog"] button[aria-label="Close"]');
        if (closeButton) {
          console.log("\u2705 Found close button, clicking...");
          closeButton.click();
          await this.sleep(1e3);
        } else {
          console.log("\u2328\uFE0F Pressing Escape to close modal...");
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", keyCode: 27 }));
          await this.sleep(1e3);
        }
        console.log("\u2705 Modal closed");
      } catch (error) {
        console.error("Error closing modal:", error);
      }
    }
    /**
     * Initialise l'état pour la vérification par URL dans localStorage
     */
    async initializeUrlCheckState(myUsername, missingFollowers) {
      const state = {
        currentIndex: 0,
        startedAt: Date.now(),
        // horodatage : permet à l'init de purger un état périmé
        myUsername,
        missingFollowers,
        results: {
          unfollowed: [],
          blocked: [],
          notFoundOnInstagram: []
        }
      };
      localStorage.setItem("unfollowerCheckState", JSON.stringify(state));
      console.log("\u{1F4BE} State initialized in localStorage");
    }
    /**
     * Vérifie la page actuelle pour un unfollower (appelé automatiquement sur chaque page)
     */
    async checkCurrentPageForUnfollower() {
      const stateStr = localStorage.getItem("unfollowerCheckState");
      if (!stateStr) {
        return;
      }
      const state = JSON.parse(stateStr);
      try {
        const dbStore = await accountGet("followerDatabase");
        const dbCount = Object.keys(dbStore.followerDatabase?.followers || {}).length;
        const missingTotal = Array.isArray(state.missingFollowers) ? state.missingFollowers.length : 0;
        if (dbCount > 0 && missingTotal > dbCount * 0.7) {
          console.warn(
            `\u{1F6D1} \xC9tat d'analyse corrompu (${missingTotal}/${dbCount} "manquants") \u2014 annulation et nettoyage, pas de boucle.`
          );
          localStorage.removeItem("unfollowerCheckState");
          await chrome.storage.local.set({ isAnalyzing: false });
          await accountSet({ unfollowerDetected: false, unfollowerCount: 0 });
          return;
        }
      } catch (e) {
      }
      const currentUrl = window.location.href;
      const currentUsername = currentUrl.match(/instagram\.com\/([^\/]+)/)?.[1];
      console.log(`\u{1F4CD} Current page: @${currentUsername}`);
      const systemPages = ["notifications", "explore", "direct", "accounts", "settings"];
      const isSystemPage = systemPages.some((page) => currentUrl.includes(`/${page}`));
      if (isSystemPage) {
        console.log("\u26A0\uFE0F On a system page, redirecting to expected profile...");
        const expectedUsername2 = state.missingFollowers[state.currentIndex];
        if (expectedUsername2) {
          console.log(`\u27A1\uFE0F Navigating to @${expectedUsername2}...`);
          window.location.href = `https://www.instagram.com/${expectedUsername2}/`;
        } else {
          console.log(`\u{1F3E0} Returning to profile @${state.myUsername}...`);
          window.location.href = `https://www.instagram.com/${state.myUsername}/`;
        }
        return;
      }
      if (currentUsername === state.myUsername && state.currentIndex >= state.missingFollowers.length) {
        console.log("\n\u2705 All checks completed!");
        console.log("\u{1F4CA} Results:");
        console.log(`   - Unfollowed: ${state.results.unfollowed.length}`, state.results.unfollowed);
        console.log(`   - Blocked: ${state.results.blocked.length}`, state.results.blocked);
        console.log(`   - Not found: ${state.results.notFoundOnInstagram.length}`, state.results.notFoundOnInstagram);
        try {
          await this.sendResultsToBackend({
            totalMissing: state.missingFollowers.length,
            unfollowed: state.results.unfollowed,
            blocked: state.results.blocked,
            notFoundOnInstagram: state.results.notFoundOnInstagram,
            errors: []
          });
          if (state.results.notFoundOnInstagram.length > 0) {
            console.log(`
\u{1F916} Triggering Agent B for ${state.results.notFoundOnInstagram.length} usernames...`);
            await this.triggerAgentB(state.results.notFoundOnInstagram);
          }
        } catch (error) {
          console.error("\u26A0\uFE0F Erreur envoi r\xE9sultats (cleanup continue quand m\xEAme):", error);
        } finally {
          localStorage.removeItem("unfollowerCheckState");
          await chrome.storage.local.set({ isAnalyzing: false });
          await accountSet({
            unfollowerDetected: false,
            unfollowerCount: 0
          });
          try {
            await chrome.runtime.sendMessage({
              type: "ANALYSIS_COMPLETED",
              data: {
                unfollowers: state.results.unfollowed.length,
                blocked: state.results.blocked.length,
                notFound: state.results.notFoundOnInstagram.length
              }
            });
            console.log("\u2705 Analysis completed notification sent");
          } catch (msgError) {
            console.error("\u26A0\uFE0F Impossible d'envoyer ANALYSIS_COMPLETED:", msgError);
          }
        }
        return;
      }
      const expectedUsername = state.missingFollowers[state.currentIndex];
      if (currentUsername === expectedUsername) {
        console.log(`
\u{1F50D} [${state.currentIndex + 1}/${state.missingFollowers.length}] Analyzing @${expectedUsername}...`);
        await this.sleep(3e3);
        const pageContent = document.body.textContent || "";
        const pageHTML = document.body.innerHTML || "";
        if (pageContent.includes("Vous ne pouvez pas acc\xE9der") || pageContent.includes("You can't access") || pageContent.includes("This Account is Private")) {
          console.log(`\u{1F6AB} @${expectedUsername} classified as BLOCKED`);
          state.results.blocked.push(expectedUsername);
        } else if (pageContent.includes("Utilisateur introuvable") || pageContent.includes("Sorry, this page") || pageContent.includes("isn't available") || pageContent.includes("Page not found") || pageHTML.includes("Page Not Found")) {
          console.log(`\u274C @${expectedUsername} classified as DELETED/NOT FOUND`);
          state.results.notFoundOnInstagram.push(expectedUsername);
        } else {
          const followsYou = /follows you|vous suit/i.test(pageContent);
          const pageLoaded = pageContent.length > 200;
          if (followsYou) {
            console.log(`\u2705 @${expectedUsername} te suit encore \u2014 ignor\xE9 (faux positif, non class\xE9)`);
          } else if (!pageLoaded) {
            console.log(`\u23F3 @${expectedUsername} page non charg\xE9e \u2014 inconclusif, non class\xE9`);
          } else {
            console.log(`\u{1F44B} @${expectedUsername} classified as UNFOLLOWED`);
            state.results.unfollowed.push(expectedUsername);
          }
        }
        state.currentIndex++;
        localStorage.setItem("unfollowerCheckState", JSON.stringify(state));
        const delay = 5e3 + Math.random() * 5e3;
        const delaySec = Math.round(delay / 1e3);
        console.log(`\u23F8\uFE0F Waiting ${delaySec} seconds before next check...`);
        await this.sleep(delay);
        if (state.currentIndex < state.missingFollowers.length) {
          const nextUsername = state.missingFollowers[state.currentIndex];
          console.log(`\u27A1\uFE0F Navigating to @${nextUsername}...`);
          window.location.href = `https://www.instagram.com/${nextUsername}/`;
        } else {
          console.log(`\u{1F3E0} Returning to profile @${state.myUsername}...`);
          window.location.href = `https://www.instagram.com/${state.myUsername}/`;
        }
      } else {
        console.log(`\u26A0\uFE0F Wrong page! Expected @${expectedUsername} but on @${currentUsername}`);
        console.log(`\u27A1\uFE0F Redirecting to @${expectedUsername}...`);
        window.location.href = `https://www.instagram.com/${expectedUsername}/`;
      }
    }
  };

  // src/content/notification-checker.ts
  var NotificationChecker = class {
    /**
     * Ouvrir la page des notifications et extraire les nouveaux followers
     */
    async checkNewFollowersFromNotifications() {
      try {
        if (localStorage.getItem("unfollowerCheckState")) {
          console.log("\u{1F515} [Notifications] Analyse unfollower en cours \u2014 navigation /notifications/ annul\xE9e");
          return [];
        }
        console.log("\u{1F514} Opening notifications page...");
        const currentUrl = window.location.href;
        const isOnNotificationsPage = currentUrl.includes("/notifications/");
        if (!isOnNotificationsPage) {
          const notificationButton = document.querySelector('a[href*="/notifications/"]');
          if (notificationButton) {
            notificationButton.click();
            await this.sleep(3e3);
          } else {
            window.location.href = "https://www.instagram.com/notifications/";
            await this.sleep(3e3);
          }
        }
        const followers = await this.extractFollowNotifications();
        console.log(`\u2705 Found ${followers.length} new follower notifications`);
        if (!isOnNotificationsPage && currentUrl !== window.location.href) {
          window.location.href = currentUrl;
        }
        return followers;
      } catch (error) {
        console.error("Error checking notifications:", error);
        return [];
      }
    }
    /**
     * Extraire les notifications de type "follow" de la page actuelle.
     * Utilise des regex sur le texte directement pour éviter les faux positifs DOM.
     */
    async extractFollowNotifications() {
      const followers = [];
      try {
        await this.sleep(2e3);
        const followPatterns = [
          /^([a-zA-Z0-9._]+)\s+started following you/i,
          /^([a-zA-Z0-9._]+)\s+a commencé à vous suivre/i,
          /^([a-zA-Z0-9._]+)\s+a commencé a vous suivre/i,
          /^([a-zA-Z0-9._]+)\s+s['']est abonné/i,
          /^([a-zA-Z0-9._]+)\s+follows you\b/i
        ];
        const systemPages = /* @__PURE__ */ new Set([
          "explore",
          "reels",
          "direct",
          "p",
          "stories",
          "tv",
          "accounts",
          "notifications",
          "settings"
        ]);
        const foundUsernames = /* @__PURE__ */ new Set();
        const candidates = Array.from(document.querySelectorAll("span, div, li, article, p"));
        for (const el of candidates) {
          const text = el.textContent?.trim() || "";
          if (text.length < 5 || text.length > 250) continue;
          for (const pattern of followPatterns) {
            const match = text.match(pattern);
            if (!match) continue;
            const username = match[1];
            if (!username || systemPages.has(username) || foundUsernames.has(username)) break;
            const timeEl = el.querySelector("time") ?? el.parentElement?.querySelector("time");
            let timestamp = Date.now();
            if (timeEl) {
              const dt = timeEl.getAttribute("datetime");
              if (dt) timestamp = new Date(dt).getTime();
            } else {
              const daysMatch = text.match(/(\d+)\s*[dj]\b/);
              const hoursMatch = text.match(/(\d+)\s*h\b/);
              const minsMatch = text.match(/(\d+)\s*min\b/);
              if (daysMatch) timestamp = Date.now() - parseInt(daysMatch[1]) * 864e5;
              else if (hoursMatch) timestamp = Date.now() - parseInt(hoursMatch[1]) * 36e5;
              else if (minsMatch) timestamp = Date.now() - parseInt(minsMatch[1]) * 6e4;
              else timestamp = 0;
            }
            foundUsernames.add(username);
            followers.push({ username, timestamp, type: "follow" });
            console.log(`\u{1F4E2} Found follow notification: @${username} (${timestamp > 0 ? new Date(timestamp).toLocaleString() : "date inconnue"})`);
            break;
          }
        }
      } catch (error) {
        console.error("Error extracting follow notifications:", error);
      }
      return followers;
    }
    /**
     * Vérifier si des nouveaux followers ont été détectés dans les notifications
     * mais pas encore dans la base de données locale
     */
    async detectHiddenUnfollowers(localFollowerDatabase) {
      try {
        if (localStorage.getItem("unfollowerCheckState")) {
          console.log("\u{1F515} [Notifications] Analyse unfollower en cours \u2014 detectHiddenUnfollowers annul\xE9");
          return { newFollowersFromNotifications: [], shouldCheckUnfollowers: false };
        }
        console.log("\u{1F50D} Checking for hidden unfollowers (new follower + unfollower = 0 change)...");
        const notificationFollowers = await this.checkNewFollowersFromNotifications();
        const stored = await chrome.storage.local.get("lastNotificationCheck");
        const lastCheck = stored.lastNotificationCheck || 0;
        const recentThreshold = lastCheck > 0 ? lastCheck : Date.now() - 48 * 60 * 60 * 1e3;
        const newFollowers = notificationFollowers.filter((nf) => !localFollowerDatabase.followers[nf.username]).filter((nf) => nf.timestamp > recentThreshold).map((nf) => nf.username);
        if (newFollowers.length > 0) {
          console.log(`\u26A0\uFE0F Found ${newFollowers.length} new followers in notifications but not in database!`);
          console.log("This suggests hidden unfollowers (new follower + unfollower = 0 net change)");
          return {
            newFollowersFromNotifications: newFollowers,
            shouldCheckUnfollowers: true
          };
        }
        console.log("\u2705 No hidden unfollowers detected");
        return {
          newFollowersFromNotifications: [],
          shouldCheckUnfollowers: false
        };
      } catch (error) {
        console.error("Error detecting hidden unfollowers:", error);
        return {
          newFollowersFromNotifications: [],
          shouldCheckUnfollowers: false
        };
      }
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /**
     * Auto-exécution : Vérifie automatiquement si on doit analyser les notifications
     * Cette fonction s'exécute automatiquement au chargement de la page
     */
    async autoCheckNotifications() {
      if (localStorage.getItem("unfollowerCheckState")) {
        console.log("\u{1F515} [AutoCheck] Analyse unfollower en cours \u2014 auto-check notifications ignor\xE9");
        return;
      }
      console.log("\u{1F50D} [AutoCheck] V\xE9rification de l'\xE9tat auto-check...");
      try {
        const stateStr = localStorage.getItem("notificationCheckerAutoState");
        console.log("\u{1F50D} [AutoCheck] \xC9tat dans localStorage:", stateStr ? "TROUV\xC9" : "AUCUN");
        if (stateStr) {
          const state = JSON.parse(stateStr);
          console.log("\u{1F916} [AutoCheck] Auto-ex\xE9cution d\xE9tect\xE9e - Followers:", Object.keys(state.followers || {}).length);
          console.log("\u{1F50D} [AutoCheck] URL actuelle:", window.location.href);
          if (window.location.href.includes("/notifications/")) {
            console.log("\u2705 [AutoCheck] Sur /notifications/ - Lancement de l'analyse...");
            await this.sleep(3e3);
            console.log("\u{1F50D} [AutoCheck] D\xE9but de l'analyse des notifications...");
            const database = {
              followers: state.followers,
              isInitialized: state.isInitialized
            };
            const result = await this.detectHiddenUnfollowers(database);
            console.log("\u2705 [AutoCheck] Analyse termin\xE9e:", result);
            const returnUrl = state.returnUrl;
            if (returnUrl) {
              console.log(`\u{1F519} [AutoCheck] Retour \xE0 ${returnUrl} dans 3 secondes...`);
              setTimeout(() => {
                console.log("\u{1F504} [AutoCheck] Redirection vers:", returnUrl);
                localStorage.removeItem("notificationCheckerAutoState");
                window.location.href = returnUrl;
              }, 3e3);
            } else {
              console.log("\u26A0\uFE0F [AutoCheck] Pas d'URL de retour");
              localStorage.removeItem("notificationCheckerAutoState");
            }
          } else {
            console.log("\u26A0\uFE0F [AutoCheck] Pas sur /notifications/, URL:", window.location.href);
          }
        } else {
          console.log("\u2139\uFE0F [AutoCheck] Aucun \xE9tat auto-check en cours");
        }
      } catch (error) {
        console.error("\u274C [AutoCheck] Erreur lors de l'auto-v\xE9rification:", error);
        localStorage.removeItem("notificationCheckerAutoState");
      }
    }
    /**
     * Démarrer une vérification automatique avec redirection
     */
    async startAutoCheck(database) {
      if (localStorage.getItem("unfollowerCheckState")) {
        console.log("\u{1F515} [StartAutoCheck] Analyse unfollower en cours \u2014 startAutoCheck ignor\xE9");
        return;
      }
      console.log("\u{1F680} [StartAutoCheck] D\xE9marrage de la v\xE9rification automatique...");
      const currentUrl = window.location.href;
      console.log("\u{1F50D} [StartAutoCheck] URL actuelle:", currentUrl);
      if (!currentUrl.includes("/notifications/")) {
        const state = {
          followers: database.followers || {},
          isInitialized: database.isInitialized || false,
          returnUrl: currentUrl,
          timestamp: Date.now()
        };
        console.log("\u{1F4BE} [StartAutoCheck] Sauvegarde de l'\xE9tat (nombre de followers):", Object.keys(state.followers).length);
        try {
          const stateJson = JSON.stringify(state);
          localStorage.setItem("notificationCheckerAutoState", stateJson);
          console.log("\u2705 [StartAutoCheck] \xC9tat sauvegard\xE9 dans localStorage");
        } catch (error) {
          console.error("\u274C [StartAutoCheck] Erreur lors de la sauvegarde:", error);
          return;
        }
        const saved = localStorage.getItem("notificationCheckerAutoState");
        console.log("\u{1F50D} [StartAutoCheck] V\xE9rification sauvegarde:", saved ? "OK" : "\xC9CHEC");
        console.log("\u{1F504} [StartAutoCheck] Redirection vers /notifications/ dans 1 seconde...");
        setTimeout(() => {
          console.log("\u{1F504} [StartAutoCheck] Redirection maintenant...");
          window.location.href = "https://www.instagram.com/notifications/";
        }, 1e3);
      } else {
        console.log("\u2139\uFE0F [StartAutoCheck] D\xE9j\xE0 sur /notifications/, analyse directe...");
        await this.detectHiddenUnfollowers(database);
      }
    }
  };

  // src/content/confirm-dialog.ts
  function showConfirmDialog(message, opts = {}) {
    const title = opts.title ?? "Waler";
    const okLabel = opts.okLabel ?? "Autoriser";
    const cancelLabel = opts.cancelLabel ?? "Refuser";
    return new Promise((resolve) => {
      const backdrop = document.createElement("div");
      backdrop.style.cssText = `
      position: fixed; inset: 0; z-index: 1000000;
      background: rgba(0,0,0,0.6);
      display: flex; align-items: center; justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      animation: walerFadeIn 0.2s ease-out;
    `;
      const style2 = document.createElement("style");
      style2.textContent = `
      @keyframes walerFadeIn { from { opacity: 0 } to { opacity: 1 } }
      @keyframes walerPop { from { transform: scale(0.95); opacity: 0 } to { transform: scale(1); opacity: 1 } }
    `;
      document.head.appendChild(style2);
      const card = document.createElement("div");
      card.style.cssText = `
      background: hsl(240, 3.7%, 15.9%);
      border: 1px solid hsl(142, 70%, 50.4%, 0.3);
      color: hsl(0, 0%, 98%);
      border-radius: 14px;
      padding: 22px;
      width: 340px; max-width: calc(100vw - 40px);
      box-shadow: 0 10px 40px rgba(0,0,0,0.6);
      animation: walerPop 0.2s ease-out;
    `;
      const titleEl = document.createElement("div");
      titleEl.textContent = title;
      titleEl.style.cssText = "font-weight: 700; font-size: 15px; margin-bottom: 10px;";
      const msgEl = document.createElement("div");
      msgEl.textContent = message;
      msgEl.style.cssText = "font-size: 13px; line-height: 1.6; opacity: 0.92; margin-bottom: 18px; white-space: pre-line;";
      const actions = document.createElement("div");
      actions.style.cssText = "display: flex; gap: 10px; justify-content: flex-end;";
      const cancelBtn = document.createElement("button");
      cancelBtn.textContent = cancelLabel;
      cancelBtn.style.cssText = `
      padding: 10px 16px; border-radius: 9px; cursor: pointer; font-weight: 600; font-size: 13px;
      background: transparent; color: hsl(0,0%,90%); border: 1px solid hsl(240,3.7%,30%);
      font-family: inherit;
    `;
      const okBtn = document.createElement("button");
      okBtn.textContent = okLabel;
      okBtn.style.cssText = `
      padding: 10px 16px; border-radius: 9px; cursor: pointer; font-weight: 700; font-size: 13px;
      background: hsl(142, 70%, 50.4%); color: hsl(240,10%,3.9%); border: 1px solid hsl(142, 70%, 50.4%);
      font-family: inherit;
    `;
      let settled = false;
      const cleanup = (result) => {
        if (settled) return;
        settled = true;
        backdrop.remove();
        style2.remove();
        resolve(result);
      };
      okBtn.addEventListener("click", () => cleanup(true));
      cancelBtn.addEventListener("click", () => cleanup(false));
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) cleanup(false);
      });
      actions.appendChild(cancelBtn);
      actions.appendChild(okBtn);
      card.appendChild(titleEl);
      card.appendChild(msgEl);
      card.appendChild(actions);
      backdrop.appendChild(card);
      document.body.appendChild(backdrop);
    });
  }

  // src/content/dm-message-extractor.ts
  var _DMMessageExtractor = class _DMMessageExtractor {
    constructor() {
      this.cache = /* @__PURE__ */ new Map();
    }
    /** Vide le cache (nouveau thread). */
    reset() {
      this.cache.clear();
    }
    /** Nombre de messages uniques collectés jusqu'ici. */
    get size() {
      return this.cache.size;
    }
    /**
     * Extrait les messages actuellement visibles dans le conteneur du thread et
     * les ajoute au cache (déduplication par clé de contenu). Renvoie le nombre
     * de nouveaux messages ajoutés lors de cet appel.
     */
    extractVisible(container) {
      const rows = this.findMessageRows(container);
      if (rows.length === 0) return 0;
      const containerRect = container.getBoundingClientRect();
      const containerCenterX = containerRect.left + containerRect.width / 2;
      const separators = this.collectTimeSeparators(container);
      let added = 0;
      for (const row of rows) {
        const text = this.extractText(row);
        if (!text) continue;
        const isSent = this.isSentMessage(row, containerCenterX);
        const realTs = this.extractTimestamp(row);
        const timestamp = realTs ?? this.timestampFromSeparators(row, separators);
        const reactions = this.extractReactions(row);
        const key = `${realTs ?? "na"}|${isSent ? 1 : 0}|${text.slice(0, 60)}`;
        const existing = this.cache.get(key);
        if (existing) {
          if (existing.timestamp == null && timestamp != null) existing.timestamp = timestamp;
          continue;
        }
        this.cache.set(key, {
          messageId: key,
          text,
          isSent,
          timestamp,
          reactions
        });
        added++;
      }
      return added;
    }
    /** Renvoie tous les messages collectés, triés par timestamp croissant. */
    getAll() {
      const all = Array.from(this.cache.values());
      all.sort((a, b) => (a.timestamp ?? 0) - (b.timestamp ?? 0));
      return all;
    }
    /**
     * Détecte un reçu de lecture (« Vu » / « Seen » / « Vu à … ») affiché sous le
     * dernier message envoyé. Ce marqueur n'est visible qu'en bas du thread (le
     * message le plus récent), donc à appeler quand le bas est à l'écran.
     */
    detectSeenReceipt(container) {
      const nodes = Array.from(container.querySelectorAll("span, div"));
      for (const el of nodes) {
        if (el.children.length > 0) continue;
        const t = (el.textContent || "").trim().toLowerCase();
        if (!t || t.length > 30) continue;
        if (/^(vu|seen)\b/.test(t) || /^vu(e)?\s+(à|le|hier|aujourd)/.test(t) || /^seen\s/.test(t)) {
          return true;
        }
      }
      return false;
    }
    // ==================== Transcriptions des messages vocaux ====================
    /**
     * Déplie les transcriptions des messages vocaux VISIBLES : clique les boutons
     * « Voir la transcription » / « View transcript » pas encore ouverts, attend
     * le rendu du texte, puis renvoie le nombre de transcriptions dépliées.
     *
     * À appeler AVANT extractVisible() : une fois la transcription affichée, le
     * texte vocal devient une bulle texte standard captée par l'extraction.
     */
    async expandVoiceTranscripts(container) {
      const triggers = this.findTranscriptTriggers(container);
      let opened = 0;
      for (const btn of triggers) {
        try {
          btn.click();
          opened++;
          await this.sleep(250);
        } catch {
        }
      }
      if (opened > 0) await this.sleep(400);
      return opened;
    }
    /** Boutons/éléments cliquables « Voir la transcription » non encore ouverts. */
    findTranscriptTriggers(container) {
      const showRe = /voir la transcription|afficher la transcription|view transcript|transcription|transcript/i;
      const hideRe = /masquer|cacher|hide/i;
      const seen = /* @__PURE__ */ new Set();
      const out = [];
      const candidates = Array.from(
        container.querySelectorAll('[role="button"], button, span, div')
      );
      for (const el of candidates) {
        const label = (el.getAttribute("aria-label") || "").toLowerCase();
        const txt = (el.textContent || "").trim().toLowerCase();
        const probe = `${label} ${txt}`;
        if (!showRe.test(label) && !(txt.length <= 30 && showRe.test(txt))) continue;
        if (hideRe.test(probe)) continue;
        if (el.offsetParent === null && el.getClientRects().length === 0) continue;
        const clickable = el.closest('[role="button"], button') || el;
        if (seen.has(clickable)) continue;
        seen.add(clickable);
        out.push(clickable);
      }
      return out;
    }
    /** Détecte un message vocal (lecteur audio / bouton lecture / forme d'onde). */
    isVoiceMessage(row) {
      if (row.querySelector("audio")) return true;
      const audioLabel = row.querySelector(
        '[aria-label*="Audio" i], [aria-label*="vocal" i], [aria-label*="voice" i], [aria-label*="Lire" i], [aria-label*="Play" i], [aria-label*="Pause" i]'
      );
      return !!audioLabel;
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    /** Normalise pour le parsing : minuscules, sans accents/apostrophes, espaces compactés. */
    normSep(s) {
      return (s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/['’`]/g, "").replace(/[,]/g, " ").replace(/ /g, " ").replace(/\s+/g, " ").trim();
    }
    /**
     * Vrai si le texte est un séparateur de date/heure du thread (et non une bulle
     * de message). On exige une forme ANCRÉE (le texte entier = l'horaire) pour ne
     * pas confondre avec un message contenant une heure (« rdv à 14:30 »).
     */
    looksLikeSeparator(raw) {
      const s = this.normSep(raw);
      if (!s || s.length > 40) return false;
      if (/^(?:(?:lun|mar|mer|jeu|ven|sam|dim|mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)\.? )?(?:(?:hier|aujourdhui|today|yesterday) )?\d{1,2} ?: ?\d{2}(?: ?[ap]m)?$/.test(
        s
      )) {
        return true;
      }
      const dm = s.match(/^\d{1,2} ([a-z]+)\.?(?: \d{4})?(?: \d{1,2} ?: ?\d{2}(?: ?[ap]m)?)?$/);
      if (dm && dm[1] in _DMMessageExtractor.MONTHS) return true;
      return false;
    }
    /**
     * Convertit une heure AFFICHÉE en timestamp (ms), en prenant l'heure locale
     * actuelle (`now`) comme référence (jour le plus récent cohérent dans le passé).
     * Best-effort FR/EN. Renvoie null si non interprétable.
     */
    parseDisplayedTime(raw, now = Date.now()) {
      const s = this.normSep(raw);
      if (!s) return null;
      let hh = 12;
      let mm = 0;
      let hasTime = false;
      const tm = s.match(/(\d{1,2}) ?: ?(\d{2}) ?([ap]m)?/);
      if (tm) {
        hh = parseInt(tm[1], 10);
        mm = parseInt(tm[2], 10);
        if (tm[3] === "pm" && hh < 12) hh += 12;
        if (tm[3] === "am" && hh === 12) hh = 0;
        hasTime = true;
      }
      if (hh > 23 || mm > 59) return null;
      const apply = (d) => {
        d.setHours(hh, mm, 0, 0);
        return d.getTime();
      };
      const tokens = s.split(" ");
      if (/\bhier\b|\byesterday\b/.test(s)) {
        const d = new Date(now);
        d.setDate(d.getDate() - 1);
        return apply(d);
      }
      if (/aujourdhui|\btoday\b/.test(s)) {
        return apply(new Date(now));
      }
      let monthIdx = -1;
      for (const t of tokens) {
        const mi = _DMMessageExtractor.MONTHS[t.replace(".", "")];
        if (mi !== void 0) {
          monthIdx = mi;
          break;
        }
      }
      if (monthIdx >= 0) {
        let day = NaN;
        let year = NaN;
        for (const t of tokens) {
          if (/^\d{1,2}$/.test(t) && isNaN(day)) day = parseInt(t, 10);
          else if (/^\d{4}$/.test(t)) year = parseInt(t, 10);
        }
        if (!isNaN(day)) {
          const d = new Date(now);
          d.setMonth(monthIdx, day);
          if (!isNaN(year)) d.setFullYear(year);
          apply(d);
          if (isNaN(year) && d.getTime() > now + 6e4) d.setFullYear(d.getFullYear() - 1);
          return d.getTime();
        }
      }
      for (const t of tokens) {
        const dow = _DMMessageExtractor.DAY_NAMES[t.replace(".", "")];
        if (dow !== void 0) {
          const d = new Date(now);
          const diff = (d.getDay() - dow + 7) % 7;
          d.setDate(d.getDate() - diff);
          apply(d);
          if (d.getTime() > now + 6e4) d.setDate(d.getDate() - 7);
          return d.getTime();
        }
      }
      if (hasTime) {
        const d = new Date(now);
        apply(d);
        if (d.getTime() > now + 6e4) d.setDate(d.getDate() - 1);
        return d.getTime();
      }
      return null;
    }
    /**
     * Recense les séparateurs de date/heure visibles, avec leur position verticale,
     * pour pouvoir attribuer une heure aux bulles situées en dessous.
     */
    collectTimeSeparators(container) {
      const now = Date.now();
      const out = [];
      const seen = /* @__PURE__ */ new Set();
      const nodes = Array.from(container.querySelectorAll("span, div, time, h5, h6"));
      for (const el of nodes) {
        if (el.children.length > 0) continue;
        const raw = (el.textContent || "").trim();
        if (!this.looksLikeSeparator(raw)) continue;
        const ts = this.parseDisplayedTime(raw, now);
        if (ts == null) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) continue;
        const k = `${Math.round(rect.top)}|${ts}`;
        if (seen.has(k)) continue;
        seen.add(k);
        out.push({ top: rect.top, ts });
      }
      out.sort((a, b) => a.top - b.top);
      return out;
    }
    /** Heure du séparateur le plus proche AU-DESSUS de la bulle (ou le 1er sinon). */
    timestampFromSeparators(row, separators) {
      if (separators.length === 0) return null;
      const top = row.getBoundingClientRect().top;
      let best = null;
      for (const s of separators) {
        if (s.top <= top + 4) best = s.ts;
        else break;
      }
      return best ?? separators[0].ts;
    }
    // ==================== DOM ====================
    findMessageRows(container) {
      let rows = Array.from(container.querySelectorAll('div[role="row"]')).filter(
        (r) => !this.isSidebarItem(r)
      );
      if (rows.length === 0) {
        const textNodes = Array.from(
          container.querySelectorAll('span[dir="auto"], div[dir="auto"]')
        );
        const set = /* @__PURE__ */ new Set();
        for (const t of textNodes) {
          if (this.isSidebarItem(t)) continue;
          const bubble = t.closest('div[role="row"]') || t.parentElement?.parentElement || t;
          if (bubble && !this.isSidebarItem(bubble)) set.add(bubble);
        }
        rows = Array.from(set);
      }
      return rows;
    }
    /**
     * Vrai si l'élément appartient à la LISTE des conversations (barre latérale) et
     * non au thread ouvert. Ces lignes sont des liens `/direct/t/<id>/` : une bulle
     * de message du thread n'en contient jamais. Sans ce filtre, quand le conteneur
     * de repli est le <main> entier, les aperçus de la barre latérale sont comptés
     * comme des « messages reçus » fantômes (ils sont à gauche → reçus).
     */
    isSidebarItem(el) {
      return !!el.closest('a[href^="/direct/t/"]') || !!el.querySelector('a[href^="/direct/t/"]');
    }
    extractText(row) {
      const textEl = row.querySelector('span[dir="auto"], div[dir="auto"]');
      let raw = (textEl?.textContent ?? row.textContent ?? "").trim();
      if (this.isVoiceMessage(row)) {
        const transcript = raw.replace(/^\d{1,2}:\d{2}\s*/, "").trim();
        if (transcript.length > 0 && !/^\d{1,2}:\d{2}$/.test(transcript)) return transcript;
        return "[message vocal]";
      }
      if (raw.length === 0) return "";
      if (this.looksLikeSeparator(raw)) return "";
      if (/^(vu|seen)\b/i.test(raw) || /^vu(e)?\s+(à|le|hier|aujourd)/i.test(raw)) return "";
      return raw;
    }
    isSentMessage(row, containerCenterX) {
      const rect = row.getBoundingClientRect();
      if (rect.width === 0) {
        return !row.querySelector("img");
      }
      const center = rect.left + rect.width / 2;
      return center > containerCenterX;
    }
    /**
     * Heure EXACTE de la bulle (à la seconde), au-delà du séparateur de bloc :
     *   1. `<time datetime>` / tout `[datetime]` ISO (le plus fiable) ;
     *   2. l'heure complète qu'IG expose dans le `title` / `aria-label` de la bulle
     *      (le « tooltip » au survol, présent dans le DOM même sans survol).
     * Permet de calculer de vrais temps de réponse des DEUX côtés (les réponses
     * rapides d'un même bloc ne sont plus écrasées à delta=0).
     */
    extractTimestamp(row) {
      const dtEl = row.querySelector("time[datetime], [datetime]");
      const dt = dtEl?.getAttribute("datetime");
      if (dt) {
        const t = new Date(dt).getTime();
        if (!isNaN(t)) return t;
      }
      const carriers = [row, ...Array.from(row.querySelectorAll("[title], [aria-label]"))];
      for (const el of carriers) {
        for (const attr of ["title", "aria-label"]) {
          const v = el.getAttribute?.(attr);
          if (!v) continue;
          const ts = this.parseAttributeTime(v);
          if (ts != null) return ts;
        }
      }
      return null;
    }
    /**
     * Parse l'heure portée par un attribut (title/aria-label). Tente d'abord un
     * format ISO ; sinon réutilise le parseur d'heures affichées FR/EN, mais
     * uniquement si l'attribut contient un vrai contexte de date (sécurité).
     */
    parseAttributeTime(v) {
      const s = v.trim();
      if (!s || s.length > 80) return null;
      if (/\d{4}-\d{2}-\d{2}[t ]\d{2}:\d{2}/i.test(s)) {
        const t = Date.parse(s);
        if (!isNaN(t)) return t;
      }
      if (_DMMessageExtractor.DATE_CONTEXT_RE.test(s) && /\d{1,2} ?: ?\d{2}/.test(s)) {
        return this.parseDisplayedTime(s);
      }
      return null;
    }
    extractReactions(row) {
      const reactionEls = row.querySelectorAll('[aria-label*="reaction" i], [aria-label*="r\xE9action" i]');
      const out = [];
      reactionEls.forEach((el) => {
        const label = el.getAttribute("aria-label") || el.textContent || "";
        if (label) out.push(label.trim());
      });
      return out;
    }
  };
  // ==================== Heures affichées (séparateurs) ====================
  // Jours de la semaine (FR/EN, abrégés ou complets) → index getDay() (0 = dim).
  _DMMessageExtractor.DAY_NAMES = {
    dim: 0,
    dimanche: 0,
    sun: 0,
    sunday: 0,
    lun: 1,
    lundi: 1,
    mon: 1,
    monday: 1,
    mar: 2,
    mardi: 2,
    tue: 2,
    tues: 2,
    tuesday: 2,
    mer: 3,
    mercredi: 3,
    wed: 3,
    wednesday: 3,
    jeu: 4,
    jeudi: 4,
    thu: 4,
    thur: 4,
    thurs: 4,
    thursday: 4,
    ven: 5,
    vendredi: 5,
    fri: 5,
    friday: 5,
    sam: 6,
    samedi: 6,
    sat: 6,
    saturday: 6
  };
  // Mois (FR/EN, abrégés ou complets, accents déjà retirés) → index getMonth().
  _DMMessageExtractor.MONTHS = {
    janvier: 0,
    janv: 0,
    jan: 0,
    january: 0,
    fevrier: 1,
    fev: 1,
    fevr: 1,
    feb: 1,
    february: 1,
    mars: 2,
    march: 2,
    avril: 3,
    avr: 3,
    apr: 3,
    april: 3,
    mai: 4,
    may: 4,
    juin: 5,
    jun: 5,
    june: 5,
    juillet: 6,
    juil: 6,
    jul: 6,
    july: 6,
    aout: 7,
    aug: 7,
    august: 7,
    septembre: 8,
    sept: 8,
    sep: 8,
    september: 8,
    octobre: 9,
    oct: 9,
    october: 9,
    novembre: 10,
    nov: 10,
    november: 10,
    decembre: 11,
    dec: 11,
    december: 11
  };
  // Contexte de DATE exigé pour interpréter une heure d'attribut (évite de
  // confondre un « 14:30 » figurant dans un message avec un horodatage).
  _DMMessageExtractor.DATE_CONTEXT_RE = /\b\d{4}\b|janv|fevr|mars|avril|\bmai\b|juin|juil|aout|sept|octo|nove|dece|jan|feb|mar|apr|jun|jul|aug|oct|nov|dec|lun|mar|mer|jeu|ven|sam|dim|mon|tue|wed|thu|fri|sat|sun|hier|aujourd|today|yesterday|\bat\b|\bà\b|\bam\b|\bpm\b/i;
  var DMMessageExtractor = _DMMessageExtractor;

  // src/content/dm-thread-scroller.ts
  var DMThreadScroller = class {
    constructor(options = {}) {
      this.extractor = new DMMessageExtractor();
      /** Reçu de lecture (« Vu ») détecté sous le dernier message envoyé. */
      this.lastSeenDetected = false;
      this.maxStuckAttempts = options.maxStuckAttempts ?? 6;
      this.scrollDelay = options.scrollDelay ?? 300;
      this.onProgress = options.onProgress;
    }
    /**
     * Scrolle jusqu'en haut du thread et renvoie tous les messages extraits.
     */
    async scrollAndExtractAll() {
      const container = await this.waitForThreadContainer();
      if (!container) {
        throw new Error("Conteneur du thread DM introuvable");
      }
      this.extractor.reset();
      await this.extractor.expandVoiceTranscripts(container);
      this.extractor.extractVisible(container);
      this.lastSeenDetected = this.extractor.detectSeenReceipt(container);
      this.onProgress?.(this.extractor.size);
      if (!this.isScrollable(container)) {
        const all2 = this.extractor.getAll();
        console.log(`\u2705 [Pro] Conversation extraite (sans scroll) : ${all2.length} messages`);
        return all2;
      }
      let stuck = 0;
      let attempts = 0;
      while (stuck < this.maxStuckAttempts) {
        attempts++;
        const before = this.extractor.size;
        const atTop = await this.humanScrollUp(container);
        await this.waitForLoad(container);
        await this.extractor.expandVoiceTranscripts(container);
        this.extractor.extractVisible(container);
        this.onProgress?.(this.extractor.size);
        const added = this.extractor.size - before;
        if (added === 0 && atTop) {
          stuck++;
        } else if (added === 0) {
          stuck++;
        } else {
          stuck = 0;
        }
        if (attempts > 200) {
          console.warn("\u26A0\uFE0F [Pro] Limite de 200 scrolls atteinte dans le thread.");
          break;
        }
      }
      const all = this.extractor.getAll();
      console.log(`\u2705 [Pro] Conversation extraite : ${all.length} messages`);
      return all;
    }
    // ==================== Conteneur ====================
    /** Attend que la grille de messages du thread soit rendue (jusqu'à ~10 s). */
    async waitForThreadContainer() {
      const deadline = Date.now() + 1e4;
      while (Date.now() < deadline) {
        const container = this.findThreadContainer();
        if (container && container.querySelector('div[role="row"], span[dir="auto"]')) {
          return container;
        }
        await this.sleep(400);
      }
      return this.findThreadContainer();
    }
    findThreadContainer() {
      const grid = document.querySelector('div[role="grid"]');
      if (grid && this.isScrollable(grid)) return grid;
      const main = document.querySelector("main") || document.body;
      const divs = Array.from(main.querySelectorAll("div"));
      let best = null;
      for (const div of divs) {
        if (!this.isScrollable(div)) continue;
        if (div.querySelector('div[role="row"], span[dir="auto"]')) {
          if (!best || div.scrollHeight > best.scrollHeight) best = div;
        }
      }
      if (best) return best;
      if (grid) return grid;
      const anchors = Array.from(
        main.querySelectorAll('div[role="row"], span[dir="auto"], div[dir="auto"]')
      );
      const anchor = anchors.find((el) => !el.closest('a[href^="/direct/t/"]'));
      if (anchor) {
        let node = anchor;
        let best2 = anchor;
        while (node.parentElement && node.parentElement !== document.body) {
          node = node.parentElement;
          if (node.querySelector('a[href^="/direct/t/"]')) break;
          best2 = node;
        }
        return best2;
      }
      return null;
    }
    isScrollable(el) {
      const style2 = window.getComputedStyle(el);
      const oy = style2.overflowY;
      return (oy === "auto" || oy === "scroll") && el.scrollHeight > el.clientHeight + 10;
    }
    // ==================== Scroll ====================
    /** Scrolle vers le haut de façon progressive/humaine. Renvoie true si en haut. */
    async humanScrollUp(container) {
      const current = container.scrollTop;
      if (current <= 5) {
        container.scrollTop = 0;
        await this.sleep(this.scrollDelay);
        return true;
      }
      const baseScroll = 300 + Math.random() * 200;
      const variation = Math.random() * 200 - 100;
      const amount = Math.min(baseScroll + variation, current);
      const steps = 5 + Math.floor(Math.random() * 5);
      const stepSize = amount / steps;
      const stepDelay = 16 + Math.floor(Math.random() * 20);
      for (let i = 0; i < steps; i++) {
        container.scrollTop -= stepSize;
        await this.sleep(stepDelay);
      }
      await this.sleep(this.scrollDelay + Math.random() * 400);
      return container.scrollTop <= 5;
    }
    async waitForLoad(container) {
      const start = Date.now();
      const initialHeight = container.scrollHeight;
      while (Date.now() - start < 4e3) {
        await this.sleep(120);
        if (container.scrollHeight > initialHeight) {
          await this.sleep(200);
          return;
        }
      }
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };

  // src/content/conversation-dynamics.ts
  var HOUR = 60 * 60 * 1e3;
  var DAY = 24 * HOUR;
  var BRIEF_TOKENS = /* @__PURE__ */ new Set([
    "ok",
    "oki",
    "okay",
    "k",
    "kk",
    "d'accord",
    "daccord",
    "dac",
    "ouais",
    "oui",
    "non",
    "yep",
    "yup",
    "yes",
    "no",
    "nope",
    "mdr",
    "ptdr",
    "lol",
    "haha",
    "hahaha",
    "ah",
    "ahh",
    "aha",
    "hmm",
    "mmh",
    "ah ok",
    "ok ok",
    "cool",
    "top",
    "nickel",
    "parfait",
    "merci",
    "thx",
    "ty",
    "oki doki",
    "ca marche",
    "ca roule",
    "nice",
    "great",
    "sure",
    "np",
    "soit",
    "bien",
    "carrement",
    "grave",
    "wsh",
    "wesh",
    "jvois",
    "jvois pas",
    "ok merci",
    "super",
    "\u{1F44D}",
    "\u{1F44C}",
    "\u{1F64F}",
    "\u2764\uFE0F",
    "\u{1F525}",
    "\u{1F602}",
    "\u{1F605}",
    "\u{1F642}",
    "\u{1F609}",
    "\u{1F91D}",
    "\u2705",
    "\u{1F4AA}",
    "\u{1F64C}",
    "\u{1F604}",
    "\u{1F60A}",
    "\u{1F440}"
  ]);
  var ConversationDynamicsAnalyzer = class {
    /**
     * Calcule la dynamique d'une conversation. `messages` doit être trié par
     * timestamp croissant (cf. DMMessageExtractor.getAll()). `seenReceipt` indique
     * si un « Vu / Seen » est affiché sous le dernier message envoyé.
     */
    analyze(messages, seenReceipt = false) {
      const sorted = [...messages].sort((a, b) => (a.timestamp ?? 0) - (b.timestamp ?? 0));
      const myMsgCount = sorted.filter((m) => m.isSent).length;
      const theirMsgCount = sorted.length - myMsgCount;
      const { theirAvgResponseMs, myAvgResponseMs } = this.computeResponseTimes(sorted);
      const theirResponseRate = this.computeTheirResponseRate(sorted);
      const briefReplyRatio = this.computeBriefReplyRatio(sorted);
      const cadenceTrend = this.computeCadenceTrend(sorted);
      const last = sorted[sorted.length - 1];
      const lastMessageIsSent = last ? last.isSent : false;
      const lastTs = last?.timestamp ?? null;
      const lastMessageAgeMs = lastTs != null ? Math.max(0, Date.now() - lastTs) : null;
      const seenNotAnswered = seenReceipt && lastMessageIsSent;
      const dyn = {
        theirAvgResponseMs,
        myAvgResponseMs,
        theirResponseRate,
        briefReplyRatio,
        lastMessageIsSent,
        lastMessageAgeMs,
        seenNotAnswered,
        msgCount: sorted.length,
        myMsgCount,
        theirMsgCount,
        cadenceTrend,
        temperatureScore: 0,
        temperature: "cold"
      };
      dyn.temperatureScore = this.scoreTemperature(dyn);
      dyn.temperature = this.toTemperature(dyn.temperatureScore);
      return dyn;
    }
    /** Conseils d'action générés à partir de la dynamique (règles, FR). */
    buildAdvice(dyn) {
      const tips = [];
      if (dyn.seenNotAnswered) {
        tips.push("They saw your message without replying \u2014 follow up with a short, open question.");
      } else if (dyn.lastMessageIsSent && (dyn.lastMessageAgeMs ?? 0) > 2 * DAY) {
        tips.push("Your last message went unanswered \u2014 suggest a time slot or ask a simple question.");
      }
      if (!dyn.lastMessageIsSent) {
        tips.push("They messaged last \u2014 reply quickly to keep the momentum.");
      }
      if (dyn.theirAvgResponseMs != null && dyn.theirAvgResponseMs < 1 * HOUR && dyn.theirResponseRate >= 0.7 && dyn.temperature === "hot") {
        tips.push("High momentum: this is the right time to pitch your offer or a call.");
      }
      if (dyn.briefReplyRatio > 0.6 && dyn.theirMsgCount >= 3) {
        tips.push("Short replies: switch angles with a question that needs more than a yes/no.");
      }
      if (dyn.temperature === "cold" && (dyn.lastMessageAgeMs ?? 0) > 14 * DAY) {
        tips.push("Conversation has cooled off: a light nudge (react to a story, short natural message).");
      }
      if (dyn.cadenceTrend === "down" && dyn.temperature !== "cold") {
        tips.push("Exchanges are slowing down \u2014 suggest a concrete next step before it fades.");
      }
      if (tips.length === 0) {
        tips.push("Stable relationship \u2014 keep in touch with a valuable message now and then.");
      }
      return tips;
    }
    // ==================== Calculs ====================
    /**
     * Temps de réponse moyens : à chaque changement d'émetteur entre deux messages
     * horodatés consécutifs, le délai est imputé à celui qui RÉPOND.
     */
    computeResponseTimes(sorted) {
      const theirs = [];
      const mine = [];
      for (let i = 1; i < sorted.length; i++) {
        const prev = sorted[i - 1];
        const cur = sorted[i];
        if (prev.isSent === cur.isSent) continue;
        if (prev.timestamp == null || cur.timestamp == null) continue;
        const delta = cur.timestamp - prev.timestamp;
        if (delta <= 0 || delta > 30 * DAY) continue;
        if (cur.isSent) mine.push(delta);
        else theirs.push(delta);
      }
      return {
        theirAvgResponseMs: theirs.length ? this.avg(theirs) : null,
        myAvgResponseMs: mine.length ? this.avg(mine) : null
      };
    }
    /**
     * Taux de réponse du contact : on découpe la conversation en « blocs » de
     * messages envoyés consécutifs ; un bloc est « répondu » s'il est suivi d'un
     * message reçu. taux = blocs répondus / blocs envoyés.
     */
    computeTheirResponseRate(sorted) {
      let blocks = 0;
      let answered = 0;
      let inSentBlock = false;
      for (const m of sorted) {
        if (m.isSent) {
          if (!inSentBlock) {
            blocks++;
            inSentBlock = true;
          }
        } else {
          if (inSentBlock) answered++;
          inSentBlock = false;
        }
      }
      if (blocks === 0) return 0;
      return Math.min(1, answered / blocks);
    }
    /** Part des messages reçus qui sont « brefs » (acquiescement / emoji seul). */
    computeBriefReplyRatio(sorted) {
      const received = sorted.filter((m) => !m.isSent);
      if (received.length === 0) return 0;
      const brief = received.filter((m) => this.isBrief(m.text)).length;
      return brief / received.length;
    }
    isBrief(text) {
      const t = (text || "").trim().toLowerCase();
      if (!t) return false;
      if (t.length <= 4) return true;
      if (BRIEF_TOKENS.has(t)) return true;
      const words = t.split(/\s+/);
      if (words.length <= 2 && t.length <= 12 && words.every((w) => BRIEF_TOKENS.has(w) || w.length <= 5)) {
        return true;
      }
      return false;
    }
    /**
     * Tendance de cadence : compare l'écart moyen entre messages sur la 1ʳᵉ moitié
     * vs la 2ᵉ moitié de la conversation. Des écarts plus courts = accélération.
     */
    computeCadenceTrend(sorted) {
      const ts = sorted.map((m) => m.timestamp).filter((t) => t != null);
      if (ts.length < 6) return "flat";
      const gaps = [];
      for (let i = 1; i < ts.length; i++) gaps.push(ts[i] - ts[i - 1]);
      const mid = Math.floor(gaps.length / 2);
      const firstAvg = this.avg(gaps.slice(0, mid));
      const secondAvg = this.avg(gaps.slice(mid));
      if (firstAvg === 0 || secondAvg === 0) return "flat";
      const ratio = secondAvg / firstAvg;
      if (ratio < 0.7) return "up";
      if (ratio > 1.4) return "down";
      return "flat";
    }
    /**
     * Score de température 0-100 à partir d'une base neutre (50) ajustée par les
     * signaux comportementaux. Bornes saturées dans [0, 100].
     */
    scoreTemperature(d) {
      let s = 50;
      s += d.theirResponseRate * 25 - 5;
      if (d.theirAvgResponseMs != null) {
        if (d.theirAvgResponseMs < 1 * HOUR) s += 15;
        else if (d.theirAvgResponseMs < 6 * HOUR) s += 10;
        else if (d.theirAvgResponseMs < 1 * DAY) s += 5;
        else if (d.theirAvgResponseMs > 3 * DAY) s -= 10;
      }
      if (d.lastMessageAgeMs != null) {
        if (d.lastMessageAgeMs < 2 * DAY) s += 15;
        else if (d.lastMessageAgeMs < 7 * DAY) s += 5;
        else if (d.lastMessageAgeMs > 30 * DAY) s -= 30;
        else if (d.lastMessageAgeMs > 14 * DAY) s -= 20;
      }
      if (d.lastMessageIsSent && (d.lastMessageAgeMs ?? 0) > 2 * DAY) s -= 15;
      if (d.seenNotAnswered) s -= 10;
      if (d.briefReplyRatio > 0.6) s -= 10;
      else if (d.briefReplyRatio > 0.4) s -= 5;
      if (d.cadenceTrend === "up") s += 10;
      else if (d.cadenceTrend === "down") s -= 10;
      return Math.max(0, Math.min(100, Math.round(s)));
    }
    toTemperature(score) {
      if (score >= 66) return "hot";
      if (score >= 33) return "warm";
      return "cold";
    }
    avg(arr) {
      if (arr.length === 0) return 0;
      return arr.reduce((a, b) => a + b, 0) / arr.length;
    }
  };

  // src/content/setting-coach.ts
  var COACH_HOUR = 60 * 60 * 1e3;
  var COACH_DAY = 24 * COACH_HOUR;
  var ACTIVITY_TYPES = [
    { label: "SaaS / software", labelFr: "SaaS / logiciel", kws: ["saas", "logiciel", "mon app", "application", "extension", "plateforme", "abonnes", "suivi des abonnes", "software", "my app", "platform", "subscribers"] },
    { label: "E-commerce", labelFr: "E-commerce", kws: ["ecommerce", "e-commerce", "boutique", "shop", "dropshipping", "dropship", "shopify", "fba", "print on demand", "store", "my store", "my shop", "online store"] },
    { label: "Agency / SMMA", labelFr: "Agence / SMMA", kws: ["agence", "smma", "studio", "agency", "my agency"] },
    { label: "Coaching / courses", labelFr: "Coaching / formations", kws: ["coaching", "coach", "mentorat", "mentor", "infopreneur", "formation en ligne", "formateur", "online course", "course creator", "courses"] },
    { label: "Freelance / services", labelFr: "Freelance / services", kws: ["freelance", "consultant", "consulting", "copywriter", "closer", "setter", "ugc", "monteur", "graphiste", "designer", "developpeur", "freelancer", "developer", "video editor", "designer"] },
    { label: "Trading / crypto", labelFr: "Trading / crypto", kws: ["trading", "trader", "crypto", "forex"] },
    { label: "Content / creator", labelFr: "Cr\xE9ateur de contenu", kws: ["createur de contenu", "cr\xE9ateur de contenu", "influenceur", "influenceuse", "newsletter", "chaine youtube", "content creator", "creator", "youtuber", "tiktoker", "streamer", "influencer", "my channel", "my page"] },
    { label: "Fitness / coaching sportif", labelFr: "Fitness / coaching sportif", kws: ["coach sportif", "fitness", "nutrition", "salle de sport", "personal trainer", "fitness coach", "gym", "workout", "wellness", "musculation", "muscu", "prep physique", "dieteticien", "dietetique", "yoga", "pilates"] },
    { label: "Real estate", labelFr: "Immobilier", kws: ["immobilier", "agent immobilier", "real estate", "realtor", "property", "properties", "investissement locatif", "locatif", "lcd", "airbnb", "marchand de biens"] },
    { label: "Beauty / esthetics", labelFr: "Beaut\xE9 / esth\xE9tique", kws: ["estheticienne", "esthetique", "salon de beaute", "institut", "onglerie", "prothesiste ongulaire", "extension de cils", "coiffure", "coiffeur", "coiffeuse", "barbier", "maquilleuse", "mua", "tatoueur", "beauty salon", "nail tech", "lash tech", "hairdresser", "makeup artist"] },
    { label: "Food / restaurant", labelFr: "Restauration / food", kws: ["restaurant", "mon resto", "food truck", "traiteur", "patisserie", "boulangerie", "chef a domicile", "dark kitchen", "restauration", "cafe", "coffee shop"] },
    { label: "Health / therapy", labelFr: "Sant\xE9 / th\xE9rapie", kws: ["therapeute", "naturopathe", "sophrologue", "osteopathe", "kine", "kinesitherapeute", "praticien", "hypnotherapeute", "psychologue", "psy", "therapist", "naturopath", "wellness coach"] },
    { label: "Music / audio", labelFr: "Musique / audio", kws: ["beatmaker", "beat maker", "producteur", "prod musicale", "ingenieur son", "inge son", "dj", "mixage", "mastering", "music producer", "audio engineer", "mon label"] },
    { label: "Photo / video", labelFr: "Photo / vid\xE9o", kws: ["photographe", "videaste", "cadreur", "motion designer", "montage video", "photographer", "videographer", "filmmaker", "film maker", "reels editor"] },
    { label: "Events / wedding", labelFr: "\xC9v\xE9nementiel / mariage", kws: ["wedding planner", "evenementiel", "organisateur devenements", "traiteur evenementiel", "decoratrice", "event planner", "mes events"] }
  ];
  var OBJECTION_GROUPS = [
    { label: "Limited budget", labelFr: "Budget limit\xE9", kws: ["pas les moyens", "pas le budget", "trop cher", "cest cher", "pas dargent", "il me reste", "me reste plus", "peux pas financer", "peux pas me permettre", "jai pas les moyens", "cant afford", "too expensive", "no money", "tight budget", "no budget", "cest chaud financierement", "jsuis fauche", "jsuis a sec", "fin de mois difficile", "jai pas un rond", "pas les fonds", "ca fait beaucoup", "cest hors budget", "jpeux pas mettre autant", "a court dargent", "im broke", "low on cash", "thats a lot", "out of my budget", "cant swing that right now"] },
    { label: "Already committed elsewhere", labelFr: "D\xE9j\xE0 engag\xE9 ailleurs", kws: ["deja une formation", "deja pris une formation", "formation en cours", "jai la formation", "deja accompagne", "deja investi", "jai deja une", "pris une formation", "already have a course", "already enrolled", "already invested", "already working with", "jai deja un mentor", "jai deja un coach", "je suis deja accompagne", "jai deja achete un programme", "i already have a mentor", "i already have a coach", "im already in a program"] },
    { label: "Stalling", labelFr: "Temporise", kws: ["je verrai", "plus tard", "pas pour linstant", "pas maintenant", "on verra", "je te tiens au courant", "des que", "quand jaurai", "je te dirai", "later", "not now", "not right now", "maybe later", "ill let you know", "well see", "jverrai ca plus tard", "pas tout de suite", "apres les vacances", "apres les fetes", "le mois prochain", "quand jaurai le temps", "after the holidays", "next month", "sometime soon", "down the road", "eventually"] },
    { label: "Lack of means/availability", labelFr: "Manque de moyens / dispo", kws: ["pas dordi", "pas encore mon ordi", "jai pas le temps", "pas le temps", "pas dispo", "pas mon ordi", "no time", "dont have time", "not available", "no laptop", "no computer", "jsuis deborde", "jai trop de boulot", "pas de connexion stable", "jai pas le materiel", "pas dispo en ce moment", "im swamped", "too much on my plate", "no stable connection", "i dont have the gear"] },
    // §7.2 additions
    { label: "Procrastination", labelFr: "Procrastination", kws: ["je vais reflechir", "laisse moi y penser", "je te recontacte", "je te recontacterai", "jai besoin de temps", "je prendrai le temps", "je vais y reflechir", "ill think about it", "let me think about it", "i need to think", "ill get back to you", "ill let you know", "i need some time", "give me some time", "i need time to decide", "faut que je murisse ca", "jdois peser le pour et le contre", "jveux pas me precipiter", "laisse moi digerer", "i need to mull it over", "i dont want to rush", "let me sleep on it"] },
    { label: "Trust / proof needed", labelFr: "Confiance / preuve n\xE9cessaire", kws: ["comment je sais que ca marche", "jai deja ete decu", "cest du serieux", "jai peur de me faire avoir", "arnaque", "je fais pas confiance", "prouve moi", "jai deja ete arnaqu", "how do i know it works", "ive been scammed", "ive been burned before", "can you prove it", "show me results", "show me testimonials", "is this legit", "sounds like a scam", "do you have proof", "tas des preuves", "tas des resultats", "des temoignages", "des avis", "cest fiable", "tes qui exactement", "ca sent larnaque", "jme mefie", "any reviews", "got testimonials", "is this real", "who are you exactly", "this feels sketchy", "im skeptical of this"] }
  ];
  var OBJECTIVE_KEYWORDS = [
    "je veux",
    "je voudrais",
    "j'aimerais",
    "jaimerais",
    "aimerais",
    "j'ai envie",
    "jai envie",
    "objectif",
    "mon but",
    "besoin",
    "j'ai besoin",
    "jai besoin",
    "cherche",
    "je cherche",
    "recherche",
    "aide",
    "aider",
    "m'aider",
    "comment faire",
    "comment tu",
    "comment je",
    "des conseils",
    "un conseil",
    "accompagn",
    "me former",
    "formation",
    "apprendre",
    "me lancer",
    "lancer mon",
    "d\xE9marrer",
    "demarrer",
    "commencer",
    "progresser",
    "d\xE9velopper",
    "developper",
    "scaler",
    "scale",
    "passer \xE0 l'\xE9chelle",
    "g\xE9n\xE9rer plus",
    "gagner plus",
    "augmenter",
    "plus de clients",
    "plus de ventes",
    "mon\xE9tiser",
    "monetiser",
    "want",
    "i want",
    "i'd like",
    "looking for",
    "need",
    "help",
    "goal",
    "interested",
    "how do you",
    "how to",
    "grow",
    "scale",
    "get more clients",
    "make more",
    // ----- Argot jeune / ambition -----
    "percer",
    "je veux percer",
    "exploser",
    "d\xE9coller",
    "decoller",
    "passer un cap",
    "changer de vie",
    "devenir riche",
    "libert\xE9 financi\xE8re",
    "liberte financiere",
    "gratter",
    "je veux gratter",
    "me lancer dans",
    "me faire des sous",
    "me faire de l'argent",
    "gagner ma vie",
    "gagner plus",
    "faire du cash",
    "faire de la maille",
    "faire des thunes",
    "wesh tu fais quoi",
    "tu peux m'aider",
    "apprends moi",
    "je veux test",
    "je veux essayer",
    "tenter le truc",
    // ----- English (intent / goal) -----
    "i wanna",
    "i want to",
    "i would like",
    "id like to",
    "im trying to",
    "trying to",
    "i need help",
    "how can i",
    "how do i start",
    "where do i start",
    "get started",
    "getting started",
    "i want to start",
    "i want to learn",
    "teach me",
    "show me how",
    "any advice",
    "some advice",
    "any tips",
    "some tips",
    "i want to grow",
    "grow my",
    "scale my",
    "level up",
    "get more clients",
    "land clients",
    "close clients",
    "make money",
    "make money online",
    "making money",
    "earn more",
    "more income",
    "side income",
    "side hustle",
    "financial freedom",
    "quit my job",
    "replace my income",
    "build a business",
    "start a business",
    "monetize",
    "monetise",
    "go full time",
    "become profitable",
    "hit my goal",
    "reach my goal",
    // ----- Enrichissement FR (objectif / quête d'aide) -----
    "jaimerais arriver a",
    "mon reve cest",
    "mon objectif cest",
    "jveux atteindre",
    "jveux arriver a",
    "comment tu ferais",
    "tu conseilles quoi",
    "par ou je commence",
    "jaimerais ton avis",
    "jcherche une methode",
    "jcherche un truc qui marche",
    "jveux des resultats",
    "jveux que ca marche",
    "jveux vivre de ca",
    "jveux en faire mon metier",
    "jveux quitter mon taf",
    "jveux etre libre",
    // ----- EN -----
    "i'd love to reach",
    "my dream is",
    "my goal is",
    "i want to hit",
    "how would you do it",
    "what do you recommend",
    "where should i start",
    "id love your advice",
    "looking for a method",
    "looking for something that works",
    "i want results",
    "i want to live off this",
    "i want to do this full time",
    "i want to quit my job",
    "i want to be free",
    // ----- Enrichissement v2 FR -----
    "jaimerais me lancer dans",
    "jveux changer de vie",
    "jveux arrondir mes fins de mois",
    "jveux un complement de revenu",
    "jveux etre mon propre patron",
    "jveux arreter de subir",
    "jai besoin dun plan",
    "jveux des bases solides",
    "jveux passer pro",
    "jveux me former serieusement",
    "comment je men sors",
    "aide moi a demarrer",
    "jveux un truc concret",
    // ----- EN -----
    "i want to get into",
    "i want to change my life",
    "i want extra income on the side",
    "i want a side income",
    "i want to be my own boss",
    "i need a plan",
    "i want solid foundations",
    "i want to go pro",
    "i want to turn pro",
    "help me get started",
    "i want something concrete",
    "i want to take this seriously"
  ];
  var SITUATION_KEYWORDS = [
    "je fais",
    "je suis",
    "je bosse",
    "je travaille",
    "mon job",
    "mon taf",
    "mon boulot",
    "mon m\xE9tier",
    "mon metier",
    // NB : les noms d'entreprise (« mon business », « ma boîte »…) sont volontairement
    // SORTIS d'ici → ils sont dans BUSINESS_KEYWORDS. Sinon « je veux lancer mon
    // business » (un simple OBJECTIF) flaggait à tort la situation comme décrite.
    "freelance",
    "salari\xE9",
    "salarie",
    "\xE9tudiant",
    "etudiant",
    "au ch\xF4mage",
    "au chomage",
    "en poste",
    "depuis",
    "\xE7a fait",
    "ca fait",
    "cela fait",
    "mon mrr",
    "mon ca",
    "chiffre d'affaire",
    "chiffre daffaire",
    "ca mensuel",
    "par mois",
    "le mois dernier",
    "je gagne",
    "je g\xE9n\xE8re",
    "je genere",
    "je fais environ",
    "actuellement",
    "en ce moment",
    "aujourd'hui je",
    "mes clients",
    "mon offre",
    "mon produit",
    "i work",
    "i'm a",
    "i am a",
    "my job",
    "my business",
    "my company",
    "my agency",
    "my saas",
    "revenue",
    "mrr",
    "per month",
    "last month",
    "currently",
    "right now",
    // ----- Argot jeune / contexte -----
    "je taf",
    "je taffe",
    "mon taf",
    "je bosse dans",
    "je bosse en",
    "l\xE0 je suis",
    "la je suis",
    "en vrai je",
    "askip je",
    "je g\xE8re",
    "je gere",
    "\xE7a fait un bail",
    "ca fait un bail",
    "depuis un moment",
    // ----- English (current situation) -----
    "i do",
    "i work in",
    "i work as",
    "i work at",
    "im working",
    "i run a",
    "i started",
    "ive been",
    "i have been",
    "right now im",
    "currently im",
    "these days",
    "for the past",
    "full time",
    "part time",
    "full-time",
    "part-time",
    "im a student",
    "im employed",
    "im self employed",
    "im self-employed",
    "my niche",
    "my industry",
    "my situation",
    "i make around",
    "i earn around",
    "i generate",
    "per month i",
    "a month",
    "last month i",
    "so far ive",
    "my current",
    "at the moment",
    "i sell",
    "i offer",
    "my clients are",
    // ----- Enrichissement FR (situation actuelle / contexte) -----
    "jai commence",
    "ca fait x mois",
    "ca fait x ans",
    "jen suis a",
    "pour linstant je",
    "en gros je fais",
    "je debute",
    "je suis debutant",
    "jai pas encore",
    "jai jamais",
    "je gere mon",
    "je tiens un",
    "je suis encore au lycee",
    "je suis a la fac",
    "jsuis etudiant",
    "jsuis lyceen",
    "jhabite a",
    "jai x ans",
    "a cote de mes etudes",
    "en parallele de mon taf",
    "jai un cdi",
    "jsuis en alternance",
    "jsuis au rsa",
    // ----- EN -----
    "i just started",
    "ive been doing this for",
    "so far im at",
    "for now i",
    "basically i do",
    "im a beginner",
    "im just starting",
    "i havent yet",
    "ive never",
    "i manage a",
    "i own a small",
    "im still in school",
    "im in college",
    "im a student",
    "i live in",
    "im x years old",
    "on the side of my studies",
    "alongside my job",
    "i have a 9 to 5",
    "im an apprentice",
    // ----- Enrichissement v2 FR -----
    "jhabite chez mes parents",
    "jsuis au smic",
    "jbosse en usine",
    "jsuis livreur",
    "jsuis serveur",
    "jsuis interimaire",
    "jsuis en reconversion",
    "jai un side project",
    "jfais ca le soir",
    "jai monte ma boite",
    "jsuis a mon compte depuis",
    "jsuis au chomage",
    "jcherche du taf",
    "jsuis freelance depuis",
    "jvends deja un peu",
    // ----- EN -----
    "i live with my parents",
    "i work minimum wage",
    "i work in a warehouse",
    "im a delivery driver",
    "im a waiter",
    "im a temp",
    "im switching careers",
    "i have a side project",
    "i do this after work",
    "i started my business",
    "ive been self employed for",
    "im unemployed",
    "im job hunting",
    "i already sell a bit"
  ];
  var BUSINESS_KEYWORDS = [
    // ----- Structures & statuts -----
    "mon business",
    "mon entreprise",
    "ma boite",
    "ma bo\xEEte",
    "ma soci\xE9t\xE9",
    "ma societe",
    "ma startup",
    "ma start-up",
    "mon agence",
    "agence",
    "smma",
    "studio",
    "mon studio",
    "mon cabinet",
    "freelance",
    "auto-entrepreneur",
    "autoentrepreneur",
    "auto entrepreneur",
    "micro-entreprise",
    "entrepreneur",
    "entrepreneuse",
    "fondateur",
    "fondatrice",
    "cofondateur",
    "ceo",
    "g\xE9rant",
    "gerant",
    "ind\xE9pendant",
    "independant",
    "\xE0 mon compte",
    "a mon compte",
    "self-employed",
    "founder",
    "co-founder",
    // ----- Commerce / vente -----
    "ma boutique",
    "mon shop",
    "mon ecommerce",
    "mon e-commerce",
    "e-commerce",
    "ecommerce",
    "dropshipping",
    "dropship",
    "print on demand",
    "pod",
    "marketplace",
    "amazon fba",
    "fba",
    "shopify",
    "mon resto",
    "mon restaurant",
    "mon salon",
    "mon local",
    "commerce",
    "retail",
    "revendeur",
    "grossiste",
    // ----- Services / prestation -----
    "coach",
    "coaching",
    "mentor",
    "mentorat",
    "consultant",
    "consulting",
    "conseil",
    "prestataire",
    "prestation",
    "freelancing",
    "copywriter",
    "copywriting",
    "closer",
    "setter",
    "community manager",
    "social media manager",
    "monteur",
    "graphiste",
    "designer",
    "d\xE9veloppeur",
    "developpeur",
    "devis",
    "webdesigner",
    "ugc",
    "cr\xE9ateur de contenu",
    "createur de contenu",
    "cr\xE9atrice",
    "influenceur",
    "influenceuse",
    // ----- Niches courantes -----
    "fitness",
    "nutrition",
    "coach sportif",
    "personal trainer",
    "immobilier",
    "real estate",
    "trading",
    "trader",
    "crypto",
    "forex",
    "investissement",
    "finance",
    "marketing",
    "growth",
    "saas",
    "logiciel",
    "mon app",
    "application",
    "plateforme",
    "abonnement",
    "infopr\xE9nariat",
    "infopreneur",
    "formation en ligne",
    "mlm",
    "affiliation",
    "affiliate",
    // ----- Vocabulaire business / activité -----
    "mes clients",
    "ma client\xE8le",
    "ma clientele",
    "mon offre",
    "mes offres",
    "mon produit",
    "mes produits",
    "mon service",
    "mes services",
    "mes ventes",
    "mon ca",
    "mon chiffre",
    "chiffre d'affaire",
    "chiffre d'affaires",
    "chiffre daffaire",
    "revenus",
    "mon revenu",
    "marge",
    "b\xE9n\xE9fice",
    "benefice",
    "rentabilit\xE9",
    "rentabilite",
    "mon \xE9quipe",
    "mon equipe",
    "mes salari\xE9s",
    "mes salaries",
    "mes employ\xE9s",
    "mes employes",
    "mes prospects",
    "mes leads",
    "mon tunnel",
    "mon funnel",
    "mes campagnes",
    "ads",
    "publicit\xE9",
    "publicite",
    "acquisition",
    "mon panier moyen",
    "taux de conversion",
    "je vends",
    "je facture",
    "je prospecte",
    "je signe des clients",
    // ----- Anglais -----
    "my business",
    "my company",
    "my agency",
    "my startup",
    "my shop",
    "my store",
    "my clients",
    "my offer",
    "my product",
    "my service",
    "my revenue",
    "my sales",
    "my team",
    "my leads",
    "i sell",
    "i run",
    "i own",
    // ----- Argot jeune / biz & argent -----
    "mon biz",
    "le biz",
    "je fais du biz",
    "side hustle",
    "side business",
    "business en ligne",
    "je dropship",
    "je fais de la money",
    "des lov\xE9s",
    "thune",
    "thunes",
    "maille",
    "la maille",
    "oseille",
    "biff",
    "caillasse",
    "flouze",
    "p\xE9sos",
    "pesos",
    "money",
    "cash",
    "mes sous",
    "des sous",
    "je gratte",
    "je fais des ventes",
    "business model",
    // ----- English (has an activity / business) -----
    "my brand",
    "my ecom",
    "my e-com",
    "my ecom brand",
    "my online store",
    "my dropshipping",
    "my coaching",
    "my course",
    "my newsletter",
    "my channel",
    "my page",
    "my account",
    "content creator",
    "creator",
    "youtuber",
    "tiktoker",
    "streamer",
    "influencer",
    "freelancer",
    "agency owner",
    "smma owner",
    "ecom store",
    "online business",
    "my saas",
    "my app",
    "my startup",
    "i freelance",
    "i consult",
    "i coach",
    "self employed",
    "self-employed",
    "solopreneur",
    "entrepreneur",
    "my mrr",
    "my revenue",
    "my margins",
    "my funnel",
    "my offer",
    "my clients",
    "my customers",
    "i run ads",
    "my ad spend",
    "my pipeline",
    "my leads",
    "my conversions",
    // ----- Enrichissement : niches services/locales (alignées sur ACTIVITY_TYPES) -----
    "mon salon",
    "mon institut",
    "mon onglerie",
    "estheticienne",
    "prothesiste ongulaire",
    "coiffeur",
    "coiffeuse",
    "barbier",
    "tatoueur",
    "maquilleuse",
    "mon resto",
    "mon restaurant",
    "food truck",
    "traiteur",
    "patisserie",
    "boulangerie",
    "therapeute",
    "naturopathe",
    "osteopathe",
    "kine",
    "sophrologue",
    "praticien",
    "coach sportif",
    "prepa physique",
    "mon cabinet",
    "investissement locatif",
    "marchand de biens",
    "airbnb",
    // ----- EN -----
    "my salon",
    "my barbershop",
    "nail tech",
    "lash tech",
    "my restaurant",
    "food truck",
    "my practice",
    "my clinic",
    "naturopath",
    "therapist",
    "real estate investor",
    "my rentals",
    "my properties",
    // ----- Enrichissement v2 FR (audience / monétisation / rôles) -----
    "mon compte insta",
    "ma page insta",
    "ma communaute",
    "mon audience",
    "mes abonnes",
    "jmonetise",
    "jvends des prestas",
    "jfais du closing",
    "jfais du setting",
    "jsuis closer",
    "jsuis setter",
    "jfais de lugc",
    "mon shop etsy",
    "ma chaine youtube",
    "mon tiktok",
    "jfais de laffiliation",
    "jsuis dropshippeur",
    "mon compte pro",
    // ----- EN -----
    "my instagram account",
    "my following",
    "my audience",
    "my subscribers",
    "i monetize",
    "i sell services",
    "i do closing",
    "im a closer",
    "im a setter",
    "i do ugc",
    "my etsy shop",
    "my youtube channel",
    "my tiktok",
    "i do affiliate",
    "im a dropshipper",
    "my business account"
  ];
  var PAIN_KEYWORDS = [
    "manque",
    "il me manque",
    "difficile",
    "dur",
    "c'est dur",
    "gal\xE8re",
    "galere",
    "je gal\xE8re",
    "je galere",
    "bloqu\xE9",
    "bloque",
    "je bloque",
    "coinc\xE9",
    "coince",
    "probl\xE8me",
    "probleme",
    "soucis",
    "souci",
    "frustr\xE9",
    "frustre",
    "frustrant",
    "marre",
    "ras-le-bol",
    "stagne",
    "je stagne",
    "stagnation",
    "\xE7a stagne",
    "j'arrive pas",
    "jarrive pas",
    "j'y arrive pas",
    "n'y arrive pas",
    "compliqu\xE9",
    "complique",
    "je perds",
    "perte",
    "pas assez",
    "pas suffisant",
    "trop peu",
    "\xE9puis\xE9",
    "epuise",
    "\xE0 bout",
    "a bout",
    "fatigu\xE9",
    "fatigue",
    "crev\xE9",
    "creve",
    "burn",
    "burnout",
    "overwhelm",
    "d\xE9bord\xE9",
    "deborde",
    "plafonne",
    "je plafonne",
    "plafond",
    "n'avance pas",
    "navance pas",
    "\xE7a avance pas",
    "pas de r\xE9sultat",
    "pas de resultat",
    "pas de client",
    "peu de client",
    "pas de vente",
    "peu de vente",
    "pas de lead",
    "inconstant",
    "irr\xE9gulier",
    "irregulier",
    "instable",
    "pas rentable",
    "je perds de l'argent",
    "stuck",
    "struggle",
    "struggling",
    "hard",
    "frustrated",
    "not enough",
    "stagnant",
    "overwhelmed",
    "no clients",
    "no sales",
    "burned out",
    "plateau",
    "losing money",
    // ----- Argot jeune / galère -----
    "je rame",
    "\xE7a rame",
    "ca rame",
    "je rame grave",
    "c'est mort",
    "la hess",
    "c'est la hess",
    "la d\xE8che",
    "la deche",
    "je suis dead",
    "je suis cuit",
    "je suis grill\xE9",
    "je suis grille",
    "je suis ko",
    "je suis hs",
    "au fond du trou",
    "\xE0 la rue",
    "a la rue",
    "c'est chaud",
    "trop chaud",
    "c'est relou",
    "relou",
    "je suis blas\xE9",
    "blas\xE9",
    "blase",
    "\xE7a me so\xFBle",
    "ca me soule",
    "\xE7a me saoule",
    "je sature",
    "je suis d\xE9go\xFBt\xE9",
    "d\xE9gout\xE9",
    "degoute",
    "je tourne en rond",
    "je suis paum\xE9",
    "paum\xE9",
    "paume",
    "je suis largu\xE9",
    "largu\xE9",
    "\xE7a part en cacahu\xE8te",
    "je suis au taquet",
    "j'en peux plus",
    "jen peux plus",
    "\xE7a le fait pas",
    "wallah je gal\xE8re",
    // ----- English (pain / consequences) -----
    "i cant",
    "i can't",
    "cant seem to",
    "i'm stuck",
    "im stuck",
    "stuck at",
    "stuck on",
    "no progress",
    "not growing",
    "not working",
    "doesnt work",
    "isnt working",
    "not getting",
    "cant get clients",
    "no clients coming",
    "inconsistent",
    "unstable income",
    "unpredictable",
    "feast or famine",
    "cant scale",
    "plateaued",
    "hit a plateau",
    "hit a wall",
    "spinning my wheels",
    "wasting time",
    "wasting money",
    "losing money",
    "not profitable",
    "barely making",
    "struggling to",
    "i struggle with",
    "its frustrating",
    "so frustrating",
    "im exhausted",
    "burnt out",
    "burned out",
    "fed up",
    "sick of",
    "tired of",
    "overwhelmed",
    "falling behind",
    "going nowhere",
    "demotivated",
    "lost motivation",
    "i give up",
    // ----- §7.3 additions -----
    "ca fait des mois que",
    "ca fait des annees que",
    "ca me stresse",
    "me stresse",
    "stresse",
    "stressant",
    "je perds de largent",
    "je perds du temps sur",
    "losing money on",
    "wasting money on",
    "been struggling for months",
    "its stressing me out",
    "so stressful",
    "really stressful",
    // ----- Enrichissement FR (douleur / consequences) -----
    "jen ai marre de",
    "jen peux vraiment plus",
    "je sais plus quoi faire",
    "je suis perdu",
    "je tourne en boucle",
    "jai limpression de stagner",
    "rien ne bouge",
    "ca decolle pas",
    "jarrive pas a vendre",
    "jai pas de resultats",
    "je procrastine",
    "je manque de discipline",
    "je manque de methode",
    "je manque de clarte",
    "jai trop dinfos",
    "je sais pas par ou commencer",
    "jai peur de me planter",
    "jai deja perdu de largent",
    "je me disperse",
    "je suis seul la dessus",
    // ----- EN -----
    "im sick and tired of",
    "i dont know what to do",
    "im lost",
    "going in circles",
    "nothing moves",
    "cant get it off the ground",
    "i cant sell",
    "no results",
    "i procrastinate",
    "i lack discipline",
    "i lack a method",
    "i lack clarity",
    "information overload",
    "dont know where to start",
    "afraid to fail",
    "already lost money",
    "im spread too thin",
    "doing this alone",
    // ----- Enrichissement v2 (douleur / conséquences) -----
    "ca me prend la tete",
    "ca me bouffe",
    "jvois pas le bout",
    "jai tout essaye",
    "rien ne marche",
    "jme decourage",
    "jperds confiance",
    "jai plus de motivation",
    "ca fait trop longtemps",
    "jose pas me lancer",
    "syndrome de limposteur",
    "jai honte",
    "jen ai gros",
    "jdors mal a cause de",
    "jsuis sous leau",
    "jcravache pour rien",
    "jvends pas assez",
    "mes posts marchent pas",
    "jai aucune visibilite",
    "personne mecrit",
    // ----- EN -----
    "it keeps me up at night",
    "its eating at me",
    "i cant see the end",
    "ive tried everything",
    "nothing works",
    "im losing confidence",
    "i lost my motivation",
    "this has gone on too long",
    "i dont dare start",
    "imposter syndrome",
    "im ashamed",
    "im drowning",
    "i grind for nothing",
    "i dont sell enough",
    "my posts flop",
    "i have no visibility",
    "nobody messages me",
    "no one engages"
  ];
  var BUYING_SIGNAL_KEYWORDS = [
    // Prix / modalités
    "ca coute combien",
    "cest quel budget",
    "facilites de paiement",
    "par mois ou en une fois",
    "combien ca coute",
    "quel est le tarif",
    "quel est le prix",
    "ca fait combien",
    // EN
    "how much does it cost",
    "how much is it",
    "whats the price",
    "what does it cost",
    "is there a payment plan",
    "payment plan",
    "monthly or one time",
    "can i pay monthly",
    "how much",
    "what is the cost",
    "whats the investment",
    // Projection / possession
    "quand on pourrait commencer",
    "ca prend combien de temps",
    "on commencerait par quoi",
    "je ferais quoi en premier",
    "du coup je ferais",
    "on commencerait comment",
    // EN
    "when can we start",
    "when could we start",
    "how long does it take",
    "what would i do first",
    "where do we start",
    "how does it work",
    "whats included",
    "whats next",
    // Détails d'usage
    "cest inclus",
    "ca marche aussi pour",
    "et si je veux",
    "ca marche pour moi",
    // EN
    "is that included",
    "does it include",
    "does it work for",
    "would it work for my",
    "can i also",
    // Garanties
    "si ca marche pas",
    "il y a une garantie",
    "ya une garantie",
    "satisfait ou rembourse",
    // EN
    "what if it doesnt work",
    "is there a guarantee",
    "money back",
    "refund",
    "refund policy",
    // ----- Enrichissement : intention d'achat explicite -----
    "je prends",
    "je le prends",
    "je veux minscrire",
    "comment je minscris",
    "comment on fait",
    "comment ca se passe",
    "je suis chaud pour",
    "on signe",
    "envoie le lien",
    "envoie moi le lien",
    "tu prends les cb",
    "paypal",
    "virement",
    "jai ma carte",
    "comment je paye",
    "ou je paye",
    "on commence quand",
    "je peux commencer quand",
    "il reste des places",
    "cest quand le prochain",
    // EN
    "i'll take it",
    "ill take it",
    "im in",
    "sign me up",
    "how do i sign up",
    "how do i join",
    "how do i enroll",
    "send me the link",
    "where do i pay",
    "do you take card",
    "do you take paypal",
    "can i start today",
    "when can i start",
    "are there spots left",
    "whats the next step",
    // ----- Enrichissement v2 (prix / engagement / logistique) -----
    "cest combien le mois",
    "ya des facilites",
    "je peux payer en plusieurs fois",
    "cest sans engagement",
    "jpeux annuler quand",
    "cest accessible debutant",
    "il faut quel niveau",
    "ca marche depuis le tel",
    "combien de temps par jour",
    "jaurai un suivi",
    "on se voit en visio",
    "cest des lives ou des videos",
    "jai acces a vie",
    "cest quoi la prochaine etape",
    "tu me files le lien",
    "je reserve comment",
    // ----- EN -----
    "how much a month",
    "any installments",
    "can i pay in installments",
    "is it no commitment",
    "can i cancel anytime",
    "is it beginner friendly",
    "what level do i need",
    "does it work from my phone",
    "how much time per day",
    "do i get support",
    "are there live calls",
    "is it lifetime access",
    "how do i book",
    "just send me the link",
    "i want to reserve",
    "put me down"
  ];
  var AUTHORITY_POSITIVE_KEYWORDS = [
    "cest moi qui decide",
    "je peux signer",
    "je decide seul",
    "cest ma decision",
    "je suis le seul a decider",
    "je gere ca tout seul",
    "jai le feu vert",
    // EN
    "im the decision maker",
    "i decide",
    "i can sign",
    "its my call",
    "i can commit",
    "i make the decisions",
    "i have the final say",
    "i can decide on my own",
    // ----- Enrichissement -----
    "cest moi le patron",
    "jai pas a demander",
    "je gere mon argent",
    "cest mon budget",
    "je fais ce que je veux",
    "jai pas de comptes a rendre",
    "cest moi qui vois",
    "im my own boss",
    "i dont need to ask anyone",
    "its my money",
    "its all on me",
    "i call the shots",
    // ----- Enrichissement v2 -----
    "jai mon propre argent",
    "je travaille je peux investir",
    "cest mes economies",
    "jai un peu de cote",
    "jassume",
    "jprends mes decisions seul",
    "jai pas a en parler",
    "cest moi qui paie",
    // ----- EN -----
    "i have my own income",
    "i can invest",
    "these are my savings",
    "i have some saved up",
    "i own it",
    "i make my own choices",
    "i pay for it myself",
    "no one to answer to"
  ];
  var AUTHORITY_BLOCKED_KEYWORDS = [
    "il faut que je demande",
    "faut que je demande",
    "jen parle a",
    "jen parle avec",
    "mon associe",
    "ma femme",
    "mon mari",
    "mon boss",
    "mon manager",
    "mon comptable",
    "cest pas moi qui gere le budget",
    "pas moi qui decide",
    "je suis pas seul",
    "on decide a deux",
    "je dois en parler",
    "faut que jen parle",
    // EN
    "i need to ask",
    "i have to check with",
    "let me check with",
    "need to talk to",
    "ill run it by",
    "my partner",
    "not my decision",
    "not up to me",
    "we decide together",
    "i dont control the budget",
    "i have to talk to",
    // ----- Enrichissement FR -----
    "jen parle a ma copine",
    "jen parle a mon copain",
    "faut que je vois avec",
    "jdois demander a mes parents",
    "mes parents",
    "cest mes parents qui",
    "faut laccord de",
    "je suis mineur",
    "jsuis mineur",
    // ----- EN -----
    "i need to ask my parents",
    "im a minor",
    "check with my wife",
    "check with my husband",
    "check with my girlfriend",
    "check with my boyfriend",
    "ask my parents",
    "i need approval from",
    // ----- Enrichissement v2 FR -----
    "jdemande a mon assoc",
    "faut que jvoie avec ma meuf",
    "faut que jvoie avec mon mec",
    "cest mes parents qui paient",
    "jai pas acces au compte",
    "cest pas mon argent",
    "faut que jen parle a la maison",
    // ----- EN -----
    "i share finances",
    "my parents pay",
    "i dont have access to the account",
    "its not my money",
    "i have to run it by my family",
    "need to ask my co-founder",
    "i need to talk to my spouse"
  ];
  var EMOTIONAL_HOT_KEYWORDS = [
    "ca minteresse",
    "ca mint\xE9resse",
    "ah ouais carrement",
    "jaime bien",
    "exactement",
    "trop bien",
    "cest cool",
    "ca a lair bien",
    "je suis partant",
    "je suis chaud",
    "ca me parle",
    "cest exactement ce que",
    "je cherchais ca",
    "ca correspond",
    // EN
    "im interested",
    "that sounds great",
    "i love that",
    "i like that",
    "that resonates",
    "im in",
    "lets do it",
    "sounds good",
    "sounds amazing",
    "definitely",
    "absolutely",
    "for sure",
    "this is what i need",
    "where do i sign",
    "sign me up",
    "yes!",
    "100%",
    // ----- Enrichissement FR (chaud / motivé / argot jeune) -----
    "jadore",
    "grave interesse",
    "grave chaud",
    "trop chaud",
    "chaud bouillant",
    "je valide",
    "ca me hype",
    "ca me parle grave",
    "go",
    "go go",
    "banger",
    "cest exactement ca",
    "parfait pour moi",
    "jattendais que ca",
    "tu lis dans mes pensees",
    "cest fait pour moi",
    "je kiffe",
    "ca me motive a balle",
    "tu me motives",
    "jsuis chaud",
    "jsuis trop chaud",
    "partant a fond",
    "wesh carrement",
    // ----- EN -----
    "lets gooo",
    "lets goo",
    "im so in",
    "count me in",
    "this is exactly what i need",
    "i love this",
    "youre reading my mind",
    "this hypes me up",
    "so down",
    "im down",
    "hell yes",
    "heck yes",
    // ----- Enrichissement v2 FR -----
    "ca me donne envie",
    "jveux foncer",
    "jveux pas rater ca",
    "on fait comment du coup",
    "jai trop hate",
    "ca tombe bien",
    "cest ce quil me faut",
    "jsuis motive comme jamais",
    "enfin quelquun qui comprend",
    "jsigne ou",
    "jattends que ca",
    "la oui clairement",
    // ----- EN -----
    "this makes me want to",
    "i want to dive in",
    "i dont want to miss this",
    "so how do we do this",
    "i cant wait",
    "perfect timing",
    "this is what i needed",
    "never been this motivated",
    "finally someone who gets it",
    "where do i sign up",
    "this is a no brainer",
    "yeah for sure lets go"
  ];
  var EMOTIONAL_COLD_KEYWORDS = [
    "je sais pas trop",
    "bof",
    "moyen",
    "pas sur",
    "pas convaincu",
    "je vais voir",
    "peut etre",
    "cest possible",
    "on verra",
    "pas trop mon truc",
    // EN
    "i guess",
    "maybe",
    "not sure",
    "i dont know",
    "i dunno",
    "possibly",
    "well see",
    "im not sure",
    "sounds okay",
    "could be",
    "i need to think",
    "not convinced",
    // ----- Enrichissement FR -----
    "mouais bof",
    "jsais pas si",
    "pourquoi pas",
    "a voir",
    "faut voir",
    "ca depend",
    "jhesite",
    "jsuis mitige",
    "pas fou",
    "ca me tente moyen",
    "jsuis pas emballe",
    // ----- EN -----
    "meh",
    "idk",
    "we'll see",
    "depends",
    "on the fence",
    "kinda",
    "sorta",
    "not really feeling it",
    "im torn",
    "im hesitant",
    "not blown away",
    // ----- Enrichissement v2 FR -----
    "jverrai bien",
    "pas trop pour moi",
    "jsuis pas sur que ce soit pour moi",
    "ca minteresse moyen",
    "jsais pas trop quoi en penser",
    "bof bof",
    "jaccroche pas trop",
    "mouais pourquoi pas",
    // ----- EN -----
    "ill see how it goes",
    "not really for me",
    "not sure its for me",
    "kind of meh",
    "dont know what to think",
    "so so",
    "im lukewarm",
    "eh maybe"
  ];
  var EMOTIONAL_SKEPTICAL_KEYWORDS = [
    "mouais",
    "cest trop beau",
    "tout le monde dit ca",
    "jai deja vu ca",
    "encore un qui",
    "cest quoi larnaque",
    "cest du bullshit",
    "ca metonnerait",
    "jy crois pas trop",
    "cest une arnaque",
    "prove it",
    "prouve moi",
    // EN
    "sounds too good to be true",
    "ive heard that before",
    "everyone says that",
    "im skeptical",
    "i doubt it",
    "i dont believe",
    "how do i know",
    "ive been burned",
    "is this legit",
    "is this a scam",
    "red flag",
    "too good to be true",
    // ----- Enrichissement FR -----
    "cest des promesses",
    "facile a dire",
    "tout le monde promet ca",
    "jy crois pas",
    "cest commercial",
    "tu vends du reve",
    "cest du vent",
    "pyramide",
    "systeme pyramidal",
    "trop beau pour etre vrai",
    "cest pas net",
    "ya anguille sous roche",
    "jai un doute",
    // ----- EN -----
    "just promises",
    "easy to say",
    "everyone promises that",
    "youre selling a dream",
    "all talk",
    "sounds like hype",
    "pyramid scheme",
    "mlm vibes",
    "i call bs",
    // ----- Enrichissement v2 FR -----
    "cest trop facile",
    "si cetait vrai ca se saurait",
    "tout le monde dit pareil",
    "jveux des preuves dabord",
    "ya un loup",
    "cest louche",
    "jme fais pas avoir deux fois",
    "ca sent le commercial",
    // ----- EN -----
    "if it were true everyone would",
    "this is too easy",
    "i want proof first",
    "something is off",
    "this is fishy",
    "wont get fooled again",
    "sounds salesy",
    "whats the catch"
  ];
  var COOLING_KEYWORDS = [
    "faut que jy aille",
    "je dois y aller",
    "je dois partir",
    "jai pas le temps la",
    "envoie moi un mail",
    "envoie un mail",
    "tu peux menvoyer un mail",
    "je regarderai ca",
    "je verrai ca",
    "je te tiens au courant",
    // EN
    "i have to go",
    "i gotta go",
    "gotta run",
    "send me an email",
    "shoot me an email",
    "ill look at it",
    "ill check it out",
    "ill think about it",
    "let me think about it",
    "ill get back to you",
    "ill let you know",
    "talk later",
    "maybe another time",
    "not a good time",
    "im busy",
    "catch you later",
    // ----- Enrichissement FR (décrochage / esquive) -----
    "on en reparle",
    "je te recontacte",
    "la jai pas le temps",
    "jsuis au taf",
    "jsuis occupe",
    "plus tard ptet",
    "je sais pas encore",
    "jhesite encore",
    "laisse moi le temps",
    "jverrai plus tard",
    "jdois filer",
    "jdois y aller la",
    "a la base je regardais juste",
    "jfaisais que regarder",
    // ----- EN -----
    "ttyl",
    "talk soon",
    "ill circle back",
    "reach out later",
    "im at work",
    "kinda busy",
    "not sure yet",
    "still thinking",
    "gimme some time",
    "i gotta run",
    "just browsing",
    "just looking",
    // ----- Enrichissement v2 FR -----
    "jrepasserai",
    "jte ping plus tard",
    "la jpeux pas trop parler",
    "jsuis en deplacement",
    "jte redis",
    "pas le bon moment la",
    "jai un truc la",
    "jsuis pas chez moi",
    "jvois ca ce week end",
    "jte fais signe",
    // ----- EN -----
    "ill swing by later",
    "ill ping you later",
    "cant really talk now",
    "im traveling",
    "ill let you know later",
    "bad timing right now",
    "im in the middle of something",
    "im not home",
    "ill look this weekend",
    "ill hit you up"
  ];
  var PHASE_LABELS = {
    en: {
      connexion: "Connection",
      situation: "Situation",
      probleme: "Problem",
      transition: "Transition to the call"
    },
    fr: {
      connexion: "Connexion",
      situation: "Situation",
      probleme: "Probl\xE8me",
      transition: "Transition vers le call"
    }
  };
  var FR_MARKERS = /* @__PURE__ */ new Set([
    "je",
    "tu",
    "il",
    "elle",
    "nous",
    "vous",
    "le",
    "la",
    "les",
    "un",
    "une",
    "des",
    "du",
    "et",
    "est",
    "suis",
    "pas",
    "mais",
    "pour",
    "avec",
    "dans",
    "mon",
    "ma",
    "mes",
    "ton",
    "ta",
    "ca",
    "cest",
    "qui",
    "que",
    "quoi",
    "plus",
    "fait",
    "veux",
    "jai",
    "tres",
    "toi",
    "moi",
    "bonjour",
    "salut",
    "merci",
    "vraiment",
    "beaucoup",
    "aussi",
    "parce",
    "comme",
    "aux",
    "cette",
    "sont",
    "ete",
    "alors",
    "donc",
    "bien",
    "ne",
    "ses",
    "leur",
    "notre",
    "votre",
    "ils",
    "elles",
    "sur",
    "au",
    "ce",
    // ----- Enrichissement : marqueurs FR discriminants (argot inclus) -----
    "jsuis",
    "jveux",
    "jvais",
    "jfais",
    "jpeux",
    "jpense",
    "jcrois",
    "jdois",
    "tas",
    "ya",
    "wesh",
    "ouais",
    "genre",
    "grave",
    "trop",
    "vraiment",
    "enfin",
    "franchement",
    "perso",
    "quand",
    "parce",
    "pourquoi",
    "comment",
    "combien",
    "chez",
    "depuis",
    "pendant",
    "tellement",
    "carrement",
    "faut",
    "ptet",
    "jte"
  ]);
  var EN_MARKERS = /* @__PURE__ */ new Set([
    "the",
    "i",
    "you",
    "to",
    "and",
    "is",
    "are",
    "an",
    "of",
    "for",
    "with",
    "my",
    "your",
    "it",
    "that",
    "this",
    "im",
    "dont",
    "want",
    "need",
    "hey",
    "thanks",
    "really",
    "just",
    "do",
    "does",
    "have",
    "has",
    "was",
    "were",
    "what",
    "how",
    "why",
    "when",
    "about",
    "can",
    "we",
    "they",
    "he",
    "she",
    "so",
    "but",
    "because",
    "like",
    "yes",
    // ----- Enrichissement : marqueurs EN discriminants (argot inclus) -----
    "gonna",
    "wanna",
    "gotta",
    "aint",
    "yeah",
    "actually",
    "literally",
    "honestly",
    "kinda",
    "sorta",
    "though",
    "would",
    "could",
    "should",
    "from",
    "into",
    "than",
    "then",
    "also",
    "still",
    "even",
    "much",
    "many",
    "where",
    "which",
    "here",
    "there",
    "around",
    "pretty",
    "gonna",
    "lemme"
  ]);
  var FR_ACCENTS_RE = /[àâäçéèêëîïôöùûüÿœæ]/i;
  var NEGATORS = /* @__PURE__ */ new Set([
    "ne",
    "n",
    "pas",
    "jamais",
    "aucun",
    "aucune",
    "sans",
    "rien",
    "ni",
    "nul",
    "nulle",
    "point",
    "no",
    "not",
    "never",
    "without",
    "dont",
    "doesnt",
    "don",
    "doesn"
  ]);
  var CLAUSE_BREAKERS = /* @__PURE__ */ new Set([
    "mais",
    "pourtant",
    "cependant",
    "toutefois",
    "neanmoins",
    "contre",
    "sauf",
    "malgre",
    "donc",
    "car",
    "et",
    "ou",
    "puis",
    "alors",
    "ensuite",
    "or",
    "parce",
    "but",
    "however",
    "though",
    "although",
    "yet",
    "so",
    "because"
  ]);
  var SettingCoach = class {
    /**
     * Déduit la phase de setting et la prochaine action depuis la conversation.
     * `dyn` (dynamique comportementale) est optionnel : fourni, il rend le coach
     * momentum-aware (prédiction de closing, priorité, urgence calibrée).
     */
    analyze(messages, dyn) {
      const theirText = messages.filter((m) => !m.isSent).map((m) => m.text || "").join(" \n ");
      const normText = this.normalize(theirText);
      const tokens = normText ? normText.split(" ") : [];
      const lang = this.detectLang(tokens, theirText);
      const hasObjective = this.hasAny(tokens, normText, OBJECTIVE_KEYWORDS);
      const hasSituation = this.hasAny(tokens, normText, SITUATION_KEYWORDS);
      const hasPain = this.hasAny(tokens, normText, PAIN_KEYWORDS);
      const hasBusiness = this.hasAny(tokens, normText, BUSINESS_KEYWORDS);
      const buyingSignal = this.hasAny(tokens, normText, BUYING_SIGNAL_KEYWORDS);
      const hasEmotionalHot = this.hasAny(tokens, normText, EMOTIONAL_HOT_KEYWORDS);
      const hasEmotionalCold = this.hasAny(tokens, normText, EMOTIONAL_COLD_KEYWORDS);
      const hasEmotionalSkeptical = this.hasAny(tokens, normText, EMOTIONAL_SKEPTICAL_KEYWORDS);
      const authorityConfirmed = this.hasAny(tokens, normText, AUTHORITY_POSITIVE_KEYWORDS);
      const authorityBlocked = this.hasAny(tokens, normText, AUTHORITY_BLOCKED_KEYWORDS);
      const hasCooling = this.hasAny(tokens, normText, COOLING_KEYWORDS);
      let emotionalState = "neutral";
      if (hasEmotionalSkeptical) emotionalState = "skeptical";
      else if (hasEmotionalHot) emotionalState = "hot";
      else if (hasEmotionalCold) emotionalState = "cold";
      let phase;
      if (hasPain && hasSituation) phase = "transition";
      else if (hasSituation) phase = "probleme";
      else if (hasObjective) phase = "situation";
      else phase = "connexion";
      const revealed = { objective: hasObjective, situation: hasSituation, pain: hasPain };
      const facts = this.extractFacts(theirText, normText, lang);
      const nextStep = this.nextStep(phase, hasBusiness, lang, facts);
      const missing = this.computeMissing(revealed, facts, lang);
      const objKws = (label) => OBJECTION_GROUPS.find((g) => g.label === label)?.kws ?? [];
      const hasBudgetObjection = this.hasAny(tokens, normText, objKws("Limited budget"));
      const hasStalling = this.hasAny(tokens, normText, [...objKws("Stalling"), ...objKws("Procrastination")]);
      const hasTrustIssue = this.hasAny(tokens, normText, objKws("Trust / proof needed"));
      const qualificationScore = this.qualificationScore(revealed, facts, {
        buyingSignal,
        emotionalState,
        authorityConfirmed,
        authorityBlocked,
        hasCooling
      });
      const recommendedOffer = this.recommendedOffer(phase, revealed, hasBusiness, hasBudgetObjection, lang);
      const momentum = this.momentumOf(dyn);
      const closeProbability = this.closeProbability(qualificationScore, momentum, emotionalState, buyingSignal, dyn);
      const priority = this.priorityOf({
        phase,
        revealed,
        momentum,
        closeProbability,
        buyingSignal
      });
      const closingTactic = this.closingTactic(
        { buyingSignal, emotionalState, hasCooling, hasStalling, hasBudgetObjection, hasTrustIssue, momentum, priority },
        lang
      );
      return {
        phase,
        phaseLabel: PHASE_LABELS[lang][phase],
        lang,
        hasBusiness,
        nextStep,
        summary: {
          nextStep,
          revealed,
          missing,
          facts,
          qualificationScore,
          recommendedOffer,
          closingTactic,
          closeProbability,
          momentum,
          priority
        },
        buyingSignal,
        emotionalState,
        authorityConfirmed,
        authorityBlocked,
        hasCooling
      };
    }
    // ==================== Extraction de faits clés ====================
    /**
     * Extrait des faits exploitables des messages du prospect : budget, horizon,
     * objectif chiffré, type d'activité, objections. Best-effort (heuristique FR).
     * `rawText` garde la casse/les chiffres d'origine ; `normText` est normalisé.
     */
    extractFacts(rawText, normText, lang) {
      const facts = {
        budget: null,
        timeline: null,
        goal: null,
        activity: null,
        objections: []
      };
      const lower = (rawText || "").toLowerCase();
      const moneyRe = /(?:[$€]\s*\d[\d  .,]*(?:\s*k)?|\d[\d  .,]*\s*(?:k€|k\$|k\b|€|\$|euros?|euro|balles?|dollars?|usd|bucks?))(?:\s*\/?\s*(?:mois|an|année|annee|semaine|sem|month|year|week|mo|yr|wk))?/gi;
      let m;
      while ((m = moneyRe.exec(lower)) !== null) {
        const amount = m[0].replace(/\s+/g, " ").trim();
        const ctx = lower.slice(Math.max(0, m.index - 45), m.index);
        const after = lower.slice(m.index + m[0].length, m.index + m[0].length + 25);
        const around = ctx + " " + after;
        const isGoal = /mrr|objectif|atteindre|vise|viser|gagner|générer|generer|au minimum|par mois|\/mois|\/an|goal|target|reach|aim|make|generate|per month|\/month|\/mo/.test(around);
        const isBudget = /reste|côté|cote|budget|investir|dispo|j'?ai|compte|économ|econom|mettre|peux|environ|prix|coûte|coute|left|budget|invest|afford|save|spend|price|cost|around|about/.test(ctx);
        if (isGoal && !facts.goal) facts.goal = amount;
        else if (isBudget && !facts.budget) facts.budget = amount;
      }
      const timeRe = /(?:d'?ici\s+|in\s+|within\s+)?\d+\s*(?:[-àa]\s*\d+)?\s*(?:mois|semaines?|jours?|ans?|années?|annees?|months?|weeks?|days?|years?)/i;
      const tm = lower.match(timeRe);
      if (tm) facts.timeline = tm[0].replace(/\s+/g, " ").trim();
      else if (/deadline|quelques mois|prochainement|bient[oô]t|cette ann[eé]e|in a few months|soon|this year|asap/.test(lower)) facts.timeline = lang === "fr" ? "\xE0 confirmer" : "to be confirmed";
      for (const t of ACTIVITY_TYPES) {
        if (t.kws.some((kw) => normText.includes(kw))) {
          facts.activity = lang === "fr" ? t.labelFr : t.label;
          break;
        }
      }
      for (const g of OBJECTION_GROUPS) {
        if (g.kws.some((kw) => normText.includes(this.normalize(kw)))) {
          facts.objections.push(lang === "fr" ? g.labelFr : g.label);
        }
      }
      return facts;
    }
    /** Axes encore à qualifier (révélés manquants + faits non collectés). */
    computeMissing(revealed, facts, lang) {
      const missing = [];
      if (lang === "fr") {
        if (!revealed.objective) missing.push("Son objectif / ce qu'il cherche");
        if (!revealed.situation) missing.push("Son activit\xE9 / sa situation actuelle");
        if (!revealed.pain) missing.push("Sa douleur / les cons\xE9quences");
        if (!facts.budget) missing.push("Son budget disponible");
        if (!facts.timeline) missing.push("Son timing / sa deadline");
      } else {
        if (!revealed.objective) missing.push("Their goal / what they're looking for");
        if (!revealed.situation) missing.push("Their activity / current situation");
        if (!revealed.pain) missing.push("Their pain / the consequences");
        if (!facts.budget) missing.push("Their available budget");
        if (!facts.timeline) missing.push("Their timing / deadline");
      }
      return missing;
    }
    // ==================== Closing (méthodo de setting) ====================
    /**
     * Readiness au closing (0-100). Suit la logique de la formation : on close
     * d'autant plus facilement que le prospect a révélé sa situation actuelle, sa
     * situation désirée (objectif) et ses blocages, qu'on connaît son budget et
     * qu'il envoie des signaux d'achat / un état émotionnel chaud.
     */
    qualificationScore(revealed, facts, signals) {
      let score = 0;
      if (revealed.situation) score += 20;
      if (revealed.objective) score += 20;
      if (revealed.pain) score += 25;
      if (facts.budget) score += 10;
      if (signals.buyingSignal) score += 15;
      if (signals.emotionalState === "hot") score += 10;
      else if (signals.emotionalState === "cold") score -= 5;
      else if (signals.emotionalState === "skeptical") score -= 10;
      if (signals.hasCooling) score -= 10;
      if (signals.authorityConfirmed) score += 5;
      else if (signals.authorityBlocked) score -= 10;
      return Math.max(0, Math.min(100, score));
    }
    /**
     * Élan de la conversation, fusionné depuis la dynamique comportementale
     * (cadence, vitesse de réponse, récence, balle dans son camp). Sans dynamique
     * disponible → 'steady' (neutre).
     */
    momentumOf(dyn) {
      if (!dyn) return "steady";
      if (dyn.temperature === "cold" || dyn.seenNotAnswered || dyn.lastMessageIsSent && (dyn.lastMessageAgeMs ?? 0) > 2 * COACH_DAY || dyn.cadenceTrend === "down") {
        return "cooling";
      }
      if (dyn.cadenceTrend === "up" || dyn.theirAvgResponseMs != null && dyn.theirAvgResponseMs < COACH_HOUR && dyn.theirResponseRate >= 0.7 || dyn.temperature === "hot") {
        return "accelerating";
      }
      return "steady";
    }
    /**
     * Prédiction : probabilité de closer maintenant (0-100). Part de la readiness
     * de qualification, ajustée par le momentum, l'état émotionnel, les signaux
     * d'achat et la réactivité comportementale. Déterministe, sans IA externe.
     */
    closeProbability(qualificationScore, momentum, emotionalState, buyingSignal, dyn) {
      let p = qualificationScore * 0.6;
      if (momentum === "accelerating") p += 15;
      else if (momentum === "cooling") p -= 20;
      if (emotionalState === "hot") p += 8;
      else if (emotionalState === "skeptical") p -= 12;
      else if (emotionalState === "cold") p -= 6;
      if (buyingSignal) p += 10;
      if (dyn) p += (dyn.theirResponseRate - 0.5) * 12;
      return Math.max(0, Math.min(100, Math.round(p)));
    }
    /**
     * Mode d'action prioritaire (machine à états du setting) :
     *  - reengage : ça refroidit → relancer la dynamique avant tout ;
     *  - close    : qualifié + chaud / forte proba → pousser le call / l'offre ;
     *  - qualify  : il reste situation ou blocages à creuser ;
     *  - nurture  : tôt / signaux faibles → entretenir sans forcer.
     */
    priorityOf(ctx) {
      if (ctx.momentum === "cooling") return "reengage";
      const qualified = ctx.phase === "transition" || ctx.revealed.situation && ctx.revealed.pain;
      if (qualified && (ctx.closeProbability >= 60 || ctx.buyingSignal)) return "close";
      if (!ctx.revealed.situation || !ctx.revealed.pain) return "qualify";
      return "nurture";
    }
    /**
     * Offre à pousser une fois la qualification suffisante. Reprend l'arbitrage de
     * la formation : petit budget / débutant sans activité → formation low-ticket ;
     * déjà une activité à scaler → call coaching. Null tant qu'on n'a pas creusé
     * situation + blocages (trop tôt pour proposer).
     */
    recommendedOffer(phase, revealed, hasBusiness, hasBudgetObjection, lang) {
      const qualified = phase === "transition" || revealed.situation && revealed.pain;
      if (!qualified) return null;
      const lowTicket = !hasBusiness || hasBudgetObjection;
      if (lang === "fr") {
        return lowTicket ? "Oriente vers la formation low-ticket (d\xE9butant / budget serr\xE9) plut\xF4t que le call." : "Propose un call pour le coaching (il a d\xE9j\xE0 une activit\xE9 \xE0 scaler).";
      }
      return lowTicket ? "Point them to the low-ticket course (beginner / tight budget) rather than the call." : "Offer a call for the coaching (they already have a business to scale).";
    }
    /**
     * Tactique de closing prioritaire. Reprend deux réflexes clés de la formation :
     * (1) un prospect chaud qui temporise (« plus tard », « pas le budget », « ma
     * carte marche pas ») fait souvent des excuses → créer de l'urgence ; (2) un
     * prospect sceptique a besoin d'une preuve avant de pousser vers le call.
     */
    closingTactic(signals, lang) {
      const interested = signals.buyingSignal || signals.emotionalState === "hot";
      const stalling = signals.hasCooling || signals.hasStalling || signals.hasBudgetObjection;
      if (signals.emotionalState === "skeptical" || signals.hasTrustIssue) {
        return lang === "fr" ? "Il doute : rassure avec une preuve concr\xE8te (r\xE9sultat, t\xE9moignage, garantie) avant de pousser vers le call." : "He's skeptical: reassure with concrete proof (a result, a testimonial, a guarantee) before pushing for the call.";
      }
      if (interested && stalling) {
        return lang === "fr" ? "Il est int\xE9ress\xE9 mais temporise (\xAB plus tard \xBB, \xAB pas le budget \xBB = souvent des excuses, ne les prends pas au pied de la lettre). Cr\xE9e de l'urgence : place / tarif limit\xE9 dans le temps, et propose de verrouiller maintenant." : `He's interested but stalling ("later", "no budget" are usually excuses \u2014 don't take them at face value). Create urgency: limited spots / price going up soon, and offer to lock it in now.`;
      }
      if (signals.priority === "close" && signals.momentum === "accelerating") {
        return lang === "fr" ? "Momentum au max : c'est LE moment. Propose le call / l'offre tout de suite, pendant qu'il est chaud \u2014 n'attends pas demain." : "Momentum is peaking: this is THE moment. Pitch the call / offer right now while he's hot \u2014 don't wait until tomorrow.";
      }
      if (signals.priority === "reengage" || signals.momentum === "cooling") {
        return lang === "fr" ? "\xC7a refroidit : r\xE9engage AVANT de vendre \u2014 un message court et personnel (r\xE9agis \xE0 une story, pose une question ouverte sur son objectif) pour relancer la dynamique." : "It's cooling: re-engage BEFORE selling \u2014 a short, personal message (react to a story, ask an open question about their goal) to revive the momentum.";
      }
      return null;
    }
    /**
     * Prochaine question/action conseillée, tirée du framework de setting. Le
     * message entre guillemets est destiné à être envoyé au prospect : on le rend
     * donc dans SA langue (`lang`).
     */
    nextStep(phase, hasBusiness, lang, facts) {
      const goal = facts?.goal || null;
      if (lang === "fr") {
        switch (phase) {
          case "connexion":
            return "Connexion \u2014 cerne son objectif : \xAB Qu'est-ce qui t'am\xE8ne \xE0 chercher ce genre d'aide ? Tu sais d\xE9j\xE0 quel type d'accompagnement tu cherches ? \xBB";
          case "situation":
            return hasBusiness ? "Situation \u2014 comprends son activit\xE9 : \xAB Tu fais quoi exactement ? Depuis combien de temps ? Et t'as fait combien le mois dernier ? \xBB" : "Situation \u2014 comprends son contexte : \xAB Tu fais quoi en ce moment ? Depuis combien de temps ? Qu'est-ce qui t'a pouss\xE9 \xE0 choisir \xE7a au d\xE9part ? \xBB";
          case "probleme":
            return hasBusiness ? "Probl\xE8me \u2014 creuse la douleur : \xAB Qu'est-ce qui te manque pour avoir fait plus que \xE7a le mois dernier ? \xC7a impacte quoi sur ton business / ton quotidien ? \xBB" : "Probl\xE8me \u2014 creuse la douleur : \xAB Qu'est-ce qui fait que ta situation actuelle ne te suffit pas ? \xC7a dure depuis combien de temps, et \xE7a a quel impact sur toi ? \xBB";
          case "transition": {
            const intro = goal ? `Avec ton objectif (${goal}) et tout ce que tu m'as dit` : `Avec tout ce que tu m'as dit`;
            return `Transition \u2014 propose le call : \xAB ${intro}, \xE7a ressemble \xE0 quelque chose sur lequel je peux t'aider. La prochaine \xE9tape serait de planifier un call pour confirmer comment. \xC7a t'aiderait ? \xBB`;
          }
        }
      }
      switch (phase) {
        case "connexion":
          return `Connection \u2014 pin down their goal: "What brought you to look for this kind of help? Do you already know what type of help you're after?"`;
        case "situation":
          return hasBusiness ? 'Situation \u2014 understand their business: "What exactly do you do? How long have you been at it? And how much did you make last month?"' : 'Situation \u2014 understand their context: "What are you up to right now? For how long? What made you choose that in the first place?"';
        case "probleme":
          return hasBusiness ? `Problem \u2014 dig into the pain: "What's missing for you to have made only that last month? How does it affect your business / your day-to-day revenue?"` : `Problem \u2014 dig into the pain: "What makes you feel your current situation isn't enough? How long has it been going on, and what impact does it have on you?"`;
        case "transition": {
          const intro = goal ? `With your goal (${goal}) and everything you've told me` : `From everything you've told me`;
          return `Transition \u2014 offer the call: "${intro}, this sounds like something I can help you with. The next step would be to schedule a call to confirm how. Would that help?"`;
        }
      }
    }
    // ==================== Détection de langue ====================
    /**
     * Détermine si le prospect écrit en français ou en anglais à partir de ses
     * messages. On compte les marqueurs « fonction » de chaque langue (+ bonus
     * accents pour le FR). Égalité ou texte vide → FR (audience francophone).
     */
    detectLang(tokens, rawText) {
      let fr = 0;
      let en = 0;
      for (const t of tokens) {
        if (FR_MARKERS.has(t)) fr++;
        if (EN_MARKERS.has(t)) en++;
      }
      if (FR_ACCENTS_RE.test(rawText)) fr += 2;
      if (fr === 0 && en === 0) return "fr";
      return en > fr ? "en" : "fr";
    }
    // ==================== Matching à proximité (tolérant aux fautes) ====================
    /**
     * Vrai si un des mots-clés est présent dans le texte, avec tolérance aux
     * fautes : on tente d'abord une sous-chaîne exacte (rapide), puis un matching
     * mot à mot par distance d'édition (Levenshtein) sur des fenêtres de tokens.
     */
    hasAny(tokens, _normalizedText, keywords) {
      if (tokens.length === 0) return false;
      for (const kw of keywords) {
        const nkw = this.normalize(kw);
        if (!nkw) continue;
        const kwWords = nkw.split(" ");
        let from = 0;
        let idx;
        while ((idx = this.findMatchIndex(tokens, kwWords, from)) !== -1) {
          if (!this.isNegated(tokens, idx, idx + kwWords.length)) return true;
          from = idx + 1;
        }
      }
      return false;
    }
    /**
     * Index de la 1ʳᵉ occurrence (≥ `from`) de la séquence de mots-clés dans les
     * tokens (chaque mot toléré flou), ou -1.
     */
    findMatchIndex(tokens, kwWords, from) {
      const w = kwWords.length;
      for (let i = Math.max(0, from); i + w <= tokens.length; i++) {
        let ok = true;
        for (let k = 0; k < w; k++) {
          if (!this.wordMatches(tokens[i + k], kwWords[k])) {
            ok = false;
            break;
          }
        }
        if (ok) return i;
      }
      return -1;
    }
    /**
     * Vrai si la séquence [start, end) est sous l'effet d'une négation, en restant
     * dans la même proposition (la portée s'arrête à une conjonction d'opposition).
     * On regarde en amont (négateurs « ne/aucun/sans… ») et en aval (le « pas »
     * post-verbal du français : « je galère PAS »), sans compter les négateurs déjà
     * inclus dans le mot-clé lui-même.
     */
    isNegated(tokens, start, end) {
      for (let k = start - 1; k >= 0 && k >= start - 3; k--) {
        if (CLAUSE_BREAKERS.has(tokens[k])) break;
        if (NEGATORS.has(tokens[k])) return true;
      }
      for (let k = end; k < tokens.length && k <= end + 1; k++) {
        if (CLAUSE_BREAKERS.has(tokens[k])) break;
        if (NEGATORS.has(tokens[k])) return true;
      }
      return false;
    }
    /** Deux mots correspondent si identiques ou à ≤ seuil(longueur) éditions près. */
    wordMatches(token, kw) {
      if (token === kw) return true;
      const t = this.editThreshold(kw.length);
      if (t === 0) return false;
      if (Math.abs(token.length - kw.length) > t) return false;
      return this.levenshtein(token, kw) <= t;
    }
    /**
     * Nombre d'éditions tolérées selon la longueur du mot-clé. Plafonné à 1 :
     * tolérer 2 éditions sur les mots longs créait des FAUX POSITIFS coûteux
     * (« commencer » matchait « commerce » → activité détectée à tort). On préfère
     * la PRÉCISION (rater une double-faute, rare) à un mauvais conseil.
     */
    editThreshold(len) {
      if (len <= 4) return 0;
      return 1;
    }
    /**
     * Normalise une chaîne : minuscules, suppression des accents, COLLAGE des
     * apostrophes (« c'est » → « cest », pour matcher aussi les formes jeunes sans
     * apostrophe « cest », « jai »…), réduction des lettres triplées (« galèèère »
     * → « galere »), ponctuation → espaces, espaces compactés.
     */
    normalize(s) {
      return (s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/['’`]/g, "").replace(/(.)\1{2,}/g, "$1").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
    }
    /** Distance d'édition de Levenshtein (court-circuit si écart de taille > 2). */
    levenshtein(a, b) {
      const m = a.length;
      const n = b.length;
      if (Math.abs(m - n) > 2) return 3;
      const dp = Array.from({ length: n + 1 }, (_, j) => j);
      for (let i = 1; i <= m; i++) {
        let prev = dp[0];
        dp[0] = i;
        for (let j = 1; j <= n; j++) {
          const tmp = dp[j];
          dp[j] = Math.min(
            dp[j] + 1,
            // suppression
            dp[j - 1] + 1,
            // insertion
            prev + (a[i - 1] === b[j - 1] ? 0 : 1)
            // substitution
          );
          prev = tmp;
        }
      }
      return dp[n];
    }
  };

  // src/content/pro-conversation-collector.ts
  var STATE_KEY = "proAnalysisState";
  var ProConversationCollector = class {
    constructor(overlay) {
      this.running = false;
      this.scoring = new ScoringEngine();
      this.analyzer = new DMAnalyzer();
      this.dynamics = new ConversationDynamicsAnalyzer();
      this.settingCoach = new SettingCoach();
      // ==================== Phase 6 — détection live ====================
      this.liveWatchStarted = false;
      this.livePeople = /* @__PURE__ */ new Set();
      this.liveLastAnalyzed = /* @__PURE__ */ new Map();
      /** Signature du dernier état analysé par thread (détection de nouveau message). */
      this.liveLastSignature = /* @__PURE__ */ new Map();
      /** Rafraîchissement périodique de secours, même sans nouveau message. */
      this.LIVE_THROTTLE_MS = 30 * 1e3;
      // 30 s
      /** Garde-fou anti-rafale : délai mini entre 2 analyses d'un même thread. */
      this.LIVE_MIN_GAP_MS = 8 * 1e3;
      this.overlay = overlay;
    }
    // ==================== Cycle de vie / état ====================
    async getState() {
      const stored = await chrome.storage.local.get(STATE_KEY);
      return stored[STATE_KEY] || null;
    }
    async setState(patch) {
      const current = await this.getState() || {};
      const next = { ...current, ...patch };
      await chrome.storage.local.set({ [STATE_KEY]: next });
      return next;
    }
    async clearState() {
      await chrome.storage.local.remove(STATE_KEY);
    }
    /**
     * Démarre l'analyse (appelé depuis le popup via le content script).
     * Sauvegarde l'état puis navigue vers l'inbox (reload du content script).
     */
    async start(targetUsername, targetFullName = "") {
      console.log(`\u2728 [Pro] D\xE9marrage analyse conversation @${targetUsername} (${targetFullName || "sans nom"})`);
      await this.setState({
        phase: "search",
        targetUsername,
        targetFullName,
        startedAt: Date.now(),
        unreadDetected: false,
        unreadReceivedAt: null
      });
      if (this.isOnThread()) {
        console.log(
          `\u{1F50E} [Pro] Sur un thread \u2014 contact d\xE9tect\xE9: @${this.getThreadContactUsername() || "?"} (cible: @${targetUsername}, match: ${this.threadMatchesTarget(targetUsername)})`
        );
      }
      if (this.isOnThread() && this.threadMatchesTarget(targetUsername)) {
        console.log(`\u2728 [Pro] D\xE9j\xE0 dans la conversation de @${targetUsername} \u2014 analyse directe du thread ouvert.`);
        if (this.running) return;
        this.running = true;
        try {
          await this.scrollExtractAndAnalyze(targetUsername);
        } catch (error) {
          console.error("\u274C [Pro] Erreur durant l'analyse directe:", error);
          this.overlay.showError("Error while analyzing the conversation");
          await this.clearState();
        } finally {
          this.running = false;
        }
        return;
      }
      this.overlay.show("Opening messages\u2026");
      if (this.isOnInbox()) {
        await this.resume();
      } else {
        window.location.href = "https://www.instagram.com/direct/inbox/";
      }
    }
    /** Vrai si le thread actuellement ouvert est bien celui du contact ciblé. */
    threadMatchesTarget(username) {
      const target = username.toLowerCase();
      const current = this.getThreadContactUsername();
      if (current && current.toLowerCase() === target) return true;
      const link = Array.from(document.querySelectorAll('a[href^="/"]')).find((a) => {
        const m = (a.getAttribute("href") || "").match(/^\/([a-zA-Z0-9._]{1,40})\/?$/);
        if (!m || m[1].toLowerCase() !== target) return false;
        if (a.closest('a[href^="/direct/t/"]')) return false;
        const r = a.getBoundingClientRect();
        return r.width > 0 && r.top < 220;
      });
      return !!link;
    }
    /**
     * Reprend l'analyse au (re)chargement du content script selon la phase.
     */
    async resume() {
      const state = await this.getState();
      if (!state) return;
      if (this.running) return;
      this.running = true;
      try {
        console.log(`\u2728 [Pro] Reprise phase="${state.phase}" pour @${state.targetUsername}`);
        switch (state.phase) {
          case "goto_inbox":
          case "search":
            await this.runFromInbox(state);
            break;
          case "await_permission":
          case "scroll":
          case "analyze":
            await this.runFromInbox(state);
            break;
          case "done":
            await this.clearState();
            break;
        }
      } catch (error) {
        console.error("\u274C [Pro] Erreur durant l'analyse:", error);
        this.overlay.showError("Error while analyzing the conversation");
        await this.clearState();
      } finally {
        this.running = false;
      }
    }
    // ==================== Flux principal (sur /direct, SPA) ====================
    async runFromInbox(state) {
      if (!this.isOnInbox() && !this.isOnThread()) {
        this.overlay.show("Opening messages\u2026");
        window.location.href = "https://www.instagram.com/direct/inbox/";
        return;
      }
      const username = state.targetUsername;
      let fullName = state.targetFullName || "";
      if (!fullName) {
        fullName = await this.resolveProfileName(username);
        if (fullName) {
          console.log(`\u{1F464} [Pro] Nom de profil r\xE9solu pour @${username} : \xAB ${fullName} \xBB`);
          chrome.runtime.sendMessage({ type: "UPDATE_CONTACT_NAME", username, fullName }).catch(() => {
          });
        } else {
          console.log(`\u{1F464} [Pro] Pas de nom de profil pour @${username} (match par id)`);
        }
      }
      this.overlay.show(`Searching for @${username} in your history\u2026`);
      const row = await this.scrollAndLocateRow(username, fullName);
      if (!row) {
        this.overlay.showError(`Conversation with @${username} not found`);
        await this.clearState();
        return;
      }
      const allowed = await this.checkUnreadAndAskPermission(row, username);
      if (!allowed) {
        await this.clearState();
        return;
      }
      this.overlay.show(`Opening the conversation with @${username}\u2026`);
      await this.openThread(row);
      await this.scrollExtractAndAnalyze(username);
    }
    /**
     * Scrolle le thread OUVERT, extrait tout l'historique, lance l'analyse et
     * persiste les stats. Partagé par le flux inbox et le fast path « déjà dans la
     * conversation ». Suppose qu'on est déjà sur le thread du contact.
     */
    async scrollExtractAndAnalyze(username) {
      await this.setState({ phase: "scroll" });
      this.overlay.show("Reading the conversation\u2026");
      const scroller = new DMThreadScroller({
        onProgress: (n) => this.overlay.updateProgress(n, n + 1, `Lecture de la conversation\u2026 (${n} messages)`)
      });
      const messages = await scroller.scrollAndExtractAll();
      if (messages.length === 0) {
        this.overlay.showError("No readable messages in this conversation");
        await this.clearState();
        return;
      }
      await this.setState({ phase: "analyze" });
      this.overlay.show("Analyzing the conversation\u2026");
      await this.analyzeAndUpdate(username, messages, scroller.lastSeenDetected);
      await this.setState({ phase: "done" });
      this.overlay.showSuccess(`Analysis complete! (${messages.length} messages)`);
      await this.clearState();
    }
    /**
     * Phase 5 : sauvegarde la conversation (sync-dms), récupère le score DM
     * quantitatif serveur (analyze-dms), combine avec l'analyse heuristique
     * mots-clés/ton (extension), calcule le score global et le persiste
     * (analyze-contact → contact_scores + circle_members.relationship_score).
     */
    async analyzeAndUpdate(username, messages, seenReceipt = false) {
      this.overlay.show("Updating stats\u2026");
      await this.persistAnalysis(username, messages, seenReceipt);
    }
    /**
     * Coeur d'analyse + persistance (sans overlay) — réutilisé par le flux manuel
     * et par l'analyse live (Phase 6).
     */
    async persistAnalysis(username, messages, seenReceipt = false) {
      const convMessages = messages.map((m) => ({
        text: m.text,
        isSent: m.isSent,
        timestamp: m.timestamp
      }));
      const conversation = { id: username, participants: [username], messages: convMessages };
      const lastMessageAt = Math.max(...messages.map((m) => m.timestamp ?? 0), Date.now());
      const syncMessages = messages.map((m) => ({
        conversationWith: username,
        messageId: m.messageId,
        text: m.text,
        mediaUrls: [],
        isSent: m.isSent,
        isRead: true,
        reactions: m.reactions || [],
        timestamp: m.timestamp ?? Date.now()
      }));
      const syncConversations = [
        {
          username,
          fullName: "",
          avatarUrl: "",
          isVerified: false,
          messageCount: messages.length,
          unreadCount: 0,
          lastMessageAt
        }
      ];
      await chrome.runtime.sendMessage({ type: "SYNC_DMS", messages: syncMessages, conversations: syncConversations });
      let serverDmScore = 0;
      try {
        const resp = await chrome.runtime.sendMessage({ type: "ANALYZE_DMS", username });
        serverDmScore = resp?.dmScore ?? 0;
      } catch {
      }
      const keywordTone = this.analyzer.scoreKeywordsTone(conversation);
      const tone = this.analyzer.analyzeConversationTone(convMessages);
      const sent = convMessages.filter((m) => m.isSent).length;
      const received = convMessages.length - sent;
      const ts = convMessages.map((m) => m.timestamp).filter((t) => !!t);
      const firstInteractionDate = ts.length ? Math.min(...ts) : Date.now();
      const lastInteractionDate = ts.length ? Math.max(...ts) : Date.now();
      const contact = {
        username,
        conversation,
        likesGiven: 0,
        commentsGiven: 0,
        storiesViewed: 0,
        sharesReceived: 0,
        profileVisits: 0,
        timeSpentMinutes: 0,
        linkClicks: 0,
        firstInteractionDate,
        lastInteractionDate,
        isFollowingBack: received > 0,
        mutualEngagementCount: Math.min(received, 5),
        mutualConnectionsCount: 0
      };
      const breakdown = this.scoring.calculateTotalScore(contact);
      breakdown.dms = Math.min(30, serverDmScore + keywordTone);
      breakdown.total = Math.min(
        100,
        breakdown.dms + breakdown.engagement + breakdown.activity + breakdown.seniority + breakdown.reciprocity
      );
      const category = this.scoring.determineSuggestedCategory(breakdown.total, tone.category);
      const dyn = this.dynamics.analyze(messages, seenReceipt);
      const coaching = this.settingCoach.analyze(messages, dyn);
      const advice = this.dynamics.buildAdvice(dyn);
      console.log(
        `\u{1F4CA} [Pro] @${username} \u2014 dms=${breakdown.dms} (serveur ${serverDmScore} + mots-cl\xE9s ${keywordTone}), total=${breakdown.total}, cat\xE9gorie=${category}, temp\xE9rature=${dyn.temperature} (${dyn.temperatureScore}), phase=${coaching.phase}`
      );
      await chrome.runtime.sendMessage({
        type: "UPDATE_CONTACT_SCORE",
        username,
        scoreBreakdown: breakdown,
        category,
        temperature: dyn.temperature,
        dynamics: dyn,
        advice,
        settingPhase: coaching.phase,
        settingSummary: coaching.summary
      });
    }
    // ==================== Recherche dans l'inbox ====================
    /**
     * Localise la ligne de conversation d'un contact dans l'inbox.
     *
     * On ne connaît que le @username (ID Instagram), or les lignes de l'inbox
     * affichent le NOM de profil (« Paco Martinez »), pas le username. Comme le
     * contact a été ajouté depuis « people », on dispose aussi de son nom de
     * profil (`fullName`) : c'est lui qui permet de matcher la ligne.
     *
     * L'inbox répartit en outre les conversations entre onglets (Primary /
     * General) : on cherche dans l'onglet actif (Primary) puis, si rien, on
     * bascule sur « General » et on réessaie.
     */
    async scrollAndLocateRow(username, fullName = "") {
      if (this.isOnThread()) {
        window.location.href = "https://www.instagram.com/direct/inbox/";
        await this.sleep(2500);
      }
      let row = await this.scrollAndLocateRowInTab(username, fullName);
      if (row) return row;
      if (await this.switchInboxTab(["General", "G\xE9n\xE9ral", "Generale"])) {
        this.overlay.show(`Searching for @${username} in "General"\u2026`);
        row = await this.scrollAndLocateRowInTab(username, fullName);
        if (row) return row;
      }
      return null;
    }
    /**
     * Localise la ligne de conversation dans l'onglet actuellement affiché en
     * scrollant l'historique de la liste. La liste est virtualisée : on extrait
     * au fil du scroll et on s'arrête dès qu'on trouve la ligne correspondante ou
     * qu'on atteint le bas.
     */
    async scrollAndLocateRowInTab(username, fullName = "") {
      let row = this.findConversationRow(username, fullName);
      if (row) return row;
      const list = await this.findInboxListContainer();
      if (!list) {
        console.warn("\u26A0\uFE0F [Pro] Liste des conversations inbox introuvable");
        return this.findConversationRow(username, fullName);
      }
      let stuck = 0;
      let attempts = 0;
      const maxStuck = 6;
      while (stuck < maxStuck && attempts < 200) {
        attempts++;
        const beforeTop = list.scrollTop;
        const beforeHeight = list.scrollHeight;
        const atBottom = await this.humanScrollListDown(list);
        await this.waitForListLoad(list, beforeHeight);
        row = this.findConversationRow(username, fullName);
        if (row) return row;
        const noProgress = list.scrollTop <= beforeTop + 2 && list.scrollHeight <= beforeHeight + 2;
        if (atBottom || noProgress) {
          stuck++;
        } else {
          stuck = 0;
        }
      }
      return null;
    }
    /** Trouve le conteneur scrollable de la liste des conversations de l'inbox. */
    async findInboxListContainer() {
      const deadline = Date.now() + 8e3;
      while (Date.now() < deadline) {
        const threadLink = document.querySelector('a[href^="/direct/t/"]');
        if (threadLink) {
          let el = threadLink;
          while (el && el !== document.body) {
            if (this.isScrollable(el)) return el;
            el = el.parentElement;
          }
        }
        await this.sleep(300);
      }
      return null;
    }
    /**
     * Bascule sur l'onglet de l'inbox dont le libellé correspond (Primary /
     * General / Demandes). Renvoie true si l'onglet a été trouvé et cliqué.
     * Les onglets sont des éléments cliquables en haut de la liste contenant
     * exactement le libellé recherché.
     */
    async switchInboxTab(labels) {
      const wanted = labels.map((l) => l.toLowerCase());
      const all = Array.from(document.querySelectorAll("span, div, a, button"));
      const leaf = all.find((el) => {
        const text = (el.textContent || "").trim().toLowerCase();
        return wanted.includes(text);
      });
      if (!leaf) {
        console.warn(`\u26A0\uFE0F [Pro] Onglet inbox introuvable (${labels.join("/")})`);
        return false;
      }
      const clickable = leaf.closest('[role="tab"], [role="button"], a, button') || leaf;
      console.log(`\u{1F5C2}\uFE0F [Pro] Bascule sur l'onglet \xAB ${leaf.textContent?.trim()} \xBB`);
      clickable.click();
      await this.sleep(1800);
      return true;
    }
    isScrollable(el) {
      const style2 = window.getComputedStyle(el);
      const oy = style2.overflowY;
      return (oy === "auto" || oy === "scroll") && el.scrollHeight > el.clientHeight + 10;
    }
    /** Scrolle la liste vers le BAS de façon progressive/humaine. Renvoie true si en bas. */
    async humanScrollListDown(container) {
      const maxTop = container.scrollHeight - container.clientHeight;
      const current = container.scrollTop;
      if (current >= maxTop - 5) {
        container.scrollTop = maxTop;
        await this.sleep(400);
        return true;
      }
      const baseScroll = 300 + Math.random() * 200;
      const variation = Math.random() * 200 - 100;
      const amount = Math.min(baseScroll + variation, maxTop - current);
      const steps = 5 + Math.floor(Math.random() * 5);
      const stepSize = amount / steps;
      const stepDelay = 16 + Math.floor(Math.random() * 20);
      for (let i = 0; i < steps; i++) {
        container.scrollTop += stepSize;
        await this.sleep(stepDelay);
      }
      await this.sleep(300 + Math.random() * 400);
      return container.scrollTop >= maxTop - 5;
    }
    async waitForListLoad(container, initialHeight) {
      const start = Date.now();
      while (Date.now() - start < 4e3) {
        await this.sleep(120);
        if (container.scrollHeight > initialHeight) {
          await this.sleep(200);
          return;
        }
      }
    }
    /**
     * Cherche, parmi les lignes affichées, la conversation du contact.
     *
     * Les lignes de l'inbox affichent généralement le NOM de profil et non le
     * @username : le `fullName` (connu via « people ») est donc le critère
     * principal. On retombe sur le username quand il est disponible (lien profil
     * ou texte de la ligne), pour les comptes dont le nom = le username.
     */
    findConversationRow(username, fullName = "") {
      const target = username.toLowerCase();
      const name = fullName.trim().toLowerCase();
      const profileLink = Array.from(document.querySelectorAll('a[href^="/"]')).find((a) => {
        const href = a.getAttribute("href") || "";
        const m = href.match(/^\/([a-zA-Z0-9._]+)\/?$/);
        return m && m[1].toLowerCase() === target;
      });
      if (profileLink) {
        const row = profileLink.closest('[role="button"], li, div[role="listitem"]');
        if (row) return row;
      }
      const candidates = Array.from(
        document.querySelectorAll('[role="button"], li, div[role="listitem"]')
      );
      for (const el of candidates) {
        const text = (el.textContent || "").toLowerCase();
        if (text.length === 0 || text.length >= 200) continue;
        if (name && text.includes(name)) return el;
        if (text.includes(target)) return el;
      }
      return null;
    }
    async openThread(row) {
      row.click();
      const deadline = Date.now() + 8e3;
      while (Date.now() < deadline) {
        if (this.isOnThread()) break;
        await this.sleep(300);
      }
      await this.sleep(1500);
    }
    // ==================== Phase 3 (hook — implémenté ensuite) ====================
    /**
     * Détecte si la conversation est non lue (point bleu) et, le cas échéant,
     * demande la permission d'entrer. Renvoie true si on peut continuer.
     */
    async checkUnreadAndAskPermission(row, username) {
      const isUnread = this.isRowUnread(row);
      if (!isUnread) {
        return true;
      }
      const unreadReceivedAt = this.readRowTimestamp(row);
      await this.setState({ phase: "await_permission", unreadDetected: true, unreadReceivedAt });
      const heure = unreadReceivedAt ? new Date(unreadReceivedAt).toLocaleString() : "recently";
      this.overlay.show("Waiting for your authorization\u2026");
      const allowed = await showConfirmDialog(
        `@${username}'s message hasn't been read yet (received ${heure}).

Opening the conversation will mark it as read. Do you authorize the analysis?`,
        { title: "Unread message", okLabel: "Allow", cancelLabel: "Decline" }
      );
      if (!allowed) {
        await this.recordRefusal({ username, refusedAt: Date.now(), unreadReceivedAt });
        this.overlay.showError("You declined opening the conversation. Process stopped");
        return false;
      }
      return true;
    }
    /** Détecte un indicateur "non lu" (point bleu / aria-label / texte en gras). */
    isRowUnread(row) {
      if (row.querySelector('[aria-label*="Unread" i], [aria-label*="Non lu" i], [aria-label*="non lu" i]')) {
        return true;
      }
      const dots = row.querySelectorAll("div, span");
      for (const el of Array.from(dots)) {
        const style2 = window.getComputedStyle(el);
        const bg = style2.backgroundColor || "";
        const radius = style2.borderRadius || "";
        const m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        if (m && (radius.includes("50%") || radius.includes("9999"))) {
          const r = +m[1], g = +m[2], b = +m[3];
          if (b > 180 && b > r + 60 && g > 100 && r < 120) {
            return true;
          }
        }
      }
      const strongish = Array.from(row.querySelectorAll("span, div")).some((el) => {
        const fw = window.getComputedStyle(el).fontWeight;
        const n = parseInt(fw, 10);
        return !isNaN(n) && n >= 700;
      });
      return strongish;
    }
    /** Lit l'horodatage du dernier message de la ligne (en ms) si disponible. */
    readRowTimestamp(row) {
      const timeEl = row.querySelector("time");
      const dt = timeEl?.getAttribute("datetime");
      if (dt) {
        const t = new Date(dt).getTime();
        if (!isNaN(t)) return t;
      }
      return null;
    }
    async recordRefusal(refusal) {
      const stored = await chrome.storage.local.get("proRefusals");
      const list = Array.isArray(stored.proRefusals) ? stored.proRefusals : [];
      list.push(refusal);
      await chrome.storage.local.set({ proRefusals: list });
      console.log(`\u{1F6AB} [Pro] Refus enregistr\xE9 pour @${refusal.username}`, refusal);
    }
    // 8 s
    /**
     * Démarre la surveillance des conversations ouvertes par l'utilisateur.
     * Quand il ouvre la conversation d'un contact suivi (people), on analyse
     * silencieusement les messages visibles et on met à jour ses stats.
     */
    startLiveWatch(peopleUsernames) {
      if (this.liveWatchStarted) return;
      this.liveWatchStarted = true;
      this.livePeople = new Set(peopleUsernames.map((u) => u.toLowerCase()));
      console.log(`\u2728 [Pro] Live watch d\xE9marr\xE9 pour ${this.livePeople.size} contact(s)`);
      setInterval(() => {
        this.liveTick().catch((e) => console.error("[Pro] liveTick error", e));
      }, 3e3);
    }
    /** Met à jour la liste des contacts suivis (sans relancer l'intervalle). */
    updateLivePeople(peopleUsernames) {
      this.livePeople = new Set(peopleUsernames.map((u) => u.toLowerCase()));
    }
    async liveTick() {
      if (this.running) return;
      if (!this.isOnThread()) return;
      const username = this.getThreadContactUsername();
      if (!username) return;
      const key = username.toLowerCase();
      if (!this.livePeople.has(key)) return;
      const container = document.querySelector('div[role="grid"]');
      const scopeEl = container || document.querySelector("main");
      if (!scopeEl) return;
      const signature = this.computeThreadSignature(scopeEl);
      const last = this.liveLastAnalyzed.get(key) || 0;
      const sinceLast = Date.now() - last;
      const changed = this.liveLastSignature.get(key) !== signature;
      if (changed) {
        if (sinceLast < this.LIVE_MIN_GAP_MS) return;
      } else if (sinceLast < this.LIVE_THROTTLE_MS) {
        return;
      }
      this.liveLastAnalyzed.set(key, Date.now());
      this.liveLastSignature.set(key, signature);
      console.log(`\u2728 [Pro] Analyse live de la conversation avec @${username}${changed ? " (nouveau message d\xE9tect\xE9)" : ""}`);
      const extractor = new DMMessageExtractor();
      await extractor.expandVoiceTranscripts(scopeEl);
      extractor.extractVisible(scopeEl);
      const messages = extractor.getAll();
      if (messages.length === 0) return;
      const seenReceipt = extractor.detectSeenReceipt(scopeEl);
      await this.persistAnalysis(username, messages, seenReceipt);
      console.log(`\u2705 [Pro] Stats live mises \xE0 jour pour @${username} (${messages.length} messages visibles)`);
    }
    /**
     * Signature légère du thread visible pour détecter un nouveau message SANS
     * cliquer/déplier (l'expansion des vocaux ne se fait qu'au moment d'analyser) :
     * nombre de bulles + texte de la dernière bulle.
     */
    computeThreadSignature(scopeEl) {
      const rows = scopeEl.querySelectorAll('div[role="row"]');
      const lastText = (rows[rows.length - 1]?.textContent || "").slice(0, 80);
      return `${rows.length}|${lastText}`;
    }
    /**
     * Extrait le username du contact depuis l'en-tête du thread ouvert.
     *
     * IG ne met pas toujours de <header> sémantique : on tente plusieurs sources,
     * de la plus fiable à la plus permissive, en excluant la barre de navigation
     * gauche (son propre profil) et la liste des conversations (liens /direct/t/).
     */
    getThreadContactUsername() {
      const profileRe = /^\/([a-zA-Z0-9._]{1,40})\/?$/;
      const reserved = /* @__PURE__ */ new Set(["explore", "reels", "reel", "direct", "stories", "accounts", "p", "tv", "about"]);
      const fromHref = (el) => {
        const m = (el?.getAttribute("href") || "").match(profileRe);
        return m && !reserved.has(m[1].toLowerCase()) ? m[1] : null;
      };
      const labelRe = /voir le profil|voir profil|view profile/i;
      const labeled = Array.from(document.querySelectorAll('a[href^="/"]')).find(
        (a) => labelRe.test((a.textContent || "") + " " + (a.getAttribute("aria-label") || "")) && fromHref(a)
      );
      if (labeled) return fromHref(labeled);
      const headerUser = fromHref(document.querySelector('header a[href^="/"]'));
      if (headerUser) return headerUser;
      const subtitle = Array.from(document.querySelectorAll("span, div")).find((el) => {
        if (el.children.length > 0) return false;
        return /^[a-zA-Z0-9._]{1,40}\s*·\s*Instagram$/i.test((el.textContent || "").trim());
      });
      if (subtitle) {
        const u = (subtitle.textContent || "").trim().split("\xB7")[0].trim();
        if (u && !reserved.has(u.toLowerCase())) return u;
      }
      const candidate = Array.from(document.querySelectorAll('a[href^="/"]')).filter((a) => {
        if (!fromHref(a)) return false;
        if (a.closest('nav, [role="navigation"]')) return false;
        if (a.closest('a[href^="/direct/t/"]')) return false;
        const r = a.getBoundingClientRect();
        return r.width > 0 && r.top >= 0 && r.top < 220;
      }).sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0];
      return fromHref(candidate);
    }
    // ==================== Helpers ====================
    /**
     * Résout le nom de profil (full_name) d'un username via l'API web interne
     * d'Instagram. Sert de repli quand « people » n'a pas stocké le nom : la
     * ligne de l'inbox affiche ce nom et non le @username. Renvoie '' si le compte
     * n'a pas de nom (ou en cas d'erreur) — le match par username prendra le relais.
     */
    async resolveProfileName(username) {
      try {
        const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || "";
        const resp = await fetch(
          `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`,
          {
            headers: { "x-ig-app-id": "936619743392459", ...csrf ? { "x-csrftoken": csrf } : {} },
            credentials: "include"
          }
        );
        if (!resp.ok) {
          console.log(`\u26A0\uFE0F [Pro] web_profile_info @${username} \u2192 HTTP ${resp.status}`);
          return "";
        }
        const data = await resp.json();
        return (data?.data?.user?.full_name || "").trim();
      } catch (e) {
        console.log(`\u26A0\uFE0F [Pro] R\xE9solution du nom de @${username} \xE9chou\xE9e:`, e);
        return "";
      }
    }
    isOnInbox() {
      return window.location.pathname.startsWith("/direct/inbox");
    }
    isOnThread() {
      return window.location.pathname.startsWith("/direct/t/");
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };

  // src/content/pro-engagement-collector.ts
  var STATE_KEY2 = "proEngagementState";
  var POSTS_RATIO = 0.5;
  var POSTS_MIN = 20;
  var POSTS_MAX = 150;
  var MAX_FOLLOWING_PAGES = 20;
  var MAX_MUTUAL_PEOPLE = 10;
  var MAX_MUTUAL_MEMBERS = 50;
  var ProEngagementCollector = class {
    constructor(overlay) {
      this.running = false;
      this.overlay = overlay;
    }
    // ==================== État ====================
    async getState() {
      try {
        const stored = await chrome.storage.local.get(STATE_KEY2);
        return stored[STATE_KEY2] || null;
      } catch {
        return null;
      }
    }
    async setState(patch) {
      const current = await this.getState() || {};
      const next = { ...current, ...patch };
      try {
        await chrome.storage.local.set({ [STATE_KEY2]: next });
      } catch {
      }
      return next;
    }
    async clearState() {
      try {
        await chrome.storage.local.remove(STATE_KEY2);
      } catch {
      }
    }
    // ==================== Démarrage / reprise ====================
    /**
     * Démarre l'analyse (depuis le popup). `ownUsername` = compte connecté ;
     * `targets` = usernames des People à suivre.
     */
    async start(ownUsername, targets) {
      if (!ownUsername) {
        this.overlay.showError("Connected account not found \u2014 open Instagram while logged in");
        return;
      }
      if (!targets || targets.length === 0) {
        this.overlay.showError("No people in People to analyze");
        return;
      }
      console.log(`\u2728 [ProEng] D\xE9marrage pour @${ownUsername} \u2014 ${targets.length} People`);
      await this.setState({
        phase: "run",
        ownUsername,
        targets: targets.map((t) => t.toLowerCase()),
        startedAt: Date.now()
      });
      this.overlay.show("Opening your profile\u2026");
      if (this.isOnOwnProfile(ownUsername)) {
        await this.resume();
      } else {
        window.location.href = `https://www.instagram.com/${ownUsername}/`;
      }
    }
    /** Reprend l'analyse au (re)chargement du content script. */
    async resume() {
      const state = await this.getState();
      if (!state || state.phase !== "run") return;
      if (this.running) return;
      this.running = true;
      try {
        if (!this.isOnOwnProfile(state.ownUsername)) {
          this.overlay.show("Opening your profile\u2026");
          window.location.href = `https://www.instagram.com/${state.ownUsername}/`;
          return;
        }
        await this.runAll(state);
      } catch (error) {
        console.error("\u274C [ProEng] Erreur:", error);
        this.overlay.showError("Error while analyzing engagement");
        await this.clearState();
      } finally {
        this.running = false;
      }
    }
    // ==================== Boucle principale (sur le profil, SPA) ====================
    async runAll(state) {
      await this.sleep(2e3);
      let totalPosts = 0;
      try {
        totalPosts = new ProfileAnalyzer().extractProfileStats()?.posts || 0;
      } catch {
      }
      const cap = totalPosts > 0 ? Math.max(POSTS_MIN, Math.min(POSTS_MAX, Math.ceil(totalPosts * POSTS_RATIO))) : POSTS_MIN;
      console.log(`\u2728 [ProEng] Analyse jusqu'\xE0 ${cap} post(s) (total\u2248${totalPosts})`);
      const processed = /* @__PURE__ */ new Set();
      const collected = {};
      const ensure = (u) => {
        if (!collected[u]) collected[u] = { likedPosts: [], comments: [] };
        return collected[u];
      };
      const engagers = /* @__PURE__ */ new Map();
      const own = (state.ownUsername || "").toLowerCase();
      const trackEngager = (username, postId, kind) => {
        if (!username || username === own) return;
        let e = engagers.get(username);
        if (!e) {
          e = { posts: /* @__PURE__ */ new Set(), liked: false, commented: false };
          engagers.set(username, e);
        }
        e.posts.add(postId);
        if (kind === "like") e.liked = true;
        else e.commented = true;
      };
      let stuckScrolls = 0;
      while (processed.size < cap && stuckScrolls < 6) {
        const next = this.findNextGridPost(processed);
        if (!next) {
          window.scrollBy(0, 1400 + Math.random() * 600);
          await this.sleep(1200 + Math.random() * 600);
          stuckScrolls++;
          continue;
        }
        stuckScrolls = 0;
        processed.add(next.postId);
        this.overlay.updateProgress(processed.size, cap, `Analyse du post ${processed.size}\u2026`);
        const opened = await this.openPostModal(next.el, next.postId);
        if (!opened) {
          console.warn(`\u26A0\uFE0F [ProEng] Impossible d'ouvrir le post ${next.postId}, on saute`);
          await this.closeModal();
          continue;
        }
        const root = this.getModalRoot();
        console.log(`\u{1F50E} [ProEng] Post ${next.postId} ouvert (href=${window.location.href})`);
        await this.loadComments(root);
        const nowIso = (/* @__PURE__ */ new Date()).toISOString();
        let peopleComments = 0;
        for (const { username, commentedAt } of this.extractComments(root)) {
          trackEngager(username, next.postId, "comment");
          if (state.targets.includes(username)) {
            ensure(username).comments.push({ postId: next.postId, postUrl: next.postUrl, commentedAt });
            console.log(`\u{1F4AC} [ProEng] @${username} a comment\xE9 ${next.postUrl} (${commentedAt})`);
            peopleComments++;
          }
        }
        const likers = await this.openAndCollectLikers(root, next.postId);
        let peopleLikes = 0;
        for (const u of likers) {
          trackEngager(u, next.postId, "like");
          if (state.targets.includes(u)) {
            ensure(u).likedPosts.push({ postId: next.postId, postUrl: next.postUrl, likedAt: nowIso });
            console.log(`\u2764\uFE0F [ProEng] @${u} a lik\xE9 ${next.postUrl}`);
            peopleLikes++;
          }
        }
        console.log(
          `\u{1F50D} [ProEng] Post ${next.postId} : ${likers.length} liker(s) lus \u2192 ${peopleLikes} People ; ${peopleComments} commentaire(s) People`
        );
        await this.closeModal();
        await this.sleep(800 + Math.random() * 900);
      }
      const engagersPayload = Array.from(engagers.entries()).filter(([, e]) => e.posts.size >= 2).map(([username, e]) => ({ username, posts: e.posts.size, liked: e.liked, commented: e.commented }));
      const presentPeople = Object.keys(collected);
      const mutuals = await this.collectMutuals(presentPeople, state.ownUsername);
      await this.finish(collected, Array.from(processed), engagersPayload, mutuals);
    }
    /** Trouve la prochaine vignette de post non encore traitée dans la grille. */
    findNextGridPost(processed) {
      const main = document.querySelector("main") || document.body;
      const anchors = Array.from(
        main.querySelectorAll('a[href*="/p/"], a[href*="/reel/"], a[href*="/reels/"]')
      );
      for (const a of anchors) {
        const href = a.getAttribute("href") || "";
        const m = href.match(/\/(p|reel|reels)\/([^/]+)/);
        if (!m) continue;
        const postId = m[2];
        if (processed.has(postId)) continue;
        return { el: a, postId, postUrl: `https://www.instagram.com${m[0]}/` };
      }
      return null;
    }
    /** Clique une vignette et attend l'ouverture de la modale du post. */
    async openPostModal(el, postId) {
      el.scrollIntoView({ block: "center" });
      await this.sleep(500);
      el.click();
      const deadline = Date.now() + 8e3;
      while (Date.now() < deadline) {
        const hasDialog = !!document.querySelector('div[role="dialog"]');
        const onPost = this.extractPostId(window.location.pathname) === postId;
        if (onPost && (hasDialog || this.isOnPostPage())) return true;
        await this.sleep(300);
      }
      return this.extractPostId(window.location.pathname) === postId;
    }
    /** Racine de la modale du post (pour scoper l'extraction). */
    getModalRoot() {
      return document.querySelector('div[role="dialog"]') || document.body;
    }
    /** Ferme la/les modale(s) ouverte(s) et revient à la grille du profil. */
    async closeModal() {
      for (let i = 0; i < 4; i++) {
        if (!document.querySelector('div[role="dialog"]') && !this.isOnPostPage()) return;
        const closeBtn = document.querySelector(
          'svg[aria-label="Close"], svg[aria-label="Fermer"]'
        )?.closest('button, [role="button"]') || null;
        if (closeBtn) closeBtn.click();
        else document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        await this.sleep(700);
      }
    }
    /**
     * Charge davantage de commentaires dans la modale (scroll de la zone de
     * commentaires + clic sur les boutons "voir plus de commentaires" / "+").
     */
    async loadComments(root) {
      const scrollables = Array.from(root.querySelectorAll("div, ul")).filter((el) => {
        const st = getComputedStyle(el);
        return (st.overflowY === "auto" || st.overflowY === "scroll") && el.scrollHeight > el.clientHeight + 20;
      });
      for (let i = 0; i < 5; i++) {
        for (const s of scrollables) s.scrollTop = s.scrollHeight;
        const more = Array.from(root.querySelectorAll('button, [role="button"], span')).find(
          (el) => {
            const t = (el.textContent || "").trim().toLowerCase();
            return /load more|view (all|more).*comment|plus de comment|voir.*comment|charger plus|afficher.*comment/.test(t) || t === "+";
          }
        );
        more?.click();
        await this.sleep(700);
      }
    }
    /**
     * Extrait TOUS les commentateurs de la modale du post (un par username).
     * Le filtrage People (targets) se fait au point d'appel ; on renvoie tout afin
     * d'alimenter aussi les suggestions de People.
     */
    extractComments(root) {
      const out = [];
      const seen = /* @__PURE__ */ new Set();
      for (const a of Array.from(root.querySelectorAll('a[href^="/"]'))) {
        const href = a.getAttribute("href") || "";
        const m = href.match(/^\/([a-zA-Z0-9._]+)\/?$/);
        if (!m) continue;
        const username = m[1].toLowerCase();
        if (seen.has(username)) continue;
        const dt = this.findCommentTime(a);
        if (!dt) continue;
        seen.add(username);
        out.push({ username, commentedAt: dt });
      }
      return out;
    }
    /** Cherche l'horodatage (<time datetime>) associé au lien auteur d'un commentaire. */
    findCommentTime(authorLink) {
      let node = authorLink;
      for (let i = 0; i < 6 && node; i++) {
        const timeEl = node.querySelector?.("time");
        const dt = timeEl?.getAttribute("datetime");
        if (dt && (node.textContent || "").length < 500) return dt;
        node = node.parentElement;
      }
      return null;
    }
    /**
     * Récupère les likers d'un post.
     *  0) API interne Instagram (le plus fiable, aucun clic) ;
     *  A) clic direct sur le compteur de likes dans la modale (photos) ;
     *  B) "Voir les statistiques" → clic du compteur (reels, fallback DOM).
     */
    async openAndCollectLikers(root, shortcode) {
      const apiUsers = await this.fetchLikersViaApi(shortcode);
      if (apiUsers) {
        console.log(`\u{1F4CB} [ProEng] (API) Liste des likers : ${apiUsers.length} username(s)`);
        return apiUsers;
      }
      if (/be the first to like|première personne|premier à aimer|soyez la première/i.test(root.textContent || "")) {
        console.log("\u2139\uFE0F [ProEng] Post sans like (0)");
        return [];
      }
      const trigger = this.findLikesTrigger(root);
      if (trigger) {
        console.log(`\u{1F446} [ProEng] Compteur de likes ("${(trigger.textContent || "").trim().slice(0, 20)}") \u2192 ouverture\u2026`);
        const usersA = await this.clickAndReadLikers(trigger);
        if (usersA) return usersA;
        console.log(`\u21AA\uFE0F [ProEng] La liste des likers ne s'est pas ouverte \u2192 tentative via "Voir les statistiques"`);
      } else {
        console.log('\u21AA\uFE0F [ProEng] Compteur introuvable dans la modale \u2192 tentative via "Voir les statistiques"');
      }
      const went = await this.openInsights();
      if (!went) {
        console.log('\u26A0\uFE0F [ProEng] "Voir les statistiques" indisponible \u2014 likes non r\xE9cup\xE9r\xE9s');
        return [];
      }
      await this.sleep(1500);
      let users = [];
      const candidates = this.findLikesCounters(document.body);
      console.log(`\u{1F522} [ProEng] ${candidates.length} compteur(s) \u2764\uFE0F candidat(s) sur la page stats`);
      if (candidates.length === 0) this.dumpInsightsCandidates();
      for (const c of candidates) {
        console.log(`\u{1F446} [ProEng] (statistiques) essai compteur ("${(c.textContent || "").trim().slice(0, 12)}") \u2192 ouverture\u2026`);
        const u = await this.clickAndReadLikers(c);
        if (u) {
          users = u;
          break;
        }
      }
      if (users.length === 0 && candidates.length > 0) {
        console.log("\u26A0\uFE0F [ProEng] Aucun candidat n'a ouvert la liste des likers");
      }
      await this.closeInsightsView();
      return users;
    }
    /**
     * Renvoie tous les compteurs ❤️ candidats (nombre seul près d'une icône cœur),
     * en priorisant la barre d'action ("J'aime") sur le panneau stats ("Icône J'aime").
     */
    findLikesCounters(root) {
      const out = [];
      const seen = /* @__PURE__ */ new Set();
      const icons = Array.from(root.querySelectorAll("svg[aria-label]")).filter(
        (s) => /like|j['’]?aime|aimer/i.test(s.getAttribute("aria-label") || "")
      );
      icons.sort((a, b) => {
        const la = (a.getAttribute("aria-label") || "").toLowerCase();
        const lb = (b.getAttribute("aria-label") || "").toLowerCase();
        const sa = /^j['’]?aime$/.test(la) ? 0 : 1;
        const sb = /^j['’]?aime$/.test(lb) ? 0 : 1;
        return sa - sb;
      });
      for (const icon of icons) {
        let node = icon.parentElement;
        for (let lvl = 0; lvl < 4 && node; lvl++) {
          const numEl = Array.from(
            node.querySelectorAll('span, div[role="button"], button, [role="button"], div')
          ).find((e) => {
            if (e.querySelector("svg")) return false;
            if (e.closest("a")) return false;
            const t = (e.textContent || "").trim();
            return /^\d[\d.,\sKkMm]*$/.test(t) && t.length > 0 && t.length <= 10;
          });
          if (numEl && !seen.has(numEl)) {
            seen.add(numEl);
            out.push(numEl);
            break;
          }
          node = node.parentElement;
        }
      }
      return out;
    }
    /**
     * Active un élément : focus + séquence pointer/mouse + click + touche Entrée.
     * (Certains handlers React ignorent .click() ; les boutons `tabindex=0`
     * réagissent souvent au clavier.)
     */
    realClick(el) {
      const opts = { bubbles: true, cancelable: true, view: window };
      try {
        el.focus();
      } catch {
      }
      try {
        el.dispatchEvent(new PointerEvent("pointerdown", opts));
        el.dispatchEvent(new MouseEvent("mousedown", opts));
        el.dispatchEvent(new PointerEvent("pointerup", opts));
        el.dispatchEvent(new MouseEvent("mouseup", opts));
      } catch {
      }
      el.click();
      const key = { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 };
      el.dispatchEvent(new KeyboardEvent("keydown", key));
      el.dispatchEvent(new KeyboardEvent("keyup", key));
    }
    /**
     * Diagnostic : liste dans la console les icônes (aria-label) et les nombres
     * cliquables de la page stats, pour repérer l'élément du compteur de likes.
     */
    dumpInsightsCandidates() {
      const svgLabels = Array.from(document.querySelectorAll("svg[aria-label]")).map((s) => s.getAttribute("aria-label")).filter(Boolean);
      console.log("\u{1F9EA} [ProEng] aria-labels des ic\xF4nes:", svgLabels);
      const nums = Array.from(document.querySelectorAll("span, div, button, a")).filter((e) => /^\d{1,9}$/.test((e.textContent || "").trim())).slice(0, 25).map((e) => ({
        tag: e.tagName.toLowerCase(),
        text: (e.textContent || "").trim(),
        role: e.getAttribute("role"),
        cls: (e.getAttribute("class") || "").slice(0, 40),
        parentSvg: e.parentElement?.querySelector("svg[aria-label]")?.getAttribute("aria-label") || null
      }));
      console.log("\u{1F9EA} [ProEng] nombres cliquables candidats:", nums);
    }
    /** Ferme la vue statistiques (/insights/media/…) via le bouton X (ou Échap). */
    async closeInsightsView() {
      for (let i = 0; i < 4 && /\/insights\//.test(window.location.pathname); i++) {
        const x = document.querySelector(
          'svg[aria-label="Close"], svg[aria-label="Fermer"]'
        )?.closest('button, [role="button"], a') || null;
        if (x) x.click();
        else document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        await this.sleep(900);
      }
    }
    /**
     * Clique le déclencheur des likes et lit la liste si une vraie modale de likers
     * s'ouvre. Renvoie les usernames, ou `null` si aucune liste ne s'est ouverte
     * (afin de tenter un autre chemin).
     */
    async clickAndReadLikers(trigger) {
      const before = document.querySelectorAll('div[role="dialog"]').length;
      for (const target of this.clickTargetsFor(trigger)) {
        console.log(
          `   \u21B3 essai clic [${target.tagName.toLowerCase()}${target.getAttribute("role") ? " role=" + target.getAttribute("role") : ""} tabindex=${target.getAttribute("tabindex")}] "${(target.textContent || "").trim().slice(0, 10)}"`
        );
        this.realClick(target);
        await this.sleep(1500);
        const dialog = this.findLikersDialog();
        const after = document.querySelectorAll('div[role="dialog"]').length;
        const headerOk = !!dialog && /likes|j['’]aime|mentions/i.test((dialog.textContent || "").slice(0, 120));
        console.log(`     dialogs: ${before} \u2192 ${after}, headerOk=${headerOk}`);
        if (dialog && (after > before || headerOk)) {
          const usernames = await this.scrollDialogAndCollectUsernames(dialog);
          console.log(`\u{1F4CB} [ProEng] Liste des likers : ${usernames.length} username(s) lus`);
          document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          await this.sleep(700);
          return usernames;
        }
      }
      return null;
    }
    /**
     * Cibles de clic à essayer pour ouvrir la liste des likers : le span le plus
     * profond, l'élément lui-même, son lien `liked_by`/bouton, puis ses parents
     * qui NE contiennent PAS d'icône (pour éviter de cliquer le cœur = liker).
     */
    clickTargetsFor(trigger) {
      const targets = [];
      const add = (el) => {
        if (el && !targets.includes(el)) targets.push(el);
      };
      let leaf = trigger;
      while (leaf.children.length === 1 && leaf.children[0].textContent?.trim() === leaf.textContent?.trim()) {
        leaf = leaf.children[0];
      }
      add(leaf);
      add(trigger);
      add(trigger.closest('a[href$="/liked_by/"], [role="button"], button'));
      let node = trigger.parentElement;
      for (let i = 0; i < 3 && node; i++) {
        if (!node.querySelector("svg")) add(node);
        node = node.parentElement;
      }
      return targets;
    }
    /** Parmi les modales ouvertes, choisit celle qui ressemble à la liste des likers. */
    findLikersDialog() {
      const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]'));
      if (dialogs.length === 0) return null;
      let best = dialogs[dialogs.length - 1];
      let bestScore = -1;
      for (const d of dialogs) {
        const links = d.querySelectorAll('a[href^="/"]').length;
        const header = /likes|j['’]aime|mentions/i.test((d.textContent || "").slice(0, 120)) ? 100 : 0;
        const score = links + header;
        if (score > bestScore) {
          bestScore = score;
          best = d;
        }
      }
      return best;
    }
    /**
     * Récupère les likers via l'API web interne d'Instagram (même origine, avec
     * la session). Aucun clic → fiable. `shortcode` = id court du post/reel
     * (ex: "DZtF4j6Sfjy"), converti en media_id numérique.
     * Renvoie les usernames (minuscules) ou null si l'API a échoué.
     */
    async fetchLikersViaApi(shortcode) {
      try {
        const mediaId = this.shortcodeToMediaId(shortcode);
        if (!mediaId) return null;
        const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || "";
        const resp = await fetch(`https://www.instagram.com/api/v1/media/${mediaId}/likers/`, {
          headers: {
            "x-ig-app-id": "936619743392459",
            ...csrf ? { "x-csrftoken": csrf } : {}
          },
          credentials: "include"
        });
        if (!resp.ok) {
          console.log(`\u26A0\uFE0F [ProEng] API likers HTTP ${resp.status} (fallback DOM)`);
          return null;
        }
        const data = await resp.json();
        if (!Array.isArray(data?.users)) return null;
        return data.users.map((u) => String(u.username || "").toLowerCase()).filter(Boolean);
      } catch (e) {
        console.log("\u26A0\uFE0F [ProEng] API likers \xE9chec (fallback DOM):", e);
        return null;
      }
    }
    /** Convertit un shortcode Instagram en media_id numérique (base64 custom). */
    shortcodeToMediaId(shortcode) {
      const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
      try {
        let id = 0n;
        for (const ch of shortcode) {
          const v = ALPHABET.indexOf(ch);
          if (v < 0) return null;
          id = id * 64n + BigInt(v);
        }
        return id.toString();
      } catch {
        return null;
      }
    }
    // ==================== Connexions mutuelles (API) ====================
    /** En-têtes communs pour l'API web interne. */
    igApiHeaders() {
      const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || "";
      return { "x-ig-app-id": "936619743392459", ...csrf ? { "x-csrftoken": csrf } : {} };
    }
    /** Récupère l'id numérique d'un compte depuis son username. */
    async fetchUserId(username) {
      try {
        const resp = await fetch(
          `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`,
          { headers: this.igApiHeaders(), credentials: "include" }
        );
        if (!resp.ok) return null;
        const data = await resp.json();
        return data?.data?.user?.id || null;
      } catch {
        return null;
      }
    }
    /**
     * Récupère les abonnements (following) d'un compte via l'API, paginé, en
     * minuscules. Plafonné par MAX_FOLLOWING_PAGES pour borner le coût.
     */
    async fetchFollowing(userId) {
      const out = /* @__PURE__ */ new Set();
      let maxId = "";
      for (let page = 0; page < MAX_FOLLOWING_PAGES; page++) {
        const url = `https://www.instagram.com/api/v1/friendships/${userId}/following/?count=50` + (maxId ? `&max_id=${encodeURIComponent(maxId)}` : "");
        let data;
        try {
          const resp = await fetch(url, { headers: this.igApiHeaders(), credentials: "include" });
          if (!resp.ok) {
            console.log(`\u26A0\uFE0F [ProEng] API following HTTP ${resp.status}`);
            break;
          }
          data = await resp.json();
        } catch (e) {
          console.log("\u26A0\uFE0F [ProEng] API following \xE9chec:", e);
          break;
        }
        const users = Array.isArray(data?.users) ? data.users : [];
        for (const u of users) {
          const name = String(u?.username || "").toLowerCase();
          if (name) out.add(name);
        }
        maxId = data?.next_max_id || "";
        if (!maxId || users.length === 0) break;
        await this.sleep(700 + Math.random() * 600);
      }
      return Array.from(out);
    }
    /**
     * Pour chaque People présent (qui a interagi), calcule les connexions mutuelles
     * par rapport à l'utilisateur Pro = abonnements(personne) ∩ abonnements(Pro).
     */
    async collectMutuals(presentUsernames, ownUsername) {
      if (presentUsernames.length === 0) return [];
      this.overlay.show("Analyzing mutual connections\u2026");
      const ownId = await this.fetchUserId(ownUsername);
      if (!ownId) {
        console.log("\u26A0\uFE0F [ProEng] Impossible de r\xE9soudre l'id du compte Pro \u2014 connexions mutuelles ignor\xE9es");
        return [];
      }
      const myFollowing = new Set(await this.fetchFollowing(ownId));
      console.log(`\u{1F517} [ProEng] Abonnements du compte Pro: ${myFollowing.size}`);
      const targets = presentUsernames.slice(0, MAX_MUTUAL_PEOPLE);
      const mutuals = [];
      for (const username of targets) {
        const id = await this.fetchUserId(username);
        if (!id) continue;
        const theirFollowing = await this.fetchFollowing(id);
        const members = theirFollowing.filter((u) => myFollowing.has(u)).slice(0, MAX_MUTUAL_MEMBERS);
        const count = theirFollowing.reduce((n, u) => myFollowing.has(u) ? n + 1 : n, 0);
        mutuals.push({ username, count, members });
        console.log(`\u{1F517} [ProEng] @${username} : ${count} connexion(s) mutuelle(s) (sur ${theirFollowing.length} abonnements lus)`);
        await this.sleep(800 + Math.random() * 700);
      }
      return mutuals;
    }
    /**
     * Trouve le déclencheur des likes dans `root` : lien `liked_by`, texte
     * "X likes/j'aime", ou (reels) nombre seul près de l'icône cœur.
     */
    findLikesTrigger(root) {
      const likedBy = root.querySelector('a[href$="/liked_by/"]');
      if (likedBy) return likedBy;
      const likeWord = /\d[\d.,\s]*(?:likes?|j['’]?aime|mentions?|me gusta)/i;
      const candidates = Array.from(
        root.querySelectorAll('span, div[role="button"], button, [role="button"]')
      );
      for (const el of candidates) {
        if (el.closest("a")) continue;
        const text = (el.textContent || "").trim();
        if (!text || text.length > 40) continue;
        if (likeWord.test(text)) return el;
      }
      const likeIcons = Array.from(root.querySelectorAll("svg[aria-label]")).filter(
        (s) => /like|j['’]?aime|aimer/i.test(s.getAttribute("aria-label") || "")
      );
      for (const icon of likeIcons) {
        let node = icon.parentElement;
        for (let lvl = 0; lvl < 4 && node; lvl++) {
          const numEl = Array.from(
            node.querySelectorAll('span, div[role="button"], button, [role="button"], div')
          ).find((e) => {
            if (e.querySelector("svg")) return false;
            if (e.closest("a")) return false;
            const t = (e.textContent || "").trim();
            return /^\d[\d.,\sKkMm]*$/.test(t) && t.length > 0 && t.length <= 10;
          });
          if (numEl) return numEl;
          node = node.parentElement;
        }
      }
      return null;
    }
    /**
     * Posts dont on est propriétaire : clique "Voir les statistiques" / "View
     * insights" pour ouvrir le panneau d'engagement (où le compteur de likes est
     * accessible). Renvoie true si l'élément a été cliqué.
     */
    async openInsights() {
      const candidates = Array.from(
        document.querySelectorAll('a, button, span, div[role="button"], [role="button"]')
      );
      const insights = candidates.find((el) => {
        const t = (el.textContent || "").trim().toLowerCase();
        if (!t || t.length > 40) return false;
        return /view insights|voir les statistiques|voir les stats|view all insights/.test(t);
      });
      if (!insights) {
        console.log('\u26A0\uFE0F [ProEng] "Voir les statistiques / View insights" introuvable');
        return false;
      }
      const clickable = insights.closest('a, [role="button"], button') || insights;
      console.log('\u{1F446} [ProEng] "Voir les statistiques" \u2192 ouverture\u2026');
      clickable.click();
      await this.sleep(2e3);
      return true;
    }
    /** Scrolle la modale des likers et collecte les usernames (profil) visibles. */
    async scrollDialogAndCollectUsernames(dialog) {
      const found = /* @__PURE__ */ new Set();
      const ignored = /* @__PURE__ */ new Set(["explore", "p", "reel", "reels", "stories", "direct", "accounts"]);
      const scroller = dialog.querySelector('div._aano, div[style*="overflow"]') || dialog;
      let stuck = 0;
      let prev = -1;
      for (let i = 0; i < 60 && stuck < 5; i++) {
        for (const a of Array.from(dialog.querySelectorAll('a[href^="/"]'))) {
          const m = (a.getAttribute("href") || "").match(/^\/([a-zA-Z0-9._]+)\/?$/);
          if (m && !ignored.has(m[1].toLowerCase())) found.add(m[1].toLowerCase());
        }
        stuck = found.size === prev ? stuck + 1 : 0;
        prev = found.size;
        scroller.scrollTop = scroller.scrollHeight;
        await this.sleep(500 + Math.random() * 400);
      }
      return Array.from(found);
    }
    // ==================== Envoi backend ====================
    async finish(collected, analyzedPosts, engagers, mutuals) {
      this.overlay.show("Updating stats\u2026");
      const postsAnalyzed = analyzedPosts.length;
      const engagements = Object.entries(collected).map(([username, data]) => ({
        username,
        likedPosts: data.likedPosts,
        comments: data.comments
      }));
      await this.setState({ phase: "done" });
      if (engagements.length === 0 && engagers.length === 0 && mutuals.length === 0) {
        this.overlay.showSuccess(`Analysis complete \u2014 no interaction detected across ${postsAnalyzed} posts`);
        await this.clearState();
        return;
      }
      try {
        const resp = await chrome.runtime.sendMessage({
          type: "SYNC_PRO_ENGAGEMENT",
          engagements,
          analyzedPosts,
          engagers,
          mutuals
        });
        if (resp?.success) {
          const totalLikes = engagements.reduce((s, e) => s + e.likedPosts.length, 0);
          const totalComments = engagements.reduce((s, e) => s + e.comments.length, 0);
          this.overlay.showSuccess(
            `Analysis complete! ${totalLikes} like(s) + ${totalComments} comment(s) across ${postsAnalyzed} posts \xB7 ${engagers.length} suggestion(s)`
          );
        } else {
          this.overlay.showError(`Save failed: ${resp?.error || "unknown"}`);
        }
      } catch (e) {
        console.error("\u274C [ProEng] Envoi backend \xE9chou\xE9:", e);
        this.overlay.showError("Failed to send data to the server");
      }
      await this.clearState();
    }
    // ==================== Helpers ====================
    isOnOwnProfile(ownUsername) {
      const p = window.location.pathname.replace(/\/$/, "");
      return p === `/${ownUsername}`;
    }
    isOnPostPage() {
      return /\/(p|reel|reels)\/[^/]+/.test(window.location.pathname);
    }
    extractPostId(url) {
      const m = url.match(/\/(?:p|reel|reels)\/([^/]+)/);
      return m ? m[1] : url;
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
  };

  // src/content/account-linker.ts
  async function autoLinkPrimaryAccount(params) {
    const { dsUserId, igUsername } = params;
    try {
      const registry = await getAccountRegistry();
      if (registry.accounts[dsUserId]?.accountId) return;
      const response = await chrome.runtime.sendMessage({
        type: "LINK_ACCOUNT",
        data: { dsUserId, igUsername }
      });
      if (response?.success) {
        console.log(`\u2705 Compte principal @${igUsername} rattach\xE9 automatiquement`);
      } else {
        console.warn("\u26A0\uFE0F Rattachement auto du compte principal \xE9chou\xE9:", response?.error);
      }
    } catch (error) {
      console.error("Error in autoLinkPrimaryAccount:", error);
    }
  }
  var promptInFlight = false;
  var promptedThisSession = /* @__PURE__ */ new Set();
  function hasEditProfileButton() {
    if (document.querySelector('a[href="/accounts/edit/"], a[href="/accounts/edit"]')) {
      return true;
    }
    const candidates = Array.from(
      document.querySelectorAll('a, button, div[role="button"]')
    );
    return candidates.some((el) => {
      const text = (el.textContent || "").trim().toLowerCase();
      return text === "edit profile" || text === "modifier le profil";
    });
  }
  async function waitForEditProfileButton(timeoutMs = 6e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (hasEditProfileButton()) return true;
      await new Promise((r) => setTimeout(r, 400));
    }
    return false;
  }
  async function maybePromptAccountLink(params) {
    const { dsUserId, igUsername } = params;
    if (promptInFlight || promptedThisSession.has(dsUserId)) return;
    try {
      const registry = await getAccountRegistry();
      const entry = registry.accounts[dsUserId];
      if (entry?.accountId) return;
      if (entry?.dismissed) return;
      const onOwnProfile = await waitForEditProfileButton();
      if (!onOwnProfile) return;
      promptInFlight = true;
      promptedThisSession.add(dsUserId);
      const accepted = await showConfirmDialog(
        `Do you want to link the account @${igUsername} to Waler?

This account will have its own isolated database. You can switch between your accounts from the extension and the dashboard.`,
        {
          title: "\u{1F517} Link this Instagram account",
          okLabel: "Link account",
          cancelLabel: "Not now"
        }
      );
      if (accepted) {
        const response = await chrome.runtime.sendMessage({
          type: "LINK_ACCOUNT",
          data: { dsUserId, igUsername }
        });
        if (response?.success) {
          console.log(`\u2705 Compte @${igUsername} li\xE9 \xE0 Waler`);
        } else {
          console.error("\u274C \xC9chec de la liaison du compte:", response?.error);
          promptedThisSession.delete(dsUserId);
        }
      } else {
        await upsertAccount(dsUserId, { igUsername, dismissed: true });
        console.log(`\u2139\uFE0F Liaison de @${igUsername} refus\xE9e (m\xE9moris\xE9)`);
      }
    } catch (error) {
      console.error("Error in maybePromptAccountLink:", error);
    } finally {
      promptInFlight = false;
    }
  }

  // src/content/instagram-tracker.ts
  var InstagramTracker = class {
    constructor() {
      this.currentUsername = null;
      this.dmSyncInterval = null;
      this.followersCache = /* @__PURE__ */ new Set();
      this.isInitialized = false;
      this.followerCountObserver = null;
      this.lastFollowerCount = 0;
      this.autoCheckInterval = null;
      this.lastUserActivity = Date.now();
      this.INACTIVITY_THRESHOLD = 2 * 60 * 1e3;
      // 2 minutes
      // Nouvelles propriétés pour le système intelligent
      this.followerDatabase = {
        followers: {},
        lastScanDate: "",
        totalCount: 0,
        firstFollowerId: "",
        isInitialized: false
      };
      this.isScanning = false;
      this.scanProgress = { current: 0, total: 0 };
      this.scanOverlay = new scan_overlay_default();
      this.apiInterceptor = new InstagramAPIInterceptor();
      this.recorder = null;
      this.unfollowerDetector = new UnfollowerDetector();
      this.notificationChecker = new NotificationChecker();
      this.observer = new DOMObserver();
      this.collector = new DataCollector();
      this.dmInterceptor = new DMInterceptor();
      this.dmAnalyzer = new DMAnalyzer();
      this.scoringEngine = new ScoringEngine();
      this.proCollector = new ProConversationCollector(this.scanOverlay);
      this.proEngagementCollector = new ProEngagementCollector(this.scanOverlay);
    }
    async init() {
      await this.unfollowerDetector.checkCurrentPageForUnfollower();
      if (this.isInitialized) return;
      if (this.isScanning) {
        console.log("\u23F8\uFE0F Init bloqu\xE9 : scan modal en cours. R\xE9essai dans 2s...");
        setTimeout(() => this.init(), 2e3);
        return;
      }
      window.__walerStop = async () => {
        localStorage.removeItem("unfollowerCheckState");
        localStorage.removeItem("notificationCheckerAutoState");
        await accountSet({ isAnalyzing: false, unfollowerDetected: false, unfollowerCount: 0 });
        console.warn("\u2705 Analyse unfollower stopp\xE9e et nettoy\xE9e. Recharge la page (F5).");
      };
      const unfollowerCheckState = localStorage.getItem("unfollowerCheckState");
      const stored = await accountGet("isAnalyzing");
      if (unfollowerCheckState || stored.isAnalyzing) {
        let startedAt = 0;
        if (unfollowerCheckState) {
          try {
            startedAt = JSON.parse(unfollowerCheckState).startedAt || 0;
          } catch {
            startedAt = 0;
          }
        }
        const STALE_MS = 5 * 60 * 1e3;
        const isPhantom = unfollowerCheckState && (startedAt === 0 || Date.now() - startedAt > STALE_MS) || !unfollowerCheckState && stored.isAnalyzing;
        if (isPhantom) {
          console.warn("\u{1F9F9} \xC9tat d'analyse fant\xF4me d\xE9tect\xE9 (scan interrompu) \u2014 nettoyage et reprise normale.");
          localStorage.removeItem("unfollowerCheckState");
          await accountSet({ isAnalyzing: false, unfollowerDetected: false, unfollowerCount: 0 });
        } else {
          console.log("\u23F8\uFE0F Init bloqu\xE9 : analyse unfollower en cours (navigation entre profils). R\xE9essai dans 3s...");
          setTimeout(() => this.init(), 3e3);
          return;
        }
      }
      console.log("\u{1F50D} Waler Instagram Tracker initializing...");
      console.log("\u{1F195} VERSION: API Interception Auto-Start v1.0");
      this.currentUsername = this.extractUsername();
      if (!this.currentUsername) {
        const loggedInId = this.getLoggedInUserId();
        if (!loggedInId) {
          console.log("\u274C Could not detect Instagram username (utilisateur non connect\xE9 ?)");
          return;
        }
        console.log("\u2139\uFE0F Username non pr\xE9sent dans l'URL, r\xE9solution via le compte connect\xE9 (ds_user_id)...");
        const resolvedCount = await this.fetchRealFollowerCount();
        console.log(`\u2139\uFE0F Compte connect\xE9 r\xE9solu: @${this.currentUsername} (${resolvedCount} followers)`);
        if (!this.currentUsername) {
          console.log("\u274C Impossible de r\xE9soudre le compte connect\xE9");
          return;
        }
      }
      console.log(`\u2705 Tracking account: @${this.currentUsername}`);
      this.collector.setTrackedUsername(this.currentUsername);
      await this.resolveActiveAccount();
      await this.cleanupCorruptedState();
      await this.loadFollowerDatabase();
      console.log("\u{1F50C} Starting continuous API interception...");
      this.apiInterceptor.start(
        (followers) => {
        },
        (data) => {
          this.collector.processUserInfo(data);
        }
      );
      console.log("\u{1F50D} Checking initialization status...");
      console.log("\u{1F4CA} followerDatabase.isInitialized:", this.followerDatabase.isInitialized);
      console.log("\u{1F4CA} Total followers in DB:", Object.keys(this.followerDatabase.followers).length);
      if (!this.followerDatabase.isInitialized) {
        const restored = await this.tryRestoreFromBackend();
        if (restored) {
          console.log("\u2705 Base restaur\xE9e depuis le serveur, scan initial \xE9vit\xE9");
        } else {
          console.log("\u{1F4CA} First launch detected, initial scan required");
          await this.notifyInitialScanRequired();
        }
      } else {
        console.log("\u2705 Database already initialized, skipping initial scan");
      }
      await this.loadFollowersCache();
      if (document.readyState === "complete") {
        await this.notificationChecker.autoCheckNotifications();
      } else {
        window.addEventListener("load", async () => {
          await this.notificationChecker.autoCheckNotifications();
        });
      }
      this.proCollector.resume();
      this.proEngagementCollector.resume();
      this.startProLiveWatch();
      window.addEventListener("message", async (event) => {
        if (event.data.type === "TRIGGER_AGENT_B_FROM_PAGE") {
          console.log("\u{1F916} Message re\xE7u pour d\xE9clencher l'Agent B:", event.data.data);
          await this.unfollowerDetector.triggerAgentB(event.data.data.missingUsernames);
        }
      });
      document.addEventListener("keydown", (e) => {
        if (e.ctrlKey && e.altKey && e.key === "r") {
          e.preventDefault();
          if (!this.recorder) {
            console.log("\u{1F3AC} Activation du Recorder Mode");
            this.recorder = new ActionRecorder();
          } else {
            console.log("\u26A0\uFE0F Recorder d\xE9j\xE0 actif");
          }
        }
      });
      this.observer.onEngagement((engagement) => {
        if (this.isSystemPage() || this.isOnOwnProfile()) {
          console.log(`\u{1F6AB} Ignoring engagement on system page or own profile`);
          return;
        }
        this.collector.trackEngagement(engagement);
      });
      this.observer.start();
      console.log("\u{1F4CA} DOM observation started");
      this.setupFollowersModalObserver();
      await this.startFollowerCountMonitoring();
      this.startDMSync();
      this.trackUserActivity();
      this.isInitialized = true;
      console.log("\u2705 Waler Instagram Tracker ready");
    }
    extractUsername() {
      const metaTag = document.querySelector('meta[property="al:ios:url"]');
      if (metaTag) {
        const content = metaTag.getAttribute("content");
        const match = content?.match(/instagram:\/\/user\?username=([^&]+)/);
        if (match) return match[1];
      }
      const RESERVED_PATHS = [
        "explore",
        "reels",
        "reel",
        "direct",
        "accounts",
        "stories",
        "notifications",
        "p",
        "tv",
        "about",
        "legal",
        "privacy",
        "developer",
        "directory",
        "web",
        "session",
        "emails",
        "challenge",
        "lite",
        "igtv",
        "ar",
        "topics"
      ];
      const pathMatch = window.location.pathname.match(/^\/([^\/]+)/);
      if (pathMatch && !RESERVED_PATHS.includes(pathMatch[1])) {
        return pathMatch[1];
      }
      return null;
    }
    isSystemPage() {
      const path = window.location.pathname;
      const systemPages = ["/explore", "/reels", "/direct", "/accounts", "/stories"];
      return systemPages.some((page) => path.startsWith(page));
    }
    isOnOwnProfile() {
      const path = window.location.pathname;
      return path === `/${this.currentUsername}` || path === `/${this.currentUsername}/`;
    }
    async loadFollowerDatabase() {
      try {
        console.log("\u{1F4C2} Loading follower database from storage...");
        const stored = await accountGet("followerDatabase");
        console.log("\u{1F4C2} Storage result:", stored);
        if (stored.followerDatabase) {
          this.followerDatabase = stored.followerDatabase;
          const actualCount = Object.keys(this.followerDatabase.followers).length;
          console.log(`\u{1F4E6} Loaded follower database: ${actualCount} followers`);
          console.log("\u{1F4E6} Database isInitialized:", this.followerDatabase.isInitialized);
          console.log("\u{1F4E6} Database totalCount:", this.followerDatabase.totalCount);
          console.log(`\u{1F4CA} Database entries: ${actualCount} (historique)`);
          console.log(`\u{1F4CA} Database totalCount: ${this.followerDatabase.totalCount}`);
          console.log(`\u2139\uFE0F Waiting for API to detect real follower count...`);
        } else {
          console.log("\u{1F4E6} No follower database found in storage (first use)");
        }
      } catch (error) {
        console.error("Error loading follower database:", error);
      }
    }
    /**
     * Restaure la base de followers depuis le backend (followers déjà synchronisés
     * en base) au lieu de re-scanner Instagram. Utile quand le cache local a été
     * vidé. Renvoie true si des followers ont été restaurés.
     */
    async tryRestoreFromBackend() {
      try {
        console.log("\u2601\uFE0F Tentative de restauration des followers depuis le serveur...");
        const resp = await chrome.runtime.sendMessage({
          type: "RESTORE_FOLLOWERS"
        });
        if (!resp?.success || !resp.followers || resp.followers.length === 0) {
          console.log("\u2601\uFE0F Aucune donn\xE9e \xE0 restaurer depuis le serveur", resp?.error ? `(${resp.error})` : "");
          return false;
        }
        const followers = {};
        let position = 0;
        for (const f of resp.followers) {
          if (!f.username) continue;
          followers[f.username] = {
            username: f.username,
            avatarUrl: f.avatarUrl,
            addedAt: f.detectedAt || (/* @__PURE__ */ new Date()).toISOString(),
            position: position++
          };
        }
        this.followerDatabase = {
          followers,
          lastScanDate: (/* @__PURE__ */ new Date()).toISOString(),
          totalCount: resp.totalCount ?? Object.keys(followers).length,
          firstFollowerId: "",
          isInitialized: true
        };
        await this.saveFollowerDatabase();
        this.followersCache = new Set(Object.keys(followers));
        await accountSet({ followersCache: Array.from(this.followersCache) });
        console.log(`\u2601\uFE0F ${Object.keys(followers).length} followers restaur\xE9s depuis le serveur`);
        return true;
      } catch (error) {
        console.error("Error restoring followers from backend:", error);
        return false;
      }
    }
    async updateFollowerCountToBackend(followerCount) {
      try {
        console.log(`\u{1F4CA} Sending follower count (${followerCount}) to backend...`);
        chrome.runtime.sendMessage({
          type: "UPDATE_USER_INFO",
          data: {
            username: this.currentUsername,
            followersCount: followerCount,
            followingCount: 0,
            // On mettra à jour plus tard si disponible
            postsCount: 0,
            bio: "",
            isPrivate: false
          }
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("\u274C Error sending follower count:", chrome.runtime.lastError);
          } else if (response && response.success) {
            console.log("\u2705 Follower count sent successfully to backend");
          } else {
            console.warn("\u26A0\uFE0F Failed to send follower count:", response);
          }
        });
      } catch (error) {
        console.error("\u274C Error updating follower count:", error);
      }
    }
    async saveFollowerDatabase() {
      try {
        const entriesCount = Object.keys(this.followerDatabase.followers).length;
        await accountSet({ followerDatabase: this.followerDatabase });
        console.log(`\u{1F4BE} Follower database saved`);
        console.log(`   - Entries (historique): ${entriesCount}`);
        console.log(`   - totalCount (r\xE9el): ${this.followerDatabase.totalCount}`);
      } catch (error) {
        console.error("Error saving follower database:", error);
      }
    }
    async loadFollowersCache() {
      try {
        const stored = await accountGet("followersCache");
        if (stored.followersCache) {
          this.followersCache = new Set(stored.followersCache);
          console.log(`\u{1F4E6} Loaded ${this.followersCache.size} followers from cache`);
        }
      } catch (error) {
        console.error("Error loading followers cache:", error);
      }
    }
    async saveFollowersCache() {
      try {
        await accountSet({ followersCache: Array.from(this.followersCache) });
      } catch (error) {
        console.error("Error saving followers cache:", error);
      }
    }
    /**
     * Démarre la surveillance live des conversations Pro (si l'utilisateur est
     * abonné Pro) : récupère la liste des contacts et observe les ouvertures de
     * conversation pour mettre à jour les stats au fil de l'eau.
     */
    async startProLiveWatch() {
      try {
        const stored = await accountGet("isPro");
        if (stored.isPro !== true) return;
        const resp = await chrome.runtime.sendMessage({ type: "GET_PEOPLE" });
        const people = resp && resp.success && Array.isArray(resp.people) ? resp.people : [];
        const usernames = people.map((p) => p.memberUsername).filter(Boolean);
        if (usernames.length > 0) {
          this.proCollector.startLiveWatch(usernames);
        }
      } catch (error) {
        console.error("Error starting pro live watch:", error);
      }
    }
    async notifyInitialScanRequired() {
      try {
        await chrome.runtime.sendMessage({
          type: "INITIAL_SCAN_REQUIRED"
        });
      } catch (error) {
        console.error("Error sending initial scan notification:", error);
      }
    }
    async updateScanProgress(current, total) {
      this.scanProgress = { current, total };
      try {
        await chrome.runtime.sendMessage({
          type: "SCAN_PROGRESS",
          current,
          total
        });
      } catch (error) {
        console.error("Error updating scan progress:", error);
      }
    }
    async updateBadge(text) {
      try {
        await chrome.runtime.sendMessage({
          type: "UPDATE_BADGE",
          text
        });
      } catch (error) {
        console.error("Error updating badge:", error);
      }
    }
    /**
     * Start DM synchronization
     */
    startDMSync() {
      const interceptor = this.dmInterceptor;
      if (typeof interceptor.start !== "function") {
        console.log("\u{1F4AC} DM interceptor non disponible (stub) - ignor\xE9");
        return;
      }
      console.log("\u{1F4AC} Starting DM interceptor...");
      interceptor.start({});
      this.dmSyncInterval = setInterval(async () => {
        await this.syncDMs();
      }, 6e4);
      console.log("\u{1F4AC} DM interceptor started");
    }
    async syncDMs() {
      try {
        const interceptor = this.dmInterceptor;
        if (typeof interceptor.getConversations !== "function") {
          return;
        }
        const conversations = interceptor.getConversations();
        if (conversations.length === 0) {
          console.log("\u{1F4AC} No DMs to sync");
          return;
        }
        const allMessages = [];
        conversations.forEach((conv) => {
          conv.messages.forEach((msg) => {
            allMessages.push({
              conversationId: conv.username,
              conversationWith: conv.username,
              messageId: `${conv.username}_${msg.timestamp}`,
              text: msg.text,
              timestamp: msg.timestamp,
              isSent: msg.isSent,
              mediaUrls: [],
              reactions: [],
              isRead: true
            });
          });
        });
        try {
          await chrome.runtime.sendMessage({
            type: "SYNC_DMS",
            messages: allMessages,
            conversations: conversations.map((c) => ({
              username: c.username,
              messageCount: c.messageCount,
              lastMessageAt: c.lastMessageAt
            }))
          });
          console.log(`\u{1F4AC} Synced ${allMessages.length} DMs from ${conversations.length} conversations`);
          await interceptor.saveConversations();
        } catch (msgError) {
          if (msgError.message?.includes("Extension context invalidated")) {
            console.log("\u26A0\uFE0F Extension reloaded, stopping DM sync");
            if (this.dmSyncInterval) {
              clearInterval(this.dmSyncInterval);
              this.dmSyncInterval = null;
            }
          } else {
            throw msgError;
          }
        }
      } catch (error) {
        console.error("Error syncing DMs:", error);
      }
    }
    /**
     * Track user activity for smart auto-check
     */
    trackUserActivity() {
      const updateActivity = () => {
        this.lastUserActivity = Date.now();
      };
      document.addEventListener("mousemove", updateActivity);
      document.addEventListener("keydown", updateActivity);
      document.addEventListener("scroll", updateActivity);
      document.addEventListener("click", updateActivity);
      console.log("\u{1F464} User activity tracking enabled");
    }
    isUserInactive() {
      return Date.now() - this.lastUserActivity > this.INACTIVITY_THRESHOLD;
    }
    /**
     * Nettoie un état corrompu provoqué par d'anciennes fausses détections
     * (ex. 29000 unfollowers issus du compteur d'un autre profil).
     */
    async cleanupCorruptedState() {
      try {
        const ANOMALY_THRESHOLD = 1e3;
        const stored = await accountGet(["unfollowerCount", "unfollowerDetected", "lastFollowerCount", "followerDatabase"]);
        let cleaned = false;
        const dbCount = stored.followerDatabase?.isInitialized ? Object.keys(stored.followerDatabase.followers || {}).length : 0;
        const impossiblePending = typeof stored.unfollowerCount === "number" && stored.unfollowerCount > 0 && dbCount > 0 && stored.unfollowerCount > dbCount;
        if (typeof stored.unfollowerCount === "number" && stored.unfollowerCount > ANOMALY_THRESHOLD || impossiblePending) {
          await accountRemove(["unfollowerDetected", "unfollowerCount", "unfollowerDetectedAt"]);
          console.warn(`\u{1F9F9} Fausse d\xE9tection nettoy\xE9e: ${stored.unfollowerCount} unfollowers (base=${dbCount})`);
          cleaned = true;
        }
        if (typeof stored.lastFollowerCount === "number" && stored.lastFollowerCount > ANOMALY_THRESHOLD) {
          await accountRemove("lastFollowerCount");
          console.warn(`\u{1F9F9} lastFollowerCount corrompu (${stored.lastFollowerCount}) r\xE9initialis\xE9`);
          cleaned = true;
        }
        if (cleaned) {
          try {
            await chrome.runtime.sendMessage({ type: "UPDATE_BADGE", text: "" });
          } catch (e) {
          }
        }
      } catch (error) {
        console.error("Error cleaning corrupted state:", error);
      }
    }
    async startFollowerCountMonitoring() {
      this.autoCheckInterval = setInterval(async () => {
        if (!chrome.runtime?.id) {
          if (this.autoCheckInterval) clearInterval(this.autoCheckInterval);
          return;
        }
        await this.detectAccountSwitch();
        this.checkFollowerCountChange();
        this.resumePendingNewFollowerScan();
      }, 3e4);
      await this.detectAccountSwitch();
      await this.checkFollowerCountChange();
      await this.resumePendingNewFollowerScan();
      console.log("\u{1F465} Automatic follower monitoring started");
    }
    /**
     * Détecte une bascule de compte Instagram (ds_user_id) survenue DANS le même
     * onglet, sans rechargement de page. Sans cela, `this.followerDatabase` (chargé
     * une seule fois à l'init) resterait celui du compte précédent et les données
     * des deux comptes se mélangeraient (ex. 214 + 3 = 217).
     *
     * On réaligne le namespace de stockage ET on recharge la base en mémoire depuis
     * le namespace du NOUVEAU compte — en la vidant d'abord, pour ne jamais
     * conserver celle de l'ancien compte si le nouveau n'a pas encore de base.
     */
    async detectAccountSwitch() {
      try {
        const current = this.getLoggedInUserId();
        if (!current) return;
        const active = await getActiveDsUserId();
        if (!active || active === current) return;
        console.log(`\u{1F504} Bascule de compte Instagram d\xE9tect\xE9e: ${active} \u2192 ${current} \u2014 r\xE9alignement`);
        await ensurePrimaryAccount(current);
        await setActiveDsUserId(current);
        chrome.runtime.sendMessage({ type: "SET_ACTIVE_ACCOUNT", dsUserId: current }).catch(() => {
        });
        this.currentUsername = null;
        this.followersCache = /* @__PURE__ */ new Set();
        this.followerDatabase = {
          followers: {},
          lastScanDate: "",
          totalCount: 0,
          firstFollowerId: "",
          isInitialized: false
        };
        await this.loadFollowerDatabase();
        await this.loadFollowersCache();
      } catch (error) {
        console.error("Error detecting account switch:", error);
      }
    }
    /**
     * Reprend une collecte de nouveau follower mise en attente : si un nouveau
     * follower a été détecté alors qu'on n'était pas sur le profil (modale
     * impossible à ouvrir), on relance la collecte dès qu'on arrive sur le profil.
     */
    async resumePendingNewFollowerScan() {
      try {
        if (this.isScanning || !this.isOnOwnProfile()) return;
        const stored = await accountGet("pendingNewFollowerScan");
        const pendingRaw = stored.pendingNewFollowerScan;
        if (!pendingRaw || pendingRaw <= 0) return;
        let pending = pendingRaw;
        const realCount = await this.fetchRealFollowerCount();
        if (realCount !== null && pendingRaw > realCount) {
          console.warn(`\u26A0\uFE0F pendingNewFollowerScan p\xE9rim\xE9 (${pendingRaw} > ${realCount} followers r\xE9els) \u2014 corrig\xE9`);
          if (realCount <= 0) {
            await accountRemove("pendingNewFollowerScan");
            return;
          }
          pending = realCount;
        }
        console.log(`\u{1F501} Reprise de la collecte de ${pending} nouveau(x) follower(s) (sur le profil)`);
        await this.scanNewFollowersIntelligent(pending);
      } catch (error) {
        console.error("Error resuming pending new follower scan:", error);
      }
    }
    /**
     * Récupère l'ID du compte CONNECTÉ depuis le cookie ds_user_id.
     * Ce cookie est lisible par le content script et identifie l'utilisateur
     * connecté, indépendamment du profil actuellement affiché.
     */
    getLoggedInUserId() {
      const match = document.cookie.match(/ds_user_id=(\d+)/);
      return match ? match[1] : null;
    }
    /**
     * MULTI-COMPTE : identifie le compte Insta connecté (ds_user_id) et bascule le
     * namespace de stockage. Migre les anciennes clés globales vers ce compte au
     * premier passage, puis propose la liaison si le compte n'est pas encore lié.
     */
    async resolveActiveAccount() {
      try {
        const dsUserId = this.getLoggedInUserId();
        if (!dsUserId) return;
        const isPrimary = await ensurePrimaryAccount(dsUserId);
        const previousActive = await getActiveDsUserId();
        if (!isPrimary) {
          await migrateLegacyKeysToAccount(dsUserId, this.currentUsername || void 0);
        }
        if (previousActive !== dsUserId) {
          await setActiveDsUserId(dsUserId);
          console.log(
            `\u{1F500} Compte Insta actif: ${dsUserId} (@${this.currentUsername})${isPrimary ? " [principal]" : ""}`
          );
          chrome.runtime.sendMessage({ type: "SET_ACTIVE_ACCOUNT", dsUserId }).catch(() => {
          });
        }
        if (!isPrimary) {
          await this.healContaminatedAccount();
        }
        if (this.isOnOwnProfile() && !await isAccountLinked(dsUserId)) {
          if (isPrimary) {
            autoLinkPrimaryAccount({
              dsUserId,
              igUsername: this.currentUsername || ""
            });
          } else {
            maybePromptAccountLink({
              dsUserId,
              igUsername: this.currentUsername || ""
            });
          }
        }
      } catch (error) {
        console.error("Error resolving active account:", error);
      }
    }
    /**
     * Réinitialise le namespace du compte actif si ses données appartiennent
     * manifestement à un autre compte (username stocké ≠ username courant). Corrige
     * la contamination provoquée par l'ancienne migration legacy.
     */
    async healContaminatedAccount() {
      try {
        if (!this.currentUsername) return;
        const stored = await accountGet("userInfo");
        const storedUsername = stored.userInfo?.username;
        if (storedUsername && storedUsername.toLowerCase() !== this.currentUsername.toLowerCase()) {
          console.warn(
            `\u{1F9F9} Donn\xE9es contamin\xE9es pour @${this.currentUsername} (trouv\xE9 @${storedUsername}) \u2014 r\xE9initialisation de la base de ce compte`
          );
          await accountSet({
            followerDatabase: {
              followers: {},
              isInitialized: false,
              totalCount: 0,
              firstFollowerId: "",
              lastScanDate: ""
            },
            sessionStats: { followers: 0, unfollowers: 0, potentialBlockers: 0, engagements: 0 },
            userInfo: { ...stored.userInfo, username: this.currentUsername }
          });
          await accountRemove([
            "lastFollowerCount",
            "lastFollowerCountSource",
            "lastFollowerCountAt",
            "unfollowerDetected",
            "unfollowerCount",
            "unfollowerDetectedAt",
            "followersCache",
            "lastNotificationCheck",
            "pendingNewFollowerScan"
          ]);
        }
      } catch (error) {
        console.error("Error healing contaminated account:", error);
      }
    }
    async fetchRealFollowerCount() {
      try {
        const userId = this.getLoggedInUserId();
        if (userId) {
          const response = await fetch(`https://www.instagram.com/api/v1/users/${userId}/info/`, {
            method: "GET",
            credentials: "include",
            headers: {
              "x-ig-app-id": "936619743392459"
            }
          });
          if (response.ok) {
            const data = await response.json();
            const user = data?.user;
            const count = user?.follower_count;
            if (typeof count === "number") {
              if (user?.username && user.username !== this.currentUsername) {
                this.currentUsername = user.username;
                this.collector.setTrackedUsername(user.username);
              }
              return count;
            }
          } else {
            console.log(`\u26A0\uFE0F [API] users/${userId}/info a r\xE9pondu ${response.status}`);
          }
        }
      } catch (error) {
        console.log("\u26A0\uFE0F [API] Echec r\xE9cup\xE9ration via ds_user_id:", error);
      }
      try {
        if (!this.currentUsername) return null;
        const url = `https://www.instagram.com/api/v1/users/web_profile_info/?username=${encodeURIComponent(this.currentUsername)}`;
        const response = await fetch(url, {
          method: "GET",
          credentials: "include",
          headers: {
            "x-ig-app-id": "936619743392459",
            "x-requested-with": "XMLHttpRequest"
          }
        });
        if (!response.ok) {
          console.log(`\u26A0\uFE0F [API] web_profile_info a r\xE9pondu ${response.status}`);
          return null;
        }
        const data = await response.json();
        const count = data?.data?.user?.edge_followed_by?.count;
        return typeof count === "number" ? count : null;
      } catch (error) {
        console.log("\u26A0\uFE0F [API] Impossible de r\xE9cup\xE9rer le nombre de followers via l'API:", error);
        return null;
      }
    }
    /**
     * Récupère les followers les plus récents via l'API Instagram (la même qui
     * alimente la modale). Renvoie les usernames du plus récent au plus ancien.
     * Fonctionne depuis N'IMPORTE QUELLE page (pas besoin du profil ni de la
     * modale) → permet de collecter l'ID d'un nouveau follower partout.
     */
    async fetchRecentFollowersFromAPI(limit) {
      try {
        const userId = this.getLoggedInUserId();
        if (!userId) return null;
        const safeCount = Math.min(Math.max(limit, 1), 50);
        const url = `https://www.instagram.com/api/v1/friendships/${userId}/followers/?count=${safeCount}`;
        const response = await fetch(url, {
          method: "GET",
          credentials: "include",
          headers: {
            "x-ig-app-id": "936619743392459",
            "x-requested-with": "XMLHttpRequest"
          }
        });
        if (!response.ok) {
          console.log(`\u26A0\uFE0F [API] friendships/followers a r\xE9pondu ${response.status}`);
          return null;
        }
        const data = await response.json();
        const users = data?.users;
        if (!Array.isArray(users)) return null;
        return users.map((u) => u?.username).filter((name) => typeof name === "string" && name.length > 0);
      } catch (error) {
        console.log("\u26A0\uFE0F [API] Echec r\xE9cup\xE9ration des followers r\xE9cents:", error);
        return null;
      }
    }
    /**
     * Lit le nombre de followers depuis le DOM (fallback si l'API échoue).
     */
    getFollowerCountFromDOM() {
      const path = window.location.pathname;
      if (path !== `/${this.currentUsername}` && path !== `/${this.currentUsername}/`) {
        return null;
      }
      let followerCountElement = document.querySelector('a[href*="/followers/"] span') || document.querySelector('a[href$="/followers/"] span');
      if (!followerCountElement) {
        const spans = Array.from(document.querySelectorAll("span"));
        followerCountElement = spans.find((el) => {
          const text = el.textContent?.trim() || "";
          return text.includes("follower") && /\d/.test(text);
        });
      }
      if (!followerCountElement) {
        const headerLinks = Array.from(document.querySelectorAll("header section ul li a"));
        for (const link of headerLinks) {
          if (link.getAttribute("href")?.includes("followers")) {
            followerCountElement = link.querySelector("span");
            break;
          }
        }
      }
      if (!followerCountElement) {
        return null;
      }
      const titleAttr = followerCountElement.getAttribute("title") || followerCountElement.closest("[title]")?.getAttribute("title") || "";
      const countText = titleAttr.trim() || followerCountElement.textContent?.trim() || "0";
      return this.parseFollowerCount(countText);
    }
    async checkFollowerCountChange() {
      try {
        if (!chrome.runtime?.id) {
          console.log("\u26A0\uFE0F Extension context invalidated, stopping monitoring");
          if (this.autoCheckInterval) {
            clearInterval(this.autoCheckInterval);
          }
          return;
        }
        if (this.isScanning) {
          return;
        }
        let count = this.getFollowerCountFromDOM();
        let source = "DOM";
        if (count === null) {
          count = await this.fetchRealFollowerCount();
          source = "API";
        }
        if (count === null) {
          console.log("\u26A0\uFE0F Impossible de d\xE9terminer le nombre de followers (API + DOM \xE9chou\xE9s)");
          return;
        }
        const stored = await accountGet(["lastFollowerCount", "lastFollowerCountSource", "lastFollowerCountAt", "lastFollowerCountOwner"]);
        const lastCount = stored.lastFollowerCount || 0;
        const lastSource = stored.lastFollowerCountSource || null;
        const lastCountAt = stored.lastFollowerCountAt || 0;
        const lastOwner = stored.lastFollowerCountOwner || null;
        const ownerId = this.getLoggedInUserId();
        const ownerStamp = ownerId ? { lastFollowerCountOwner: ownerId } : {};
        console.log(`\u{1F50D} [${source}] Checking: current=${count}, last=${lastCount}, diff=${count - lastCount}`);
        if (lastCount !== 0 && ownerId && lastOwner !== ownerId) {
          if (lastOwner) {
            console.warn(`\u26A0\uFE0F [${source}] R\xE9f\xE9rence d'un autre compte ignor\xE9e (owner=${lastOwner} \u2260 connect\xE9=${ownerId}). Resynchronisation sans notification.`);
          } else {
            console.log(`\u2139\uFE0F [${source}] R\xE9f\xE9rence non estampill\xE9e \u2014 attribu\xE9e au compte ${ownerId} sans notification.`);
          }
          await accountSet({ lastFollowerCount: count, lastFollowerCountSource: source, lastFollowerCountAt: Date.now(), ...ownerStamp });
          this.lastFollowerCount = count;
          if (this.followerDatabase.isInitialized) {
            this.followerDatabase.totalCount = count;
            await this.saveFollowerDatabase();
            await this.updateFollowerCountToBackend(count);
          }
          return;
        }
        if (lastCount === 0) {
          await accountSet({ lastFollowerCount: count, lastFollowerCountSource: source, lastFollowerCountAt: Date.now(), ...ownerStamp });
          this.lastFollowerCount = count;
          console.log(`\u{1F4CA} [${source}] Initial follower count: ${count}`);
          if (this.followerDatabase.isInitialized) {
            this.followerDatabase.totalCount = count;
            await this.saveFollowerDatabase();
            console.log(`\u{1F4BE} [${source}] Updated totalCount to ${count}`);
            await this.updateFollowerCountToBackend(count);
          }
          return;
        }
        if (count !== lastCount) {
          const diff = count - lastCount;
          const CACHE_DIVERGENCE = 5;
          const ANTI_FLAP_WINDOW_MS = 10 * 60 * 1e3;
          const withinWindow = Date.now() - lastCountAt < ANTI_FLAP_WINDOW_MS;
          if (source === "API" && lastSource === "DOM" && Math.abs(diff) <= CACHE_DIVERGENCE && withinWindow) {
            console.log(`\u23ED\uFE0F [API] Divergence ignor\xE9e (API=${count} vs dernier DOM=${lastCount}) \u2014 cache API probablement en retard`);
            return;
          }
          const ANOMALY_THRESHOLD = 1e3;
          if (Math.abs(diff) > ANOMALY_THRESHOLD) {
            console.warn(`\u26A0\uFE0F [${source}] \xC9cart anormal d\xE9tect\xE9 (${lastCount} \u2192 ${count}, diff=${diff}). Resynchronisation sans notification.`);
            await accountSet({ lastFollowerCount: count, lastFollowerCountSource: source, lastFollowerCountAt: Date.now(), ...ownerStamp });
            this.lastFollowerCount = count;
            if (this.followerDatabase.isInitialized) {
              this.followerDatabase.totalCount = count;
              await this.saveFollowerDatabase();
              await this.updateFollowerCountToBackend(count);
            }
            return;
          }
          console.log(`\u{1F514} [${source}] Follower count changed: ${lastCount} \u2192 ${count} (${diff > 0 ? "+" : ""}${diff})`);
          await accountSet({ lastFollowerCount: count, lastFollowerCountSource: source, lastFollowerCountAt: Date.now(), ...ownerStamp });
          this.lastFollowerCount = count;
          if (this.followerDatabase.isInitialized) {
            this.followerDatabase.totalCount = count;
            await this.saveFollowerDatabase();
            await this.updateFollowerCountToBackend(count);
          }
          if (diff > 0) {
            await this.handleNewFollowers(diff);
          } else {
            await this.handleUnfollowers(Math.abs(diff));
          }
        } else {
          await this.checkForHiddenUnfollowers();
        }
      } catch (error) {
        console.error("Error checking follower count:", error);
      }
    }
    parseFollowerCount(text) {
      const cleaned = text.replace(/,/g, "").replace(/\s/g, "");
      if (cleaned.includes("K")) {
        return Math.floor(parseFloat(cleaned) * 1e3);
      } else if (cleaned.includes("M")) {
        return Math.floor(parseFloat(cleaned) * 1e6);
      }
      return parseInt(cleaned) || 0;
    }
    /**
     * Handle new followers (scan intelligent avec estimation)
     */
    async handleNewFollowers(diff) {
      console.log(`\u{1F195} ${diff} new follower(s) detected`);
      try {
        await chrome.runtime.sendMessage({
          type: "FOLLOWER_CHANGE_DETECTED",
          count: diff,
          changeType: "follower"
        });
      } catch (error) {
        console.error("Error sending notification:", error);
      }
      try {
        await this.updateBadge(`+${diff}`);
      } catch (error) {
        console.error("Error updating badge:", error);
      }
      setTimeout(() => {
        this.scanNewFollowersIntelligent(diff);
      }, 1500);
    }
    /**
     * Handle unfollowers - Envoie une notification pour analyse manuelle
     */
    async handleUnfollowers(diff) {
      console.log(`\u{1F6AB} ${diff} unfollower(s) detected`);
      try {
        await chrome.runtime.sendMessage({
          type: "FOLLOWER_CHANGE_DETECTED",
          count: diff,
          changeType: "unfollower"
        });
        await accountSet({
          unfollowerDetected: true,
          unfollowerCount: diff,
          unfollowerDetectedAt: Date.now()
        });
        await this.updateBadge(`-${diff}`);
        console.log(`\u{1F4E2} Unfollower notification sent to popup`);
      } catch (error) {
        console.error("Error sending notification:", error);
      }
    }
    /**
     * Vérifier les notifications pour détecter les unfollowers cachés
     * Logique : Si nouveaux followers dans notifications mais nombre total n'augmente pas assez → unfollowers cachés
     */
    async checkForHiddenUnfollowers() {
      try {
        return;
        if (localStorage.getItem("unfollowerCheckState")) {
          return;
        }
        const analysisStore = await accountGet("isAnalyzing");
        if (analysisStore.isAnalyzing) {
          return;
        }
        const stored = await accountGet("lastNotificationCheck");
        const lastCheck = stored.lastNotificationCheck || 0;
        const now = Date.now();
        if (now - lastCheck < 5 * 60 * 1e3) {
          return;
        }
        if (this.lastFollowerCount === 0) {
          console.log("\u26A0\uFE0F [HiddenUnfollower] Compteur de followers non charg\xE9, v\xE9rification ignor\xE9e");
          return;
        }
        console.log("\u{1F50D} Checking notifications for hidden unfollowers...");
        const result = await this.notificationChecker.detectHiddenUnfollowers(this.followerDatabase);
        if (result.newFollowersFromNotifications.length > 0) {
          const newFollowersCount = result.newFollowersFromNotifications.length;
          console.log(`\u{1F4E2} Found ${newFollowersCount} new follower(s) in notifications`);
          for (const username of result.newFollowersFromNotifications) {
            if (this.followerDatabase.followers[username]) continue;
            this.followerDatabase.followers[username] = {
              username,
              addedAt: (/* @__PURE__ */ new Date()).toISOString(),
              position: Object.keys(this.followerDatabase.followers).length + 1
            };
            try {
              await chrome.runtime.sendMessage({
                type: "TRACK_FOLLOWER",
                data: {
                  username,
                  metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString(), source: "notifications" }
                }
              });
            } catch (error) {
              console.error(`Error tracking new follower ${username} from notifications:`, error);
            }
          }
          this.followerDatabase.totalCount = Object.keys(this.followerDatabase.followers).length;
          const currentCount = this.lastFollowerCount;
          const previousCount = this.followerDatabase.totalCount - newFollowersCount;
          const expectedCount = previousCount + newFollowersCount;
          console.log(`\u{1F4CA} Previous: ${previousCount}, New followers: ${newFollowersCount}, Expected: ${expectedCount}, Current: ${currentCount}`);
          if (currentCount < expectedCount) {
            const hiddenUnfollowers = expectedCount - currentCount;
            console.log(`\u26A0\uFE0F HIDDEN UNFOLLOWERS DETECTED! Expected ${expectedCount} but got ${currentCount} \u2192 ${hiddenUnfollowers} unfollower(s)`);
            await accountSet({ followerDatabase: this.followerDatabase });
            console.log("\u{1F680} Triggering unfollower analysis due to hidden unfollowers...");
            await this.handleUnfollowers(hiddenUnfollowers);
          } else {
            console.log("\u2705 No hidden unfollowers, just new followers");
            await accountSet({ followerDatabase: this.followerDatabase });
            try {
              await chrome.runtime.sendMessage({
                type: "FOLLOWER_CHANGE_DETECTED",
                count: newFollowersCount,
                changeType: "follower"
              });
              await this.updateBadge(`+${newFollowersCount}`);
            } catch (error) {
              console.error("Error notifying new followers:", error);
            }
          }
        }
        await accountSet({ lastNotificationCheck: now });
      } catch (error) {
        console.error("Error checking for hidden unfollowers:", error);
      }
    }
    /**
     * Lance l'analyse complète des unfollowers (appelé depuis le popup)
     */
    async startUnfollowerAnalysis() {
      if (this.unfollowerDetector.isAnalysisRunning()) {
        console.log("\u23F3 Unfollower analysis already in progress");
        return;
      }
      try {
        console.log("\u{1F3AC} Starting unfollower analysis...");
        this.isScanning = true;
        this.scanOverlay.show("Analyzing unfollowers...");
        const result = await this.unfollowerDetector.analyzeUnfollowers(this.currentUsername);
        this.scanOverlay.showSuccess(
          `Analysis complete!
Unfollows: ${result.unfollowed.length}
Blocks: ${result.blocked.length}
Google check: ${result.notFoundOnInstagram.length}`
        );
        await accountSet({
          unfollowerDetected: false,
          unfollowerCount: 0
        });
        console.log("\u2705 Unfollower analysis completed");
      } catch (error) {
        console.error("Error during unfollower analysis:", error);
        this.scanOverlay.showError("Error while analyzing unfollowers");
      } finally {
        this.isScanning = false;
      }
    }
    /**
     * SCAN INITIAL PROGRESSIF PAR PORTIONS
     */
    /**
     * Ouvre le modal followers de façon ROBUSTE — la même capacité que le scan
     * « basique » (performInitialScan*), factorisée pour que TOUTE fonction ayant
     * besoin du modal puisse l'ouvrir elle-même au lieu de supposer qu'il est déjà
     * ouvert :
     *   1. Si le modal est déjà ouvert → on le renvoie tel quel (aucune navigation).
     *   2. Sinon → on va sur le profil si besoin (le lien followers n'existe que là),
     *      on cherche le lien avec plusieurs stratégies + retries, on clique, puis on
     *      renvoie le modal.
     * Renvoie l'élément modal, ou null si impossible à ouvrir.
     */
    async ensureFollowersModalOpen() {
      let modal = document.querySelector('[role="dialog"]');
      if (modal) {
        console.log("\u2705 Followers modal already open!");
        return modal;
      }
      if (!this.isOnOwnProfile()) {
        console.log(`\u{1F4CD} Navigating to profile: /${this.currentUsername}`);
        window.location.href = `/${this.currentUsername}`;
        await new Promise((resolve) => setTimeout(resolve, 3e3));
      }
      console.log("\u{1F50D} Searching for followers link...");
      let followersLink = null;
      let attempts = 0;
      const maxAttempts = 10;
      while (!followersLink && attempts < maxAttempts) {
        followersLink = document.querySelector(`a[href="/${this.currentUsername}/followers/"]`);
        if (!followersLink) {
          followersLink = document.querySelector(`a[href*="/followers/"]`);
        }
        if (!followersLink) {
          const links = Array.from(document.querySelectorAll("a"));
          followersLink = links.find((link) => link.href.includes("/followers/"));
        }
        if (!followersLink) {
          attempts++;
          console.log(`\u23F3 Attempt ${attempts}/${maxAttempts} - Waiting for page to load...`);
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
      }
      if (!followersLink) {
        console.error("\u274C Followers link not found after multiple attempts");
        return null;
      }
      console.log("\u2705 Followers link found:", followersLink.href);
      followersLink.click();
      await new Promise((resolve) => setTimeout(resolve, 2e3));
      modal = document.querySelector('[role="dialog"]');
      if (!modal) {
        console.log("\u274C Followers modal not found after click");
        return null;
      }
      console.log("\u2705 Modal opened successfully");
      return modal;
    }
    async performInitialScan() {
      if (this.isScanning) {
        console.log("\u23F3 Scan already in progress");
        return;
      }
      this.isScanning = true;
      console.log("\u{1F3AC} Starting initial follower scan...");
      await this.updateBadge("\u23F3");
      this.scanOverlay.show("Initial scan in progress...");
      try {
        if (!this.isOnOwnProfile()) {
          window.location.href = `/${this.currentUsername}`;
          await new Promise((resolve) => setTimeout(resolve, 2e3));
        }
        let modal = document.querySelector('[role="dialog"]');
        if (!modal) {
          console.log("\u23F3 Modal not open, trying to open it...");
          this.scanOverlay.updateProgress(0, 100, "Opening the followers modal...");
          await new Promise((resolve) => setTimeout(resolve, 2e3));
          let followersLink = null;
          let attempts = 0;
          const maxAttempts = 10;
          while (!followersLink && attempts < maxAttempts) {
            followersLink = document.querySelector(`a[href="/${this.currentUsername}/followers/"]`);
            if (!followersLink) {
              followersLink = document.querySelector(`a[href*="/followers/"]`);
            }
            if (!followersLink) {
              const links = Array.from(document.querySelectorAll("a"));
              followersLink = links.find((link) => link.href.includes("/followers/"));
            }
            if (!followersLink) {
              attempts++;
              await new Promise((resolve) => setTimeout(resolve, 500));
            }
          }
          if (!followersLink) {
            console.error("\u274C Followers link not found");
            this.scanOverlay.showError("Please open the followers modal manually and restart the scan");
            this.isScanning = false;
            return;
          }
          console.log("\u2705 Followers link found:", followersLink.href);
          followersLink.click();
          await new Promise((resolve) => setTimeout(resolve, 2e3));
          modal = document.querySelector('[role="dialog"]');
          if (!modal) {
            console.log("\u274C Followers modal not found after click");
            this.scanOverlay.showError("Please open the followers modal manually and restart the scan");
            this.isScanning = false;
            return;
          }
        } else {
          console.log("\u2705 Followers modal already open!");
        }
        let scrollContainer = null;
        const divs = modal.querySelectorAll("div");
        for (const div of Array.from(divs)) {
          const style2 = window.getComputedStyle(div);
          if (style2.overflow === "auto" || style2.overflow === "scroll" || style2.overflowY === "auto" || style2.overflowY === "scroll") {
            scrollContainer = div;
            console.log("\u2705 Found scrollable div with overflow");
            break;
          }
        }
        if (!scrollContainer) {
          scrollContainer = modal;
          console.log("\u26A0\uFE0F Using modal itself as scroll container");
        }
        console.log(`\u{1F4CF} Scroll container: scrollHeight=${scrollContainer.scrollHeight}, clientHeight=${scrollContainer.clientHeight}`);
        let totalFollowers = 0;
        const modalTitle = modal.querySelector('h1, div[role="dialog"] span');
        if (modalTitle) {
          const titleText = modalTitle.textContent || "";
          console.log(`\u{1F4CA} Modal title: "${titleText}"`);
          const match = titleText.match(/(\d+[\d,\.]*[KkMm]?)\s*(follower|abonné)/i);
          if (match) {
            totalFollowers = this.parseFollowerCount(match[1]);
            console.log(`\u2705 Parsed ${totalFollowers} followers from modal title`);
          }
        }
        if (totalFollowers === 0) {
          const profileFollowerLink = document.querySelector('a[href*="/followers/"]');
          if (profileFollowerLink) {
            const linkText = profileFollowerLink.textContent || "";
            console.log(`\u{1F4CA} Profile link text: "${linkText}"`);
            const match = linkText.match(/(\d+[\d,\.]*[KkMm]?)\s*(follower|abonné)/i);
            if (match) {
              totalFollowers = this.parseFollowerCount(match[1]);
              console.log(`\u2705 Parsed ${totalFollowers} followers from profile link`);
            }
          }
        }
        if (totalFollowers === 0 && this.lastFollowerCount > 0) {
          totalFollowers = this.lastFollowerCount;
          console.log(`\u2705 Using cached count: ${totalFollowers}`);
        }
        if (totalFollowers === 0) {
          totalFollowers = 100;
          console.log(`\u26A0\uFE0F Using fallback count: ${totalFollowers}`);
        }
        const portionSize = 100;
        const maxPortions = totalFollowers < 100 ? 1 : totalFollowers < 500 ? 5 : 10;
        console.log(`\u{1F4CA} Total followers: ${totalFollowers}, scanning in ${maxPortions} portions`);
        let scannedFollowers = /* @__PURE__ */ new Set();
        let lastCount = 0;
        let stableCount = 0;
        const maxStableChecks = 5;
        console.log("\u{1F504} Starting API-based follower collection...");
        let apiFollowers = [];
        this.apiInterceptor.start((followers) => {
          apiFollowers = followers;
          console.log(`\u{1F4E1} API intercepted ${followers.length} followers`);
        });
        const collectVisibleFollowers = () => {
          const links = modal.querySelectorAll('a[href^="/"]');
          for (const link of Array.from(links)) {
            const href = link.getAttribute("href");
            if (href) {
              const usernameMatch = href.match(/^\/([a-zA-Z0-9._]+)\/?(\?.*)?$/);
              if (usernameMatch) {
                const username = usernameMatch[1];
                const systemPages = ["explore", "reels", "direct", "p", "stories", "tv", "accounts"];
                if (!systemPages.includes(username) && !scannedFollowers.has(username)) {
                  scannedFollowers.add(username);
                }
              }
            }
          }
        };
        let baseScrollPx = 9;
        let baseDelayMs = 58;
        if (totalFollowers > 1e3) {
          baseScrollPx = 50;
          baseDelayMs = 100;
        } else if (totalFollowers > 500) {
          baseScrollPx = 25;
          baseDelayMs = 80;
        }
        console.log(`\u{1F680} Starting adaptive scroll (${baseScrollPx}px/${baseDelayMs}ms for ${totalFollowers} followers)...`);
        while (stableCount < maxStableChecks) {
          collectVisibleFollowers();
          const currentCount = scannedFollowers.size;
          const newFound = currentCount - lastCount;
          if (currentCount % 50 === 0 && currentCount !== lastCount) {
            console.log(`\u{1F4CA} Followers: ${currentCount}/${totalFollowers}`);
            await this.updateScanProgress(currentCount, totalFollowers);
            this.scanOverlay.updateProgress(currentCount, totalFollowers, `${currentCount}/${totalFollowers} followers`);
          }
          if (currentCount >= totalFollowers) {
            console.log("\u2705 All expected followers loaded!");
            break;
          }
          if (currentCount === lastCount) {
            stableCount++;
          } else {
            stableCount = 0;
            lastCount = currentCount;
          }
          const scrollVariation = baseScrollPx * (0.7 + Math.random() * 0.6);
          scrollContainer.scrollTop += Math.round(scrollVariation);
          const delayVariation = baseDelayMs * (0.6 + Math.random() * 0.8);
          await new Promise((resolve) => setTimeout(resolve, Math.round(delayVariation)));
          if (Math.random() < 0.05) {
            const pauseDuration = 200 + Math.random() * 500;
            await new Promise((resolve) => setTimeout(resolve, pauseDuration));
          }
        }
        console.log(`\u2705 Scroll complete: ${scannedFollowers.size} followers collected from DOM`);
        this.apiInterceptor.stop();
        apiFollowers.forEach((username) => scannedFollowers.add(username));
        console.log(`\u2705 Initial scan complete: ${scannedFollowers.size} followers loaded (DOM + API)`);
        this.followerDatabase.followers = {};
        const followersArray = Array.from(scannedFollowers);
        const firstFollower = followersArray[0];
        followersArray.forEach((username, index) => {
          this.followerDatabase.followers[username] = {
            username,
            addedAt: (/* @__PURE__ */ new Date()).toISOString(),
            position: index
          };
        });
        this.followerDatabase.totalCount = scannedFollowers.size;
        this.followerDatabase.firstFollowerId = firstFollower;
        this.followerDatabase.lastScanDate = (/* @__PURE__ */ new Date()).toISOString();
        this.followerDatabase.isInitialized = true;
        await this.saveFollowerDatabase();
        const closeButton = modal.querySelector('button[aria-label="Close"], button[aria-label="Fermer"]');
        if (closeButton) {
          closeButton.click();
        }
        await this.updateBadge("\u2705");
        this.scanOverlay.showSuccess(`${scannedFollowers.size} followers scanned!`);
        console.log("\u2705 Initial scan completed successfully");
      } catch (error) {
        console.error("Error during initial scan:", error);
        this.scanOverlay.showError("Error during scan");
      } finally {
        this.isScanning = false;
        setTimeout(() => this.updateBadge(""), 3e3);
      }
    }
    /**
     * SCAN INITIAL AVEC SMART SCROLLER (Nouvelle version optimisée)
     * Utilise InstagramModalScroller et FollowerExtractor
     */
    async performInitialScanWithSmartScroller() {
      if (this.isScanning) {
        console.log("\u23F3 Scan already in progress");
        return;
      }
      this.isScanning = true;
      console.log("\u{1F3AC} Starting initial scan with Smart Scroller...");
      await this.updateBadge("\u23F3");
      this.scanOverlay.show("Smart scan in progress...");
      try {
        let modal = document.querySelector('[role="dialog"]');
        if (modal) {
          console.log("\u2705 Followers modal already open!");
          console.log("\u23F3 Waiting for modal content to load...");
          await new Promise((resolve) => setTimeout(resolve, 1e3));
        } else {
          if (!this.isOnOwnProfile()) {
            console.log(`\u{1F4CD} Navigating to profile: /${this.currentUsername}`);
            window.location.href = `/${this.currentUsername}`;
            await new Promise((resolve) => setTimeout(resolve, 3e3));
          }
          console.log("\u{1F50D} Searching for followers link...");
          let followersLink = null;
          let attempts = 0;
          const maxAttempts = 10;
          while (!followersLink && attempts < maxAttempts) {
            followersLink = document.querySelector(`a[href="/${this.currentUsername}/followers/"]`);
            if (!followersLink) {
              followersLink = document.querySelector(`a[href*="/followers/"]`);
            }
            if (!followersLink) {
              const links = Array.from(document.querySelectorAll("a"));
              followersLink = links.find((link) => link.href.includes("/followers/"));
            }
            if (!followersLink) {
              attempts++;
              console.log(`\u23F3 Attempt ${attempts}/${maxAttempts} - Waiting for page to load...`);
              await new Promise((resolve) => setTimeout(resolve, 500));
            }
          }
          if (!followersLink) {
            this.scanOverlay.showError("Please open the followers modal manually and restart the scan");
            throw new Error("Followers link not found after multiple attempts. Please open the followers modal manually.");
          }
          console.log("\u2705 Followers link found:", followersLink.href);
          followersLink.click();
          await new Promise((resolve) => setTimeout(resolve, 2e3));
          modal = document.querySelector('[role="dialog"]');
          if (!modal) {
            throw new Error("Followers modal not found after clicking link");
          }
          console.log("\u2705 Modal opened successfully");
        }
        const extractor = new FollowerExtractor();
        const scroller = new InstagramModalScroller({
          maxScrollAttempts: 6,
          // 6 tentatives avant d'arrêter (équilibre entre patience et discrétion)
          scrollDelay: 400,
          // 400ms entre chaque scroll (plus lent = plus sûr)
          waitForLoadTimeout: 8e3,
          // 8 secondes pour attendre le chargement (Instagram peut être lent)
          onProgress: (progress) => {
            console.log(`\u{1F4CA} Progress: ${progress.totalFollowers} followers scann\xE9s`);
            extractor.extractAllVisible();
            this.scanOverlay.updateProgress(
              progress.totalFollowers,
              progress.totalFollowers + 100,
              // Estimation
              `${progress.totalFollowers} followers scann\xE9s`
            );
          }
        });
        console.log("\u{1F680} Starting intelligent scroll to capture ALL followers...");
        const allUsernames = await scroller.scrollToEnd();
        console.log(`\u2705 Scroll complete: ${allUsernames.length} followers found`);
        console.log(`\uFFFD First 10 followers:`, allUsernames.slice(0, 10));
        if (allUsernames.length === 0) {
          throw new Error("No followers found during scroll. Please try again.");
        }
        this.followerDatabase.followers = {};
        const firstFollower = allUsernames[0];
        console.log(`\u{1F4BE} Saving ${allUsernames.length} followers to database...`);
        allUsernames.forEach((username, index) => {
          this.followerDatabase.followers[username] = {
            username,
            avatarUrl: "",
            // Pas d'avatar pour l'instant (extraction simple)
            addedAt: (/* @__PURE__ */ new Date()).toISOString(),
            position: index
          };
        });
        this.followerDatabase.totalCount = allUsernames.length;
        this.followerDatabase.firstFollowerId = firstFollower;
        this.followerDatabase.lastScanDate = (/* @__PURE__ */ new Date()).toISOString();
        this.followerDatabase.isInitialized = true;
        await this.saveFollowerDatabase();
        console.log(`\u2705 Database saved: ${allUsernames.length} followers`);
        scroller.closeModal();
        await this.updateBadge("\u2705");
        this.scanOverlay.showSuccess(
          `${allUsernames.length} followers scann\xE9s avec succ\xE8s !`
        );
        console.log("\u2705 Smart scan completed successfully");
      } catch (error) {
        console.error("Error during smart scan:", error);
        this.scanOverlay.showError(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
      } finally {
        this.isScanning = false;
        setTimeout(() => this.updateBadge(""), 3e3);
      }
    }
    /**
     * Réconcilie le total de la base après l'ajout de nouveaux followers.
     *
     * Le compteur AUTORITAIRE est le nombre réel affiché par Instagram
     * (this.lastFollowerCount), PAS la taille de la base. L'API/la modale des
     * followers « récents » révèle les nouveaux arrivants mais pas ceux qui sont
     * partis : si, après ajout, la base contient PLUS d'entrées que le compteur
     * réel, la différence = des unfollowers cachés. Ex. observé : 6 nouveaux
     * collectés mais hausse nette de seulement +2 (213→215) ⇒ la base monte à 220
     * alors que le réel est 215 ⇒ 5 départs cachés. On cale alors totalCount sur le
     * réel et on signale ces unfollowers pour l'analyse manuelle.
     *
     * Renvoie le nombre d'unfollowers cachés détectés (0 si aucun).
     */
    async reconcileTotalAfterNewFollowers() {
      const dbSize = Object.keys(this.followerDatabase.followers).length;
      const realCount = this.lastFollowerCount > 0 ? this.lastFollowerCount : dbSize;
      this.followerDatabase.totalCount = realCount;
      await this.saveFollowerDatabase();
      const hidden = dbSize - realCount;
      if (hidden > 0) {
        console.warn(
          `\u26A0\uFE0F Incoh\xE9rence: base=${dbSize} > compteur r\xE9el=${realCount} \u2192 ${hidden} unfollower(s) cach\xE9(s). totalCount cal\xE9 sur ${realCount}, d\xE9tection d'unfollowers signal\xE9e.`
        );
        await this.handleUnfollowers(hidden);
        return hidden;
      }
      return 0;
    }
    /**
     * SCAN INTELLIGENT NOUVEAUX FOLLOWERS (Estimation)
     */
    async scanNewFollowersIntelligent(expectedNew) {
      if (this.isScanning) return;
      this.isScanning = true;
      console.log(`\u{1F50D} Starting smart scan for ${expectedNew} new followers...`);
      this.scanOverlay.show(`Detecting ${expectedNew} new follower(s)...`);
      try {
        const apiFollowers = await this.fetchRecentFollowersFromAPI(expectedNew + 10);
        if (apiFollowers && apiFollowers.length > 0) {
          const newFromApi = apiFollowers.filter((u) => !this.followerDatabase.followers[u]);
          console.log(`\u{1F195} [API] ${newFromApi.length} nouveau(x) follower(s) collect\xE9(s):`, newFromApi);
          for (const username of newFromApi) {
            this.followerDatabase.followers[username] = {
              username,
              addedAt: (/* @__PURE__ */ new Date()).toISOString()
            };
            await chrome.runtime.sendMessage({
              type: "TRACK_FOLLOWER",
              data: { username, metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString(), source: "api" } }
            });
          }
          if (newFromApi.length > 0) {
            this.followerDatabase.firstFollowerId = apiFollowers[0];
            const hidden = await this.reconcileTotalAfterNewFollowers();
            this.scanOverlay.showSuccess(
              hidden > 0 ? `${newFromApi.length} new \xB7 ${hidden} hidden unfollower(s) detected` : `${newFromApi.length} new follower(s) collected!`
            );
          } else {
            const hidden = await this.reconcileTotalAfterNewFollowers();
            if (hidden > 0) {
              this.scanOverlay.showSuccess(`${hidden} hidden unfollower(s) detected`);
            } else {
              this.scanOverlay.hide();
            }
          }
          await accountRemove("pendingNewFollowerScan");
          this.isScanning = false;
          await this.updateBadge("");
          return;
        }
        console.log("\u2139\uFE0F API followers indisponible, repli sur la modale...");
        let modal = document.querySelector('[role="dialog"]');
        if (!modal) {
          let followersLink = null;
          let attempts = 0;
          const maxAttempts = 6;
          while (!followersLink && attempts < maxAttempts) {
            followersLink = document.querySelector(`a[href="/${this.currentUsername}/followers/"]`);
            if (!followersLink) {
              followersLink = document.querySelector('a[href*="/followers/"]');
            }
            if (!followersLink) {
              const links2 = Array.from(document.querySelectorAll("a"));
              followersLink = links2.find((link) => link.href.includes("/followers/"));
            }
            if (!followersLink) {
              attempts++;
              await new Promise((resolve) => setTimeout(resolve, 500));
            }
          }
          if (!followersLink) {
            console.log("\u26A0\uFE0F Pas sur le profil, collecte du nouveau follower report\xE9e");
            await accountSet({ pendingNewFollowerScan: expectedNew });
            this.scanOverlay.hide();
            this.isScanning = false;
            return;
          }
          followersLink.click();
          await new Promise((resolve) => setTimeout(resolve, 2e3));
          modal = document.querySelector('[role="dialog"]');
        }
        if (!modal) {
          this.isScanning = false;
          return;
        }
        const scanLimit = expectedNew + 5;
        const links = modal.querySelectorAll('a[href^="/"]');
        const currentFollowers = [];
        for (const link of Array.from(links).slice(0, scanLimit * 3)) {
          const href = link.getAttribute("href");
          if (href) {
            const usernameMatch = href.match(/^\/([a-zA-Z0-9._]+)\/?(\?.*)?$/);
            if (usernameMatch) {
              const username = usernameMatch[1];
              const systemPages = ["explore", "reels", "direct", "p", "stories", "tv", "accounts"];
              if (!systemPages.includes(username) && !currentFollowers.includes(username)) {
                currentFollowers.push(username);
                if (username === this.followerDatabase.firstFollowerId) {
                  break;
                }
              }
            }
          }
        }
        const newFollowers = [];
        for (const username of currentFollowers) {
          if (username === this.followerDatabase.firstFollowerId) {
            break;
          }
          if (!this.followerDatabase.followers[username]) {
            newFollowers.push(username);
          }
        }
        console.log(`\u{1F195} Found ${newFollowers.length} new followers:`, newFollowers);
        for (const username of newFollowers) {
          this.followerDatabase.followers[username] = {
            username,
            addedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          await chrome.runtime.sendMessage({
            type: "TRACK_FOLLOWER",
            data: {
              username,
              metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString() }
            }
          });
        }
        let hiddenUnfollowers = 0;
        if (newFollowers.length > 0) {
          this.followerDatabase.firstFollowerId = newFollowers[0];
          hiddenUnfollowers = await this.reconcileTotalAfterNewFollowers();
        }
        await accountRemove("pendingNewFollowerScan");
        const closeButton = modal.querySelector('button[aria-label="Close"], button[aria-label="Fermer"]');
        if (closeButton) {
          closeButton.click();
        }
        if (newFollowers.length > 0) {
          this.scanOverlay.showSuccess(
            hiddenUnfollowers > 0 ? `${newFollowers.length} new \xB7 ${hiddenUnfollowers} hidden unfollower(s) detected` : `${newFollowers.length} new follower(s) collected!`
          );
        } else {
          this.scanOverlay.hide();
        }
        console.log("\u2705 Smart scan completed");
      } catch (error) {
        console.error("Error during smart scan:", error);
        this.scanOverlay.showError("Error during detection");
      } finally {
        this.isScanning = false;
        await this.updateBadge("");
      }
    }
    /**
     * DÉTECTION UNFOLLOWERS AVEC SMART SCROLLER
     * Utilise InstagramModalScroller et FollowerExtractor pour détecter les unfollowers
     */
    async detectUnfollowersWithSmartScroller() {
      if (this.isScanning) {
        console.log("\u23F3 Scan already in progress");
        return;
      }
      this.isScanning = true;
      console.log("\u{1F50D} Starting unfollower detection with Smart Scroller...");
      await this.updateBadge("\u{1F50D}");
      this.scanOverlay.show("Detecting unfollowers...");
      try {
        const modal = await this.ensureFollowersModalOpen();
        if (!modal) {
          throw new Error("Followers modal not found");
        }
        const scroller = new InstagramModalScroller({
          maxScrollAttempts: 3,
          scrollDelay: 300,
          onProgress: (progress) => {
            this.scanOverlay.updateProgress(
              progress.totalFollowers,
              Object.keys(this.followerDatabase.followers).length,
              `${progress.totalFollowers} followers v\xE9rifi\xE9s`
            );
          }
        });
        const extractor = new FollowerExtractor();
        console.log("\u{1F680} Scanning current followers...");
        const currentUsernames = await scroller.scrollToEnd();
        console.log(`\u2705 Found ${currentUsernames.length} current followers`);
        const previousUsernames = Object.keys(this.followerDatabase.followers);
        console.log(`\u{1F4CA} Previous followers in DB: ${previousUsernames.length}`);
        console.log(`\u{1F4CA} Current followers scanned: ${currentUsernames.length}`);
        const currentSet = new Set(currentUsernames);
        const previousSet = new Set(previousUsernames);
        const unfollowers = previousUsernames.filter((username) => !currentSet.has(username));
        const newFollowers = currentUsernames.filter((username) => !previousSet.has(username));
        console.log(`\u{1F6AB} Detected ${unfollowers.length} unfollowers:`, unfollowers);
        console.log(`\u{1F195} Detected ${newFollowers.length} new followers:`, newFollowers);
        for (const username of newFollowers) {
          try {
            this.followerDatabase.followers[username] = {
              username,
              addedAt: (/* @__PURE__ */ new Date()).toISOString()
            };
            await chrome.runtime.sendMessage({
              type: "TRACK_FOLLOWER",
              data: {
                username,
                metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString() }
              }
            });
          } catch (error) {
            console.error(`Error tracking new follower ${username}:`, error);
          }
        }
        for (const username of unfollowers) {
          try {
            await chrome.runtime.sendMessage({
              type: "TRACK_UNFOLLOWER",
              data: {
                username,
                metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString() }
              }
            });
            delete this.followerDatabase.followers[username];
          } catch (error) {
            console.error(`Error tracking unfollower ${username}:`, error);
          }
        }
        this.followerDatabase.totalCount = Object.keys(this.followerDatabase.followers).length;
        this.followerDatabase.lastScanDate = (/* @__PURE__ */ new Date()).toISOString();
        await this.saveFollowerDatabase();
        scroller.closeModal();
        await this.updateBadge(unfollowers.length > 0 ? `-${unfollowers.length}` : "\u2705");
        this.scanOverlay.showSuccess(
          unfollowers.length > 0 ? `${unfollowers.length} unfollower(s) d\xE9tect\xE9(s) !` : "Aucun unfollower d\xE9tect\xE9"
        );
        console.log("\u2705 Unfollower detection completed");
      } catch (error) {
        console.error("Error during unfollower detection:", error);
        this.scanOverlay.showError(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
      } finally {
        this.isScanning = false;
        setTimeout(() => this.updateBadge(""), 3e3);
      }
    }
    /**
     * SCAN PROGRESSIF UNFOLLOWERS (Par portions intelligent)
     */
    async scanUnfollowersProgressive(expectedUnfollowers) {
      if (this.isScanning) return;
      this.isScanning = true;
      console.log(`\u{1F50D} Starting progressive scan for ${expectedUnfollowers} unfollowers...`);
      this.scanOverlay.show(`Searching for ${expectedUnfollowers} unfollower(s)...`);
      try {
        const modal = await this.ensureFollowersModalOpen();
        if (!modal) {
          this.isScanning = false;
          return;
        }
        const scrollContainer = modal.querySelector('div[style*="overflow"]');
        if (!scrollContainer) {
          this.isScanning = false;
          return;
        }
        const portionSize = 50;
        const maxPortions = 10;
        let portion = 0;
        let unfollowersFound = [];
        let scannedFollowers = /* @__PURE__ */ new Set();
        while (portion < maxPortions && unfollowersFound.length < expectedUnfollowers) {
          portion++;
          const links = modal.querySelectorAll('a[href^="/"]');
          for (const link of Array.from(links)) {
            const href = link.getAttribute("href");
            if (href) {
              const usernameMatch = href.match(/^\/([a-zA-Z0-9._]+)\/?(\?.*)?$/);
              if (usernameMatch) {
                const username = usernameMatch[1];
                const systemPages = ["explore", "reels", "direct", "p", "stories", "tv", "accounts"];
                if (!systemPages.includes(username)) {
                  scannedFollowers.add(username);
                }
              }
            }
          }
          const dbFollowers = Object.keys(this.followerDatabase.followers);
          for (const dbFollower of dbFollowers) {
            if (!scannedFollowers.has(dbFollower) && !unfollowersFound.includes(dbFollower)) {
              unfollowersFound.push(dbFollower);
            }
          }
          console.log(`\u{1F4CA} Portion ${portion}: ${unfollowersFound.length}/${expectedUnfollowers} unfollowers found`);
          await this.updateScanProgress(unfollowersFound.length, expectedUnfollowers);
          this.scanOverlay.updateProgress(unfollowersFound.length, expectedUnfollowers, `Portion ${portion}`);
          if (unfollowersFound.length === expectedUnfollowers) {
            console.log("\u2705 All unfollowers found, stopping scan");
            break;
          }
          if (unfollowersFound.length === 0 && portion > 2) {
            console.log("\u26A0\uFE0F No unfollowers in recent portions, stopping");
            break;
          }
          scrollContainer.scrollTop = scrollContainer.scrollHeight;
          const delay = 800 + Math.random() * 400;
          await new Promise((resolve) => setTimeout(resolve, delay));
        }
        console.log(`\u{1F6AB} Found ${unfollowersFound.length} unfollowers:`, unfollowersFound);
        for (const username of unfollowersFound) {
          await chrome.runtime.sendMessage({
            type: "TRACK_UNFOLLOWER",
            data: {
              username,
              metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString() }
            }
          });
          delete this.followerDatabase.followers[username];
        }
        this.followerDatabase.totalCount -= unfollowersFound.length;
        await this.saveFollowerDatabase();
        const closeButton = modal.querySelector('button[aria-label="Close"], button[aria-label="Fermer"]');
        if (closeButton) {
          closeButton.click();
        }
        this.scanOverlay.showSuccess(`${unfollowersFound.length} unfollower(s) detected!`);
        console.log("\u2705 Progressive scan completed");
      } catch (error) {
        console.error("Error during progressive scan:", error);
        this.scanOverlay.showError("Error during detection");
      } finally {
        this.isScanning = false;
        await this.updateBadge("");
      }
    }
    /**
     * Vérification rapide des nouveaux followers (seulement les 10 premiers visibles)
     */
    async quickCheckForNewFollowers() {
      try {
        const modal = await this.ensureFollowersModalOpen();
        if (!modal) {
          console.log("\u274C Modal not found");
          return;
        }
        const extractor = new FollowerExtractor();
        const visibleFollowers = extractor.extractAllVisible();
        if (visibleFollowers.length === 0) {
          console.log("\u26A0\uFE0F No followers found in modal");
          return;
        }
        console.log(`\u{1F4CA} Found ${visibleFollowers.length} visible followers`);
        const firstFollower = visibleFollowers[0];
        const isNew = !this.followerDatabase.followers[firstFollower.username];
        if (isNew) {
          console.log(`\u{1F195} New follower detected: @${firstFollower.username}`);
          this.followerDatabase.followers[firstFollower.username] = {
            username: firstFollower.username,
            avatarUrl: firstFollower.avatarUrl,
            addedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          this.followerDatabase.totalCount++;
          this.followerDatabase.firstFollowerId = firstFollower.username;
          await this.saveFollowerDatabase();
          await chrome.runtime.sendMessage({
            type: "TRACK_FOLLOWER",
            data: {
              username: firstFollower.username,
              avatarUrl: firstFollower.avatarUrl,
              metadata: { detectedAt: (/* @__PURE__ */ new Date()).toISOString() }
            }
          });
          console.log("\u2705 New follower tracked and synced!");
        } else {
          console.log(`\u2713 First follower @${firstFollower.username} already in database`);
        }
      } catch (error) {
        console.error("Error during quick check:", error);
      }
    }
    /**
     * Observer automatique pour détecter l'ouverture du modal followers
     * et lancer la vérification des nouveaux followers
     */
    setupFollowersModalObserver() {
      console.log("\u{1F441}\uFE0F Setting up followers modal observer...");
      let lastModalCheck = 0;
      const CHECK_INTERVAL = 2e3;
      const checkForFollowersModal = () => {
        const now = Date.now();
        if (now - lastModalCheck < CHECK_INTERVAL) return;
        lastModalCheck = now;
        const modal = document.querySelector('[role="dialog"]');
        if (!modal) return;
        const modalText = modal.textContent?.toLowerCase() || "";
        const isFollowersModal = modalText.includes("follower") || modalText.includes("abonn\xE9");
        if (!isFollowersModal) return;
        if (!this.followerDatabase.isInitialized) {
          console.log("\u26A0\uFE0F Database not initialized, skipping auto-check");
          return;
        }
        if (this.isScanning) {
          console.log("\u23F3 Scan already in progress, skipping auto-check");
          return;
        }
        console.log("\u2705 Followers modal detected! Checking for new followers...");
        setTimeout(() => {
          this.quickCheckForNewFollowers();
        }, 1500);
      };
      const observer = new MutationObserver(() => {
        checkForFollowersModal();
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      console.log("\u2705 Followers modal observer active");
    }
  };
  var tracker = new InstagramTracker();
  tracker.init();
  window.fixFollowerCount = async (targetCount) => {
    console.log("\u{1F527} Fix Follower Count - Debug Tool\n");
    try {
      if (!targetCount) {
        const followerEl = document.querySelector('a[href*="/followers/"] span');
        if (followerEl) {
          const parseCount = (text) => {
            const cleaned = text.replace(/,/g, "").replace(/\s/g, "");
            if (cleaned.includes("K")) return Math.floor(parseFloat(cleaned) * 1e3);
            if (cleaned.includes("M")) return Math.floor(parseFloat(cleaned) * 1e6);
            return parseInt(cleaned) || 0;
          };
          targetCount = parseCount(followerEl.textContent?.trim() || "0");
          console.log(`\u{1F4CA} Compteur Instagram d\xE9tect\xE9: ${targetCount}`);
        } else {
          console.error("\u274C Compteur Instagram non trouv\xE9 et aucune valeur fournie");
          console.log("\u{1F4A1} Usage: fixFollowerCount(213)");
          return;
        }
      }
      const stored = await accountGet("followerDatabase");
      if (!stored.followerDatabase) {
        console.error("\u274C Base de donn\xE9es non trouv\xE9e");
        return;
      }
      const db = stored.followerDatabase;
      const actualCount = Object.keys(db.followers).length;
      console.log(`
\u{1F4C2} \xC9tat actuel:`);
      console.log(`   totalCount: ${db.totalCount}`);
      console.log(`   Followers r\xE9els: ${actualCount}`);
      console.log(`   Cible: ${targetCount}`);
      const oldCount = db.totalCount;
      db.totalCount = targetCount;
      await accountSet({
        followerDatabase: db,
        lastFollowerCount: targetCount
      });
      console.log(`
\u2705 CORRECTION APPLIQU\xC9E!`);
      console.log(`   ${oldCount} \u2192 ${targetCount}`);
      console.log(`
\u{1F504} Recharge l'extension (chrome://extensions/) pour voir le changement`);
      const diff = targetCount - actualCount;
      if (diff !== 0) {
        console.log(`
\u26A0\uFE0F Note: Diff\xE9rence de ${Math.abs(diff)} entre cible (${targetCount}) et DB (${actualCount})`);
        if (diff > 0) {
          console.log(`   \u2192 ${diff} follower(s) manquant(s) dans la base`);
          console.log(`   \u{1F4A1} Lance un scan pour les capturer`);
        } else {
          console.log(`   \u2192 ${Math.abs(diff)} entr\xE9e(s) obsol\xE8te(s) dans la base`);
          console.log(`   \u{1F4A1} Lance une d\xE9tection d'unfollowers`);
        }
      }
    } catch (error) {
      console.error("\u274C Erreur:", error);
    }
  };
  window.debugFollowerDetection = async function() {
    console.log("=".repeat(60));
    console.log("DEBUG - \xC9tat de la D\xE9tection des Followers");
    console.log("=".repeat(60));
    console.log("");
    console.log("\uFFFD [1/4] DOM...");
    const followerCountElement = document.querySelector('a[href*="/followers/"] span') || document.querySelector('a[href$="/followers/"] span');
    if (followerCountElement) {
      const countText = followerCountElement.textContent?.trim();
      const parseCount = (text) => {
        const cleaned = text.replace(/,/g, "").replace(/\s/g, "");
        if (cleaned.includes("K")) return Math.floor(parseFloat(cleaned) * 1e3);
        if (cleaned.includes("M")) return Math.floor(parseFloat(cleaned) * 1e6);
        return parseInt(cleaned) || 0;
      };
      const domCount2 = parseCount(countText || "0");
      console.log(`   \u2705 Followers (DOM): ${domCount2}`);
    } else {
      console.log("   \u274C \xC9l\xE9ment non trouv\xE9");
    }
    console.log("\u{1F4E6} [2/4] Storage...");
    const stored = await accountGet(["lastFollowerCount", "followerDatabase"]);
    console.log(`   lastFollowerCount: ${stored.lastFollowerCount || "non d\xE9fini"}`);
    if (stored.followerDatabase) {
      const dbCount2 = Object.keys(stored.followerDatabase.followers || {}).length;
      console.log(`   Database count: ${dbCount2}`);
      console.log(`   Database.totalCount: ${stored.followerDatabase.totalCount}`);
    }
    console.log("\u{1F50C} [3/4] API Interceptor...");
    console.log("   \u2139\uFE0F L'interception fetch/XHR s'ex\xE9cute dans le monde MAIN (page-interceptor.js)");
    console.log('   \u2139\uFE0F Cherchez le log "[MAIN] Waler page interceptor installed" au chargement de la page');
    console.log('   \u2139\uFE0F et "User info detected in API response" lors de la navigation');
    console.log("\u{1F50D} [4/4] Synchronisation...");
    const domCount = followerCountElement ? parseInt(followerCountElement.textContent?.replace(/[^0-9]/g, "") || "0") : null;
    const lastCount = stored.lastFollowerCount;
    const dbCount = stored.followerDatabase ? Object.keys(stored.followerDatabase.followers || {}).length : null;
    if (domCount === lastCount && domCount === dbCount) {
      console.log("   \u2705 Tout est synchronis\xE9!");
    } else {
      console.log("   \u26A0\uFE0F D\xC9SYNCHRONISATION:");
      console.log(`      DOM: ${domCount}`);
      console.log(`      lastFollowerCount: ${lastCount}`);
      console.log(`      Database: ${dbCount}`);
    }
    console.log("");
    console.log("=".repeat(60));
  };
  console.log("\u{1F4A1} Debug tools available:");
  console.log("   - debugFollowerDetection() : V\xE9rifier l'\xE9tat de la d\xE9tection");
  console.log("   - fixFollowerCount() : Corriger le compteur");
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "PING") {
      sendResponse({ success: true, ready: true });
      return true;
    } else if (message.type === "START_INITIAL_SCAN") {
      console.log("\u{1F4E8} Received START_INITIAL_SCAN message from popup");
      tracker["performInitialScanWithSmartScroller"]();
      sendResponse({ success: true });
    } else if (message.type === "START_UNFOLLOWER_ANALYSIS") {
      console.log("\u{1F4E8} Received START_UNFOLLOWER_ANALYSIS message from popup");
      tracker["startUnfollowerAnalysis"]();
      sendResponse({ success: true });
    } else if (message.type === "START_PRO_CONVERSATION_ANALYSIS") {
      console.log("\u{1F4E8} Received START_PRO_CONVERSATION_ANALYSIS message from popup");
      tracker["proCollector"].start(message.username, message.fullName);
      sendResponse({ success: true });
    } else if (message.type === "START_PRO_ENGAGEMENT_ANALYSIS") {
      console.log("\u{1F4E8} Received START_PRO_ENGAGEMENT_ANALYSIS message from popup");
      (async () => {
        const ownUsername = tracker["currentUsername"];
        const resp = await chrome.runtime.sendMessage({ type: "GET_PEOPLE" });
        const people = resp && resp.success && Array.isArray(resp.people) ? resp.people : [];
        const targets = people.map((p) => p.memberUsername).filter(Boolean);
        tracker["proEngagementCollector"].start(ownUsername || "", targets);
      })();
      sendResponse({ success: true });
    } else if (message.type === "START_NOTIFICATION_CHECK") {
      console.log("\u{1F4E8} Received START_NOTIFICATION_CHECK message from popup");
      if (localStorage.getItem("unfollowerCheckState")) {
        console.log("\u{1F515} Analyse unfollower en cours \u2014 START_NOTIFICATION_CHECK ignor\xE9");
        sendResponse({ success: false, reason: "analysis_in_progress" });
        return true;
      }
      tracker["notificationChecker"].startAutoCheck(tracker["followerDatabase"]);
      sendResponse({ success: true });
    } else if (message.type === "RESTORE_FROM_BACKEND") {
      console.log("\u{1F4E8} Received RESTORE_FROM_BACKEND message from popup");
      (async () => {
        const ok = await tracker.tryRestoreFromBackend();
        sendResponse({ success: ok, count: Object.keys(tracker["followerDatabase"].followers).length });
      })();
      return true;
    } else if (message.type === "FOLLOWER_COUNT_CHANGED") {
      console.log("\u{1F4E8} Received FOLLOWER_COUNT_CHANGED from API interceptor");
      const { newCount, diff } = message.data;
      tracker["lastFollowerCount"] = newCount;
      console.log(`\u{1F504} Synchronized lastFollowerCount to ${newCount} (${diff > 0 ? "+" : ""}${diff})`);
      if (diff > 0) {
        tracker["handleNewFollowers"](diff);
      } else if (diff < 0) {
        tracker["handleUnfollowers"](Math.abs(diff));
      }
      sendResponse({ success: true });
    }
    return true;
  });
  var instagram_tracker_default = tracker;
})();
